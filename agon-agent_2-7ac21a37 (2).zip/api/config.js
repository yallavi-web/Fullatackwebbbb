// Public site configuration: branding and which features the admin switched on.
import supabase from './db-client.js';
import { loadSettings } from './_lib/settings.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { site, access, bot, follow } = await loadSettings(supabase);
    return res.status(200).json({
      site: { name: site.name, tagline: site.tagline, logoUrl: site.logoUrl },
      bot: bot ? { username: bot.username, name: bot.name } : null,
      webBuilder: access.webBuilder,
      apiKeys: access.apiKeys,
      trialHours: access.trialHours,
      follow: { channel: follow.channel, links: follow.links },
    });
  } catch (err) {
    console.error('config API error:', err);
    return res.status(500).json({ error: err.message });
  }
}
