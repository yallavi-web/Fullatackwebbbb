import supabase from './db-client.js';
import { ownerHash } from './_lib/keystore.js';
import { resolveWorkspace } from './_lib/auth.js';
import { Invalid, createBuildFor, deleteBuildFor, publicBuild, purgeExpired } from './_lib/service.js';
import { loadSettings } from './_lib/settings.js';

const API_OFF = 'API access is switched off by the administrator';

async function listBuilds(req, res) {
  const { key, error: authError, via } = await resolveWorkspace(supabase, req);
  if (authError) return res.status(401).json({ error: authError });
  if (via === 'api-key' && !(await loadSettings(supabase)).access.apiKeys) return res.status(403).json({ error: API_OFF });
  const totalQuery = await supabase.from('builds').select('id', { count: 'exact', head: true });
  if (totalQuery.error) throw totalQuery.error;

  if (!key) return res.status(200).json({ builds: [], total: totalQuery.count ?? 0, signing: null });

  const owner = ownerHash(key);
  const [builds, signing] = await Promise.all([
    supabase.from('builds').select('*').eq('owner_hash', owner).order('created_at', { ascending: false }),
    supabase.from('keystores').select('fingerprint, created_at').eq('owner_hash', owner).maybeSingle(),
  ]);
  if (builds.error) throw builds.error;
  if (signing.error) throw signing.error;
  return res.status(200).json({
    builds: builds.data.map(publicBuild),
    total: totalQuery.count ?? 0,
    signing: signing.data || null,
  });
}

async function createBuild(req, res) {
  const { key, error: authError, via } = await resolveWorkspace(supabase, req);
  if (!key) {
    return res.status(401).json({ error: authError || 'Missing workspace key — reload the page and try again' });
  }
  const settings = await loadSettings(supabase);
  if (via === 'api-key' && !settings.access.apiKeys) return res.status(403).json({ error: API_OFF });
  if (via !== 'api-key' && !settings.access.webBuilder) {
    return res.status(403).json({ error: 'Building on the website is switched off by the administrator' });
  }

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const result = await createBuildFor(supabase, key, body);
  await purgeExpired(supabase, settings.privacy.retentionDays).catch(() => 0);
  return res.status(201).json({ build: result.build, log: result.log });
}

async function deleteBuild(req, res) {
  const { key, error: authError } = await resolveWorkspace(supabase, req);
  if (!key) return res.status(401).json({ error: authError || 'Missing workspace key' });
  const id = Number(req.body?.id ?? req.query?.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: 'Missing build id' });
  const removed = await deleteBuildFor(supabase, ownerHash(key), id);
  if (!removed) return res.status(404).json({ error: 'Build not found' });
  return res.status(200).json({ ok: true });
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Workspace-Key');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') return await listBuilds(req, res);
    if (req.method === 'POST') return await createBuild(req, res);
    if (req.method === 'DELETE') return await deleteBuild(req, res);
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    if (err instanceof Invalid) return res.status(400).json({ error: err.message, field: err.field });
    console.error('builds API error:', err);
    return res.status(500).json({ error: err?.message || 'Build server error' });
  }
}
