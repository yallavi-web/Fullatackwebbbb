import supabase from './db-client.js';
import { ownerHash } from './_lib/keystore.js';
import { newApiKey, workspaceFromHeader } from './_lib/auth.js';
import { loadSettings } from './_lib/settings.js';

const MAX_KEYS = 10;
const FIELDS = 'id, name, key_prefix, created_at, last_used_at';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Workspace-Key');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // Keys are managed from the browser workspace only — an API key cannot mint or revoke keys.
    const workspaceKey = workspaceFromHeader(req);
    if (!workspaceKey) {
      return res.status(401).json({ error: 'Missing workspace key — reload the page and try again' });
    }
    const owner = ownerHash(workspaceKey);

    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('api_keys')
        .select(FIELDS)
        .eq('owner_hash', owner)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const settings = await loadSettings(supabase);
      if (!settings.access.apiKeys) {
        return res.status(403).json({ error: 'API access is switched off by the administrator', field: 'name' });
      }
      const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
      if (!name) return res.status(400).json({ error: 'Give the key a name', field: 'name' });
      if ([...name].length > 40) {
        return res.status(400).json({ error: 'Keep the key name under 40 characters', field: 'name' });
      }
      const existing = await supabase
        .from('api_keys')
        .select('id', { count: 'exact', head: true })
        .eq('owner_hash', owner);
      if (existing.error) throw existing.error;
      if ((existing.count ?? 0) >= MAX_KEYS) {
        return res.status(400).json({ error: `You already have ${MAX_KEYS} API keys. Revoke one first.`, field: 'name' });
      }

      const fresh = newApiKey(workspaceKey);
      const { data, error } = await supabase
        .from('api_keys')
        .insert({
          owner_hash: owner,
          name,
          key_prefix: fresh.prefix,
          key_hash: fresh.hash,
          wrapped_key: fresh.wrapped,
          created_at: new Date().toISOString(),
        })
        .select(FIELDS)
        .single();
      if (error) throw error;
      // The full token is returned exactly once; only its hash is stored.
      return res.status(201).json({ key: data, token: fresh.token });
    }

    if (req.method === 'DELETE') {
      const id = Number(req.body?.id ?? req.query?.id);
      if (!Number.isInteger(id)) return res.status(400).json({ error: 'Missing key id' });
      const { data, error } = await supabase
        .from('api_keys')
        .delete()
        .eq('id', id)
        .eq('owner_hash', owner)
        .select('id');
      if (error) throw error;
      if (!data.length) return res.status(404).json({ error: 'API key not found' });
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('keys API error:', err);
    return res.status(500).json({ error: err?.message || 'Server error' });
  }
}
