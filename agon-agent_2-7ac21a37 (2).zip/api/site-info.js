// Pre-fills the builder form from a website's own metadata.
import { readSite } from './_lib/site.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Workspace-Key');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  let target;
  try {
    target = new URL(String(req.query?.url || ''));
    if (target.protocol !== 'http:' && target.protocol !== 'https:') throw new Error('scheme');
  } catch {
    return res.status(400).json({ error: 'Enter a valid http(s) website URL', field: 'url' });
  }

  try {
    return res.status(200).json(await readSite(target));
  } catch (err) {
    const timedOut = err?.name === 'TimeoutError' || err?.name === 'AbortError';
    const message = timedOut
      ? 'The website took too long to respond'
      : err?.message && !/fetch failed/i.test(err.message)
        ? err.message
        : `Could not reach ${target.hostname}`;
    return res.status(502).json({ error: message, field: 'url' });
  }
}
