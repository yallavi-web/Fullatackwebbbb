// Super-admin API. Every request needs the signed-in admin's session token.
import crypto from 'node:crypto';
import supabase from './db-client.js';
import { BUCKET, Invalid, publicBuild, purgeExpired, removeBuilds } from './_lib/service.js';
import { cleanAccess, cleanFollow, cleanPrivacy, cleanSite, dropSetting, loadSettings, saveSetting } from './_lib/settings.js';
import { seal, unseal, webhookSecret } from './_lib/secret.js';
import { tgClient, validToken } from './_lib/tg.js';
import { COMMANDS, accessOf } from './_lib/bot.js';
import { Forbidden, addAdmin, isSuper, listAdmins, removeAdmin, requireSuper, resetAdminPassword, resolveAdmin, setAdminRole } from './_lib/admins.js';

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function requireAdmin(req) {
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
  if (!token) throw new HttpError(401, 'Sign in to continue');
  const { data, error } = await supabase.auth.getUser(token);
  const user = data?.user;
  if (error || !user) throw new HttpError(401, 'Your session has expired — sign in again');

  const admin = await resolveAdmin(supabase, user, token);
  if (admin) return admin;
  throw new HttpError(403, 'This account is not an administrator');
}

async function audit(admin, action, detail = '') {
  await supabase
    .from('audit_log')
    .insert({ actor: admin.email, action, detail: String(detail).slice(0, 300), created_at: new Date().toISOString() });
}

function botView(bot) {
  if (!bot) return null;
  return { id: bot.id, username: bot.username, name: bot.name, hint: bot.hint, webhookUrl: bot.webhookUrl, connectedAt: bot.connectedAt };
}

function userView(u, settings) {
  const plan = accessOf(u, settings);
  return {
    id: u.id,
    username: u.username,
    first_name: u.first_name,
    status: u.status,
    approved: u.approved,
    unlimited: u.unlimited,
    trial_started_at: u.trial_started_at,
    access_until: u.access_until,
    builds_count: u.builds_count,
    created_at: u.created_at,
    last_seen_at: u.last_seen_at,
    plan: { ok: plan.ok, kind: plan.kind || null, reason: plan.reason || null, until: plan.until ? new Date(plan.until).toISOString() : null },
  };
}

const userLabel = (u) => (u.username ? `@${u.username}` : u.first_name || `Telegram user ${u.id}`);

async function snapshot(admin) {
  const settings = await loadSettings(supabase);
  await purgeExpired(supabase, settings.privacy.retentionDays).catch(() => 0);
  const [users, builds, total, log] = await Promise.all([
    supabase.from('tg_users').select('*').order('last_seen_at', { ascending: false }).limit(500),
    supabase.from('builds').select('*').order('created_at', { ascending: false }).limit(100),
    supabase.from('builds').select('id', { count: 'exact', head: true }),
    supabase.from('audit_log').select('*').order('id', { ascending: false }).limit(100),
  ]);
  for (const q of [users, builds, total, log]) if (q.error) throw q.error;

  const views = users.data.map((u) => userView(u, settings));
  const owners = new Map(users.data.map((u) => [u.owner_hash, u]));
  const count = (test) => views.filter(test).length;
  return {
    me: { email: admin.email, role: admin.role, via: admin.via, last_login_at: admin.last_login_at },
    settings: {
      site: { name: settings.site.name, tagline: settings.site.tagline, logoUrl: settings.site.logoUrl },
      access: settings.access,
      privacy: settings.privacy,
      follow: settings.follow,
    },
    bot: botView(settings.bot),
    stats: {
      users: views.length,
      trials: count((u) => u.plan.kind === 'trial'),
      access: count((u) => u.plan.kind === 'paid' || u.plan.kind === 'unlimited'),
      expired: count((u) => u.plan.reason === 'expired'),
      builds: total.count ?? 0,
    },
    users: views,
    builds: builds.data.map((b) => {
      const owner = owners.get(b.owner_hash);
      return { ...publicBuild(b), source: owner ? 'bot' : 'web', owner_label: owner ? userLabel(owner) : 'Website / API' };
    }),
    audit: log.data,
    admins: isSuper(admin) ? await listAdmins(supabase, admin) : [],
  };
}

// ------------------------------------------------------------ Telegram bot

function publicBase(req) {
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  if (!/^[a-z0-9.-]+$/i.test(host)) throw new HttpError(400, 'Could not work out this site’s address');
  return `https://${host}`;
}

async function registerBot(token, req) {
  const tg = tgClient(token);
  let me;
  try {
    me = await tg.call('getMe');
  } catch (err) {
    throw new Invalid(
      'token',
      err.code === 401 || err.code === 404
        ? 'Telegram rejected this token. Copy it again from @BotFather and try once more.'
        : `${err.message}. Try again in a moment.`,
    );
  }
  if (!me?.is_bot || !me.username) throw new Invalid('token', 'This token does not belong to a bot.');
  const webhookUrl = `${publicBase(req)}/api/telegram`;
  try {
    await tg.call('setWebhook', {
      url: webhookUrl,
      secret_token: webhookSecret(me.id),
      allowed_updates: ['message', 'callback_query'],
      drop_pending_updates: true,
      max_connections: 20,
    });
  } catch (err) {
    throw new Invalid('token', `Telegram could not register the webhook: ${err.message}`);
  }
  await tg.call('setMyCommands', { commands: COMMANDS }).catch(() => {});
  return { me, webhookUrl };
}

function botToken(settings) {
  if (!settings.bot) throw new HttpError(400, 'No bot is connected');
  try {
    return unseal(settings.bot.token);
  } catch {
    throw new HttpError(400, 'The stored bot token can no longer be read — disconnect and connect the bot again');
  }
}

/** Best-effort message to a bot user (e.g. "your access was extended"). */
async function notify(settings, chatId, text) {
  if (!settings.bot || !chatId) return;
  try {
    await tgClient(unseal(settings.bot.token)).call('sendMessage', { chat_id: chatId, text });
  } catch {
    // The user may have stopped the bot; the admin action still stands.
  }
}

const sniffLogo = (buf) =>
  buf.length > 12 && buf[0] === 0x89 && buf[1] === 0x50
    ? 'png'
    : buf[0] === 0xff && buf[1] === 0xd8
      ? 'jpg'
      : buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP'
        ? 'webp'
        : null;

// ---------------------------------------------------------------- actions

async function userAction(admin, settings, body) {
  const id = Number(body.id);
  if (!Number.isSafeInteger(id)) throw new HttpError(400, 'Missing user id');
  const found = await supabase.from('tg_users').select('*').eq('id', id).maybeSingle();
  if (found.error) throw found.error;
  const user = found.data;
  if (!user) throw new HttpError(404, 'That user no longer exists');
  const label = userLabel(user);
  const now = Date.now();
  let patch = null;
  let message = '';

  if (body.op === 'grant') {
    const days = Number(body.days);
    if (!Number.isInteger(days) || days < 1 || days > 3650) throw new HttpError(400, 'Choose between 1 and 3650 days');
    const from = Math.max(now, user.access_until ? new Date(user.access_until).getTime() : 0);
    patch = { access_until: new Date(from + days * 86400000).toISOString(), unlimited: false };
    message = `Your access was extended by ${days} day${days === 1 ? '' : 's'}. Send /new to build an app.`;
    await audit(admin, 'Granted access', `${label}: +${days} days`);
  } else if (body.op === 'unlimited') {
    patch = { unlimited: true };
    message = 'You now have unlimited access. Send /new to build an app.';
    await audit(admin, 'Granted unlimited access', label);
  } else if (body.op === 'revoke') {
    patch = { unlimited: false, access_until: null, trial_started_at: new Date(0).toISOString() };
    await audit(admin, 'Ended access', label);
  } else if (body.op === 'resetTrial') {
    patch = { trial_started_at: new Date(now).toISOString() };
    message = 'Your free trial was restarted. Send /new to build an app.';
    await audit(admin, 'Restarted trial', label);
  } else if (body.op === 'block' || body.op === 'unblock') {
    patch = { status: body.op === 'block' ? 'blocked' : 'active' };
    await audit(admin, body.op === 'block' ? 'Blocked user' : 'Unblocked user', label);
  } else if (body.op === 'approve') {
    patch = { approved: true };
    message = 'Your account was approved. Send /new to build an app.';
    await audit(admin, 'Approved user', label);
  } else if (body.op === 'delete') {
    const owned = await supabase.from('builds').select('id, storage_prefix').eq('owner_hash', user.owner_hash).limit(1000);
    if (owned.error) throw owned.error;
    await removeBuilds(supabase, owned.data);
    const draft = user.state?.draft;
    const drafts = [draft?.iconPath, draft?.siteIconPath].filter(Boolean).flatMap((p) => ['icon.png', 'icon-fg.png', 'icon-bg.png'].map((f) => `${p}/${f}`));
    if (drafts.length) await supabase.storage.from(BUCKET).remove(drafts);
    await supabase.from('keystores').delete().eq('owner_hash', user.owner_hash);
    const del = await supabase.from('tg_users').delete().eq('id', id);
    if (del.error) throw del.error;
    await audit(admin, 'Deleted user data', `Telegram user ${id} and ${owned.data.length} build(s)`);
    return;
  } else {
    throw new HttpError(400, 'Unknown user action');
  }

  const { error } = await supabase.from('tg_users').update(patch).eq('id', id);
  if (error) throw error;
  if (message) await notify(settings, user.chat_id, message);
}

async function act(admin, req) {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const settings = await loadSettings(supabase);

  switch (body.action) {
    case 'login':
      await supabase.from('admins').update({ last_login_at: new Date().toISOString() }).eq('id', admin.id);
      await audit(admin, 'Signed in', admin.via === 'google' ? 'with Google' : 'with e-mail and password');
      return {};
    case 'passwordChanged':
      await audit(admin, 'Changed password');
      return {};

    case 'saveSite':
      await saveSetting(supabase, 'site', cleanSite(body.site, settings.site));
      await audit(admin, 'Updated branding', String(body.site?.name || '').slice(0, 40));
      return {};
    case 'saveAccess': {
      const access = cleanAccess(body.access);
      await saveSetting(supabase, 'access', access);
      await audit(admin, 'Updated access settings', `trial ${access.trialHours} h · bot ${access.botAccess} · web ${access.webBuilder ? 'on' : 'off'} · API ${access.apiKeys ? 'on' : 'off'}`);
      return {};
    }
    case 'savePrivacy': {
      const privacy = cleanPrivacy(body.privacy);
      await saveSetting(supabase, 'privacy', privacy);
      if (!privacy.storeProfiles) {
        // Switching profile storage off also wipes what was stored before.
        const wipe = await supabase.from('tg_users').update({ username: null, first_name: null }).gt('id', 0);
        if (wipe.error) throw wipe.error;
      }
      await audit(admin, 'Updated privacy settings', `profiles ${privacy.storeProfiles ? 'stored' : 'not stored'} · retention ${privacy.retentionDays || 'off'} · auto-lock ${privacy.idleMinutes} min`);
      return {};
    }

    case 'saveFollow': {
      const follow = cleanFollow(body.follow);
      if (follow.required) {
        // Only an administrator of the channel can see who has joined it.
        if (!settings.bot) throw new Invalid('channel', 'Connect the Telegram bot first — it is what checks who has joined.');
        const needAdmin = `Add @${settings.bot.username} as an administrator of @${follow.channel} first, so it can check who has joined.`;
        let member;
        try {
          member = await tgClient(botToken(settings)).call('getChatMember', { chat_id: `@${follow.channel}`, user_id: settings.bot.id });
        } catch (err) {
          throw new Invalid('channel', /chat not found/i.test(err.message) ? `Telegram can’t find @${follow.channel}. Check the username.` : needAdmin);
        }
        if (member.status !== 'administrator' && member.status !== 'creator') throw new Invalid('channel', needAdmin);
      }
      await saveSetting(supabase, 'follow', follow);
      await audit(admin, 'Updated follow settings', `${follow.channel ? `@${follow.channel}${follow.required ? ' (required)' : ''}` : 'no channel'} · ${follow.links.length} link(s)`);
      return {};
    }

    case 'uploadLogo': {
      const buf = Buffer.from(String(body.fileBase64 || ''), 'base64');
      const ext = buf.length ? sniffLogo(buf) : null;
      if (!ext) throw new Invalid('logo', 'Use a PNG, JPG or WebP image for the logo');
      if (buf.length > 512 * 1024) throw new Invalid('logo', 'Keep the logo under 512 KB');
      const path = `branding/logo-${crypto.randomBytes(6).toString('hex')}.${ext}`;
      const bucket = supabase.storage.from(BUCKET);
      const up = await bucket.upload(path, buf, { contentType: ext === 'jpg' ? 'image/jpeg' : `image/${ext}`, upsert: true });
      if (up.error) throw up.error;
      if (settings.site.logoPath) await bucket.remove([settings.site.logoPath]);
      await saveSetting(supabase, 'site', { ...settings.site, logoUrl: bucket.getPublicUrl(path).data.publicUrl, logoPath: path });
      await audit(admin, 'Changed logo');
      return {};
    }
    case 'removeLogo':
      if (settings.site.logoPath) await supabase.storage.from(BUCKET).remove([settings.site.logoPath]);
      await saveSetting(supabase, 'site', { ...settings.site, logoUrl: '', logoPath: '' });
      await audit(admin, 'Removed logo');
      return {};

    case 'connectBot': {
      requireSuper(admin);
      const token = String(body.token || '').trim();
      if (!validToken(token)) {
        throw new Invalid('token', 'That doesn’t look like a bot token. It should look like 123456789:AAE… — copy it from @BotFather.');
      }
      const { me, webhookUrl } = await registerBot(token, req);
      await saveSetting(supabase, 'bot', {
        token: seal(token),
        id: me.id,
        username: me.username,
        name: me.first_name,
        hint: `${me.id}:••••${token.slice(-4)}`,
        webhookUrl,
        connectedAt: new Date().toISOString(),
      });
      await audit(admin, 'Connected Telegram bot', `@${me.username}`);
      return {};
    }
    case 'repairBot': {
      requireSuper(admin);
      const { me, webhookUrl } = await registerBot(botToken(settings), req);
      await saveSetting(supabase, 'bot', { ...settings.bot, username: me.username, name: me.first_name, webhookUrl });
      await audit(admin, 'Re-registered bot webhook', `@${me.username}`);
      return {};
    }
    case 'testBot': {
      const tg = tgClient(botToken(settings));
      let me;
      let info;
      try {
        me = await tg.call('getMe');
        info = await tg.call('getWebhookInfo');
      } catch (err) {
        return { test: { ok: false, error: err.code === 401 ? 'Telegram no longer accepts this token. It may have been revoked in @BotFather.' : err.message } };
      }
      const matches = info.url === settings.bot.webhookUrl;
      return {
        test: {
          ok: matches && !info.last_error_message,
          username: me.username,
          matches,
          pending: info.pending_update_count || 0,
          lastError: info.last_error_message || null,
          lastErrorAt: info.last_error_date ? new Date(info.last_error_date * 1000).toISOString() : null,
        },
      };
    }
    case 'disconnectBot': {
      requireSuper(admin);
      if (settings.bot) {
        try {
          await tgClient(unseal(settings.bot.token)).call('deleteWebhook', { drop_pending_updates: true });
        } catch {
          // The token may already be revoked; forgetting it is what matters.
        }
        await dropSetting(supabase, 'bot');
        await audit(admin, 'Disconnected Telegram bot', `@${settings.bot.username}`);
      }
      return {};
    }

    case 'addAdmin': {
      const { admin: added, password } = await addAdmin(supabase, admin, body);
      await audit(admin, 'Added admin', `${added.email} (${added.role === 'super_admin' ? 'super admin' : 'admin'}, ${added.method === 'google' ? 'Google sign-in' : 'password'})`);
      // A password admin gets a temporary password, shown once and not stored anywhere; a Google admin has none.
      return { email: added.email, password };
    }
    case 'setAdminRole': {
      const changed = await setAdminRole(supabase, admin, Number(body.id), body.role);
      await audit(admin, 'Changed admin role', `${changed.email} → ${changed.role === 'super_admin' ? 'super admin' : 'admin'}`);
      return {};
    }
    case 'resetAdminPassword': {
      const reset = await resetAdminPassword(supabase, admin, Number(body.id));
      await audit(admin, 'Reset admin password', reset.email);
      return reset;
    }
    case 'removeAdmin': {
      const removed = await removeAdmin(supabase, admin, Number(body.id));
      await audit(admin, 'Removed admin', removed.email);
      return {};
    }

    case 'user':
      await userAction(admin, settings, body);
      return {};
    case 'deleteBuild': {
      const id = Number(body.id);
      const found = await supabase.from('builds').select('id, storage_prefix, app_name, version_name').eq('id', id).maybeSingle();
      if (found.error) throw found.error;
      if (!found.data) throw new HttpError(404, 'Build not found');
      await removeBuilds(supabase, [found.data]);
      await audit(admin, 'Deleted build', `${found.data.app_name} v${found.data.version_name}`);
      return {};
    }
    default:
      throw new HttpError(400, 'Unknown action');
  }
}

export default async function handler(req, res) {
  // Same-origin only: no CORS headers are sent, so other websites cannot call this API from a browser.
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const admin = await requireAdmin(req);
    if (req.method === 'GET') return res.status(200).json(await snapshot(admin));
    if (req.method === 'POST') return res.status(200).json({ ok: true, ...(await act(admin, req)) });
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    if (err instanceof Invalid) return res.status(400).json({ error: err.message, field: err.field });
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
    if (err instanceof Forbidden) return res.status(403).json({ error: err.message });
    console.error('admin API error:', err?.message || err);
    return res.status(500).json({ error: err?.message || 'Server error' });
  }
}
