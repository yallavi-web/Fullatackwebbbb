// Signing identities. The private key is derived from the caller's workspace
// secret (never stored server-side); only the public self-signed certificate
// is persisted so every build from one workspace carries the same signature
// and Android accepts new builds as updates.
import crypto from 'node:crypto';

const OID_ECDSA_SHA256 = Buffer.from([0x06, 0x08, 0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02]);
const OID_CN = Buffer.from([0x06, 0x03, 0x55, 0x04, 0x03]);
const OID_O = Buffer.from([0x06, 0x03, 0x55, 0x04, 0x0a]);

function der(tag, ...parts) {
  const body = Buffer.concat(parts);
  let len;
  if (body.length < 0x80) len = Buffer.from([body.length]);
  else if (body.length < 0x100) len = Buffer.from([0x81, body.length]);
  else len = Buffer.from([0x82, body.length >> 8, body.length & 0xff]);
  return Buffer.concat([Buffer.from([tag]), len, body]);
}

const seq = (...parts) => der(0x30, ...parts);
const rdn = (oid, value) => der(0x31, seq(oid, der(0x0c, Buffer.from(value, 'utf8'))));

function derTime(date) {
  const p = (n, w = 2) => String(n).padStart(w, '0');
  const tail = `${p(date.getUTCMonth() + 1)}${p(date.getUTCDate())}${p(date.getUTCHours())}${p(date.getUTCMinutes())}${p(date.getUTCSeconds())}Z`;
  const year = date.getUTCFullYear();
  // RFC 5280: UTCTime through 2049, GeneralizedTime from 2050.
  return year < 2050
    ? der(0x17, Buffer.from(p(year % 100) + tail, 'ascii'))
    : der(0x18, Buffer.from(p(year, 4) + tail, 'ascii'));
}

export function ownerHash(secret) {
  return crypto.createHash('sha256').update('web2apk/owner/v1\n' + secret).digest('hex');
}

export function deriveKey(secret) {
  let d = crypto.createHash('sha256').update('web2apk/signing-key/v1\n' + secret).digest();
  const ecdh = crypto.createECDH('prime256v1');
  for (let i = 0; ; i++) {
    try {
      ecdh.setPrivateKey(d);
      break;
    } catch (err) {
      if (i > 8) throw err;
      d = crypto.createHash('sha256').update(d).digest();
    }
  }
  const pub = ecdh.getPublicKey();
  const privateKey = crypto.createPrivateKey({
    format: 'jwk',
    key: {
      kty: 'EC',
      crv: 'P-256',
      d: d.toString('base64url'),
      x: pub.subarray(1, 33).toString('base64url'),
      y: pub.subarray(33, 65).toString('base64url'),
    },
  });
  const spki = crypto.createPublicKey(privateKey).export({ type: 'spki', format: 'der' });
  return { privateKey, spki };
}

export function createCertificate({ privateKey, spki }, commonName) {
  const serial = crypto.randomBytes(8);
  serial[0] = (serial[0] & 0x7f) | 0x40;
  const name = seq(rdn(OID_O, 'Web2APK'), rdn(OID_CN, commonName));
  const notBefore = new Date(Date.now() - 24 * 3600 * 1000);
  const notAfter = new Date(notBefore.getTime() + 30 * 365.25 * 24 * 3600 * 1000);
  const algorithm = seq(OID_ECDSA_SHA256);
  const tbs = seq(
    der(0xa0, der(0x02, Buffer.from([2]))), // v3
    der(0x02, serial),
    algorithm,
    name,
    seq(derTime(notBefore), derTime(notAfter)),
    name,
    spki,
  );
  const signature = crypto.sign('sha256', tbs, privateKey);
  return seq(tbs, algorithm, der(0x03, Buffer.from([0]), signature));
}

export function certFingerprint(certDer) {
  return crypto.createHash('sha256').update(certDer).digest('hex');
}

/** Loads (or creates on first use) the certificate for this workspace. */
export async function loadKeystore(supabase, secret) {
  const owner = ownerHash(secret);
  const key = deriveKey(secret);

  const matches = (certB64) => {
    try {
      const certDer = Buffer.from(certB64, 'base64');
      const cert = new crypto.X509Certificate(certDer);
      const certSpki = cert.publicKey.export({ type: 'spki', format: 'der' });
      return certSpki.equals(key.spki) ? certDer : null;
    } catch {
      return null;
    }
  };

  const existing = await supabase.from('keystores').select('*').eq('owner_hash', owner).maybeSingle();
  if (existing.error) throw existing.error;
  if (existing.data) {
    const certDer = matches(existing.data.cert_b64);
    if (certDer) return { ...key, certDer, owner, fingerprint: existing.data.fingerprint, created: false };
  }

  const certDer = createCertificate(key, `Workspace ${owner.slice(0, 12)}`);
  const fingerprint = certFingerprint(certDer);
  const { error } = await supabase
    .from('keystores')
    .upsert({ owner_hash: owner, cert_b64: certDer.toString('base64'), fingerprint }, { onConflict: 'owner_hash', ignoreDuplicates: !existing.data });
  if (error) throw error;

  // Another request may have won the race — always sign with what is stored.
  const stored = await supabase.from('keystores').select('*').eq('owner_hash', owner).maybeSingle();
  if (stored.error) throw stored.error;
  const storedDer = stored.data ? matches(stored.data.cert_b64) : null;
  if (storedDer) return { ...key, certDer: storedDer, owner, fingerprint: stored.data.fingerprint, created: true };
  return { ...key, certDer, owner, fingerprint, created: true };
}
