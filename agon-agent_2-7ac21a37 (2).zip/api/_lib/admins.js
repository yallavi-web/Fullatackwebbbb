// Admin accounts: who may sign in to the admin panel, and with which role.
// Sign-in accounts are always created here, server-side, and bound by user id —
// an e-mail address alone never grants admin access.
import crypto from 'node:crypto';
import { Invalid } from './service.js';

export const MAX_ADMINS = 10;
const ROLES = ['super_admin', 'admin'];
const EMAIL = /^[^\s@]{1,64}@[^\s@.]+(\.[^\s@.]+)+$/;

export class Forbidden extends Error {}

// Admins who sign in with Google have no password account. Their row keeps
// `google:` in user_id until their first Google sign-in, then `google:<user id>`.
// The prefix matters: such a row is only ever matched by a session that was
// started through Google, never by a password session for the same account.
const GOOGLE = 'google:';
const isGoogleRow = (row) => String(row?.user_id || '').startsWith(GOOGLE);

/** Comparable form of an address; Gmail ignores dots, +tags and letter case. */
export function emailKey(email) {
  const value = String(email || '').trim().toLowerCase();
  const at = value.lastIndexOf('@');
  if (at < 1) return value;
  let local = value.slice(0, at);
  let domain = value.slice(at + 1);
  if (domain === 'googlemail.com') domain = 'gmail.com';
  if (domain === 'gmail.com') local = local.split('+')[0].replace(/\./g, '');
  return `${local}@${domain}`;
}

/**
 * True only for a session that was started by signing in with Google, for a
 * Google account whose verified address is this user's e-mail. The token has
 * already been verified by the auth server before this is called.
 */
export function isGoogleSession(user, token) {
  let methods = [];
  try {
    const claims = JSON.parse(Buffer.from(String(token).split('.')[1], 'base64url').toString('utf8'));
    methods = (Array.isArray(claims.amr) ? claims.amr : []).map((m) => (typeof m === 'string' ? m : m?.method));
  } catch {
    return false;
  }
  if (!methods.includes('oauth')) return false;
  const key = emailKey(user?.email);
  return (user?.identities || []).some(
    (i) => i.provider === 'google' && i.identity_data?.email_verified !== false && emailKey(i.identity_data?.email) === key,
  );
}

/** Finds the admin record for a signed-in user, or null when they are not an admin. */
export async function resolveAdmin(supabase, user, token) {
  const { data, error } = await supabase.from('admins').select('*');
  if (error) throw error;
  const google = isGoogleSession(user, token);

  const direct = data.find((row) => row.user_id === user.id);
  if (direct) return { ...direct, via: google ? 'google' : 'password' };
  if (!google) return null;

  const bound = data.find((row) => row.user_id === GOOGLE + user.id);
  if (bound) return { ...bound, via: 'google' };

  // First Google sign-in for an address a super admin has added: bind it to this account.
  const key = emailKey(user.email);
  const pending = data.find((row) => row.user_id === GOOGLE && emailKey(row.email) === key);
  if (!pending) return null;
  const claim = await supabase
    .from('admins')
    .update({ user_id: GOOGLE + user.id })
    .eq('id', pending.id)
    .eq('user_id', GOOGLE)
    .select()
    .maybeSingle();
  if (claim.error) throw claim.error;
  if (claim.data) return { ...claim.data, via: 'google' };
  // Another request from the same sign-in bound it a moment ago.
  const again = await supabase.from('admins').select('*').eq('user_id', GOOGLE + user.id).maybeSingle();
  if (again.error) throw again.error;
  return again.data ? { ...again.data, via: 'google' } : null;
}

export const isSuper = (admin) => admin?.role === 'super_admin';

export function requireSuper(admin) {
  if (!isSuper(admin)) throw new Forbidden('Only a super admin can do this');
}

/** 120 random bits, grouped so it can be read out or typed. */
export const tempPassword = () => crypto.randomBytes(15).toString('base64url').match(/.{5}/g).join('-');

const view = (row, me) => ({
  id: row.id,
  email: row.email,
  role: row.role,
  method: isGoogleRow(row) ? 'google' : 'password',
  last_login_at: row.last_login_at || null,
  created_at: row.created_at,
  you: row.id === me.id,
});

export async function listAdmins(supabase, me) {
  const { data, error } = await supabase.from('admins').select('*').order('id', { ascending: true });
  if (error) throw error;
  return data.map((row) => view(row, me));
}

async function findAdmin(supabase, id) {
  if (!Number.isInteger(id)) throw new Invalid(null, 'Missing admin id');
  const { data, error } = await supabase.from('admins').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  if (!data) throw new Invalid(null, 'That admin account no longer exists');
  return data;
}

/** Creates the sign-in account and the admin record. The password is returned once and never stored. */
export async function addAdmin(supabase, me, input) {
  requireSuper(me);
  const email = String(input?.email || '').trim().toLowerCase();
  if (!EMAIL.test(email) || email.length > 120) throw new Invalid('email', 'Enter a valid e-mail address');
  const role = ROLES.includes(input?.role) ? input.role : 'admin';

  const all = await supabase.from('admins').select('id, email');
  if (all.error) throw all.error;
  if (all.data.some((a) => emailKey(a.email) === emailKey(email))) {
    throw new Invalid('email', 'This e-mail already has an admin account');
  }
  if (all.data.length >= MAX_ADMINS) {
    throw new Invalid('email', `You can have up to ${MAX_ADMINS} admin accounts. Remove one first.`);
  }

  if (input?.method === 'google') {
    // No password account is created: this address can only get in by signing in with Google.
    const { data, error } = await supabase
      .from('admins')
      .insert({ email, user_id: GOOGLE, role, created_at: new Date().toISOString() })
      .select()
      .single();
    if (error) throw error;
    return { admin: view(data, me), password: null };
  }

  const password = tempPassword();
  const created = await supabase.auth.admin.createUser({ email, password, email_confirm: true });
  const user = created.data?.user;
  if (created.error || !user) {
    const reason = created.error?.message || '';
    if (/already|registered|exists/i.test(reason)) {
      // Someone else may know that account's password, so it is never promoted.
      throw new Invalid('email', 'A sign-in account with this e-mail already exists, so it can’t safely be made an admin. Use a different e-mail.');
    }
    throw new Error(reason || 'The account could not be created');
  }

  const { data, error } = await supabase
    .from('admins')
    .insert({ email, user_id: user.id, role, created_at: new Date().toISOString() })
    .select()
    .single();
  if (error) {
    await supabase.auth.admin.deleteUser(user.id);
    throw error;
  }
  return { admin: view(data, me), password };
}

export async function setAdminRole(supabase, me, id, role) {
  requireSuper(me);
  if (!ROLES.includes(role)) throw new Invalid(null, 'Unknown role');
  const target = await findAdmin(supabase, id);
  // You keep your own role, so there is always at least one super admin.
  if (target.id === me.id) throw new Invalid(null, 'You can’t change your own role. Ask another super admin.');
  if (target.role !== role) {
    const { error } = await supabase.from('admins').update({ role }).eq('id', id);
    if (error) throw error;
  }
  return view({ ...target, role }, me);
}

export async function resetAdminPassword(supabase, me, id) {
  requireSuper(me);
  const target = await findAdmin(supabase, id);
  if (target.id === me.id) throw new Invalid(null, 'Change your own password under Security & privacy.');
  if (isGoogleRow(target)) throw new Invalid(null, 'This admin signs in with Google, so there is no password to reset.');
  if (!target.user_id) throw new Invalid(null, 'This account has no sign-in attached. Remove it and add it again.');
  const password = tempPassword();
  const { error } = await supabase.auth.admin.updateUserById(target.user_id, { password });
  if (error) throw new Error(error.message || 'The password could not be reset');
  return { email: target.email, password };
}

export async function removeAdmin(supabase, me, id) {
  requireSuper(me);
  const target = await findAdmin(supabase, id);
  if (target.id === me.id) throw new Invalid(null, 'You can’t remove your own account.');
  // Removing the record ends their access at once: every request re-checks it.
  const del = await supabase.from('admins').delete().eq('id', id);
  if (del.error) throw del.error;
  if (target.user_id && !isGoogleRow(target)) {
    const gone = await supabase.auth.admin.deleteUser(target.user_id);
    if (gone.error) console.error('admin sign-in account could not be deleted:', gone.error.message);
  }
  return target;
}
