// Launcher icon layers for builds that arrive without artwork (API builds):
// a ring mark on the app's theme colour, at the sizes the APK template expects.
import zlib from 'node:zlib';
import { crc32 } from './apk.js';

function png(size, pixel) {
  const raw = Buffer.alloc(size * (size * 4 + 1));
  for (let y = 0; y < size; y++) {
    const row = y * (size * 4 + 1);
    for (let x = 0; x < size; x++) {
      const [r, g, b, a] = pixel(x, y);
      const o = row + 1 + x * 4;
      raw[o] = r;
      raw[o + 1] = g;
      raw[o + 2] = b;
      raw[o + 3] = a;
    }
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

const clamp = (v) => Math.max(0, Math.min(1, v));

const ring = (size, outer, inner) => (x, y) => {
  const d = Math.hypot(x + 0.5 - size / 2, y + 0.5 - size / 2);
  return clamp(outer - d + 0.5) * clamp(d - inner + 0.5);
};

/** @param {string} hex theme colour as #RRGGBB */
export function defaultIcons(hex) {
  const bg = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const luminance = (0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]) / 255;
  const fg = luminance > 0.6 ? [23, 22, 15] : [255, 255, 255];
  const adaptiveRing = ring(432, 84, 46);
  const legacyRing = ring(192, 56, 30);
  const radius = 42;
  return {
    background: png(432, () => [bg[0], bg[1], bg[2], 255]),
    foreground: png(432, (x, y) => [fg[0], fg[1], fg[2], Math.round(255 * adaptiveRing(x, y))]),
    legacy: png(192, (x, y) => {
      const cx = Math.min(Math.max(x + 0.5, radius), 192 - radius);
      const cy = Math.min(Math.max(y + 0.5, radius), 192 - radius);
      const corner = clamp(radius - Math.hypot(x + 0.5 - cx, y + 0.5 - cy) + 0.5);
      const mix = legacyRing(x, y);
      return [
        Math.round(bg[0] + (fg[0] - bg[0]) * mix),
        Math.round(bg[1] + (fg[1] - bg[1]) * mix),
        Math.round(bg[2] + (fg[2] - bg[2]) * mix),
        Math.round(255 * corner),
      ];
    }),
  };
}
