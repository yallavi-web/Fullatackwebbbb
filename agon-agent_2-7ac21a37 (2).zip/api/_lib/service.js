// Build pipeline shared by the website API and the Telegram bot.
import crypto from 'node:crypto';
import { buildApk } from './apk.js';
import { loadKeystore, ownerHash } from './keystore.js';
import { defaultIcons } from './default-icon.js';
import { shareCode } from './secret.js';

export const BUCKET = 'apks';
export const MAX_BUILDS_PER_WORKSPACE = 40;
const MAX_ICON_BYTES = 600 * 1024;
const HEX = /^#[0-9a-fA-F]{6}$/;
const PACKAGE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
export const ICON_FILES = { legacy: 'icon.png', foreground: 'icon-fg.png', background: 'icon-bg.png' };
const ICON_SIZES = { legacy: 192, foreground: 432, background: 432 };

export class Invalid extends Error {
  constructor(field, message) {
    super(message);
    this.field = field;
  }
}

export function publicBuild(row) {
  // eslint-disable-next-line no-unused-vars
  const { owner_hash, storage_prefix, ...rest } = row;
  return { ...rest, share_code: shareCode(row.id) };
}

/** '' when empty, the bare username / +invite code when valid, null otherwise. */
export function normalizeTelegramHandle(value) {
  let s = typeof value === 'string' ? value.trim() : '';
  if (!s) return '';
  s = s
    .replace(/^(https?:\/\/)?(www\.)?(t|telegram)\.me\//i, '')
    .replace(/^joinchat\//i, '+')
    .replace(/^@/, '')
    .replace(/[/?#].*$/, '');
  return /^\+[A-Za-z0-9_-]{8,64}$/.test(s) || /^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(s) ? s : null;
}

export function validate(body) {
  const str = (v) => (typeof v === 'string' ? v.trim() : '');

  const appName = str(body.name);
  if (!appName) throw new Invalid('name', 'Give your app a name');
  if ([...appName].length > 40) throw new Invalid('name', 'Keep the app name under 40 characters');
  if (/[\u0000-\u001f]/.test(appName)) throw new Invalid('name', 'The app name contains control characters');

  let url;
  try {
    url = new URL(str(body.url));
  } catch {
    throw new Invalid('url', 'Enter a valid website URL, e.g. https://example.com');
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new Invalid('url', 'Only http:// and https:// websites can be wrapped');
  }
  if (url.toString().length > 2000) throw new Invalid('url', 'That URL is too long');

  const packageName = str(body.packageName);
  if (!PACKAGE.test(packageName) || packageName.length > 100) {
    throw new Invalid(
      'packageName',
      'Use a reverse-domain ID like com.example.app (lowercase letters, digits and underscores)',
    );
  }

  const versionName = str(body.versionName) || '1.0.0';
  if (!/^[0-9A-Za-z][0-9A-Za-z._+-]{0,23}$/.test(versionName)) {
    throw new Invalid('versionName', 'Use up to 24 letters, digits, dots or dashes, e.g. 1.2.0');
  }
  const versionCode = Number(body.versionCode);
  if (!Number.isInteger(versionCode) || versionCode < 1 || versionCode > 2100000000) {
    throw new Invalid('versionCode', 'Version code must be a whole number from 1 to 2,100,000,000');
  }

  const color = (value, field, fallback) => {
    const s = str(value) || fallback;
    if (!HEX.test(s)) throw new Invalid(field, 'Use a hex colour like #1FBF6B');
    return s.toUpperCase();
  };
  const oneOf = (value, allowed, fallback) => (allowed.includes(value) ? value : fallback);

  const telegram = normalizeTelegramHandle(body.telegram);
  if (telegram === null) {
    throw new Invalid('telegram', 'Enter a Telegram username, channel or t.me link, e.g. @mychannel');
  }
  const customCss =
    typeof body.customCss === 'string' ? body.customCss.replace(/[\u0000\u2028\u2029]/g, '').trim() : '';
  if (customCss.length > 4000) throw new Invalid('customCss', 'Keep custom CSS under 4,000 characters');

  return {
    appName,
    url: url.toString(),
    packageName,
    versionName,
    versionCode,
    themeColor: color(body.themeColor, 'themeColor', '#1FBF6B'),
    backgroundColor: color(body.backgroundColor, 'backgroundColor', '#FFFFFF'),
    orientation: oneOf(body.orientation, ['auto', 'portrait', 'landscape'], 'auto'),
    options: {
      fullscreen: body.fullscreen === true,
      keepScreenOn: body.keepScreenOn === true,
      zoom: body.zoom === true,
      splash: body.splash !== false,
      confirmExit: body.confirmExit === true,
      desktopMode: body.desktopMode === true,
      externalLinks: oneOf(body.externalLinks, ['inapp', 'browser'], 'inapp'),
      camera: body.camera === true,
      microphone: body.microphone === true,
      location: body.location === true,
      navBar: body.navBar === true,
      blockScreenshots: body.blockScreenshots === true,
      telegram,
      customCss,
    },
  };
}

function decodeIcon(value, key) {
  if (typeof value !== 'string' || !value) throw new Invalid('icon', 'The app icon is missing — pick or generate one');
  const buf = Buffer.from(value.replace(/^data:image\/png;base64,/, ''), 'base64');
  if (buf.length < 57 || buf.length > MAX_ICON_BYTES || !buf.subarray(0, 8).equals(PNG_MAGIC)) {
    throw new Invalid('icon', 'The icon could not be read. Try a different image.');
  }
  const size = ICON_SIZES[key];
  if (buf.readUInt32BE(16) !== size || buf.readUInt32BE(20) !== size) {
    throw new Invalid('icon', 'The icon has unexpected dimensions. Try a different image.');
  }
  return buf;
}

async function iconsFromBuild(supabase, owner, id) {
  const gone = () => new Invalid('icon', 'The original icon is no longer available — choose a new one');
  const { data, error } = await supabase
    .from('builds')
    .select('storage_prefix')
    .eq('id', id)
    .eq('owner_hash', owner)
    .maybeSingle();
  if (error) throw error;
  if (!data) throw gone();
  const icons = {};
  for (const [key, file] of Object.entries(ICON_FILES)) {
    const res = await supabase.storage.from(BUCKET).download(`${data.storage_prefix}/${file}`);
    if (res.error || !res.data) throw gone();
    icons[key] = Buffer.from(await res.data.arrayBuffer());
  }
  return icons;
}

function fileNameFor(appName, versionName) {
  const slug = appName
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  return `${slug || 'app'}-${versionName}.apk`;
}

/**
 * Builds, stores and records one APK for the workspace identified by `key`.
 * `opts.icons` supplies ready-made launcher layers (used by the Telegram bot).
 */
export async function createBuildFor(supabase, key, body, opts = {}) {
  const started = Date.now();
  const spec = validate(body);
  const owner = ownerHash(key);

  const existing = await supabase
    .from('builds')
    .select('id', { count: 'exact', head: true })
    .eq('owner_hash', owner);
  if (existing.error) throw existing.error;
  if ((existing.count ?? 0) >= MAX_BUILDS_PER_WORKSPACE) {
    throw new Invalid(null, `You have ${MAX_BUILDS_PER_WORKSPACE} stored builds. Delete an old one to make room.`);
  }

  const icons = opts.icons
    ? opts.icons
    : body.iconsFromBuild != null
      ? await iconsFromBuild(supabase, owner, Number(body.iconsFromBuild))
      : body.icons == null
        ? defaultIcons(spec.themeColor)
        : {
            legacy: decodeIcon(body.icons.legacy, 'legacy'),
            foreground: decodeIcon(body.icons.foreground, 'foreground'),
            background: decodeIcon(body.icons.background, 'background'),
          };

  const keystore = await loadKeystore(supabase, key);

  const { apk, sha256, log } = buildApk(
    {
      packageName: spec.packageName,
      appName: spec.appName,
      versionName: spec.versionName,
      versionCode: spec.versionCode,
      permissions: spec.options,
      icons,
      config: {
        url: spec.url,
        appName: spec.appName,
        themeColor: spec.themeColor,
        backgroundColor: spec.backgroundColor,
        orientation: spec.orientation,
        ...spec.options,
      },
    },
    keystore,
  );

  const prefix = `${owner.slice(0, 16)}/${crypto.randomBytes(9).toString('hex')}`;
  const bucket = supabase.storage.from(BUCKET);
  const uploads = [
    [`${prefix}/app.apk`, apk, 'application/vnd.android.package-archive'],
    ...Object.entries(ICON_FILES).map(([k, file]) => [`${prefix}/${file}`, icons[k], 'image/png']),
  ];
  const uploaded = await Promise.all(
    uploads.map(([path, data, contentType]) =>
      bucket.upload(path, data, { contentType, upsert: true, cacheControl: '300' }),
    ),
  );
  const failed = uploaded.find((u) => u.error);
  if (failed) {
    await bucket.remove(uploads.map((u) => u[0]));
    throw failed.error;
  }

  const fileName = fileNameFor(spec.appName, spec.versionName);
  const apkUrl = `${bucket.getPublicUrl(`${prefix}/app.apk`).data.publicUrl}?download=${encodeURIComponent(fileName)}`;
  const iconUrl = bucket.getPublicUrl(`${prefix}/icon.png`).data.publicUrl;

  const { data, error } = await supabase
    .from('builds')
    .insert({
      owner_hash: owner,
      app_name: spec.appName,
      package_name: spec.packageName,
      url: spec.url,
      version_name: spec.versionName,
      version_code: spec.versionCode,
      theme_color: spec.themeColor,
      background_color: spec.backgroundColor,
      orientation: spec.orientation,
      options: spec.options,
      storage_prefix: prefix,
      apk_url: apkUrl,
      icon_url: iconUrl,
      file_name: fileName,
      apk_size: apk.length,
      sha256,
      cert_sha256: keystore.fingerprint,
      created_at: new Date().toISOString(),
    })
    .select()
    .single();
  if (error) {
    await bucket.remove(uploads.map((u) => u[0]));
    throw error;
  }

  const base = Date.now() - started;
  const fullLog = [
    { t: 0, message: keystore.created ? 'Created signing identity for this workspace' : 'Loaded workspace signing identity' },
    ...log,
    { t: base, message: `Published ${fileName} to storage` },
  ];
  return { build: publicBuild(data), row: data, log: fullLog, apk };
}

/** Deletes build rows together with their stored APK and icon files. */
export async function removeBuilds(supabase, rows) {
  if (!rows.length) return 0;
  const paths = rows.flatMap((r) => ['app.apk', ...Object.values(ICON_FILES)].map((f) => `${r.storage_prefix}/${f}`));
  const removal = await supabase.storage.from(BUCKET).remove(paths);
  if (removal.error) throw removal.error;
  const del = await supabase.from('builds').delete().in('id', rows.map((r) => r.id));
  if (del.error) throw del.error;
  return rows.length;
}

export async function deleteBuildFor(supabase, owner, id) {
  const { data, error } = await supabase
    .from('builds')
    .select('id, storage_prefix')
    .eq('id', id)
    .eq('owner_hash', owner)
    .maybeSingle();
  if (error) throw error;
  if (!data) return false;
  await removeBuilds(supabase, [data]);
  return true;
}

/** Data retention: removes builds older than `days` (0 keeps them forever). */
export async function purgeExpired(supabase, days) {
  if (!(days > 0)) return 0;
  const cutoff = new Date(Date.now() - days * 86400000).toISOString();
  const { data, error } = await supabase.from('builds').select('id, storage_prefix').lt('created_at', cutoff).limit(25);
  if (error) throw error;
  return removeBuilds(supabase, data || []);
}
