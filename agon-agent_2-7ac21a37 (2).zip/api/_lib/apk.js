// Pure-JS APK assembler: patches the compiled shell template, writes an aligned
// ZIP and signs it with APK Signature Scheme v2 (ECDSA P-256 / SHA-256).
import crypto from 'node:crypto';
import { TEMPLATE_FILES } from './template.js';

const PLACEHOLDER_PACKAGE = 'com.web2apk.placeholder';
const PLACEHOLDER_LABEL = 'W2A_APP_LABEL';
const PLACEHOLDER_VERSION = 'W2A_VERSION_NAME';
const ATTR_VERSION_CODE = 0x0101021b;

const RES_STRING_POOL = 0x0001;
const RES_TABLE = 0x0002;
const RES_XML = 0x0003;
const RES_XML_RESOURCE_MAP = 0x0180;
const RES_XML_START_ELEMENT = 0x0102;
const RES_XML_END_ELEMENT = 0x0103;
const TYPE_STRING = 0x03;
const RES_TABLE_PACKAGE = 0x0200;

const OPTIONAL_PERMISSIONS = {
  camera: ['android.permission.CAMERA'],
  microphone: ['android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS'],
  location: ['android.permission.ACCESS_FINE_LOCATION', 'android.permission.ACCESS_COARSE_LOCATION'],
};

// ---------------------------------------------------------------- utilities

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const u32 = (n) => {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n >>> 0);
  return b;
};
const u64 = (n) => {
  const b = Buffer.alloc(8);
  b.writeBigUInt64LE(BigInt(n));
  return b;
};
const lp = (...parts) => {
  const body = Buffer.concat(parts);
  return Buffer.concat([u32(body.length), body]);
};
const sha256 = (...parts) => {
  const h = crypto.createHash('sha256');
  for (const p of parts) h.update(p);
  return h.digest();
};

// ------------------------------------------------- Android binary XML (AXML)

function readStringPool(buf, off) {
  if (buf.readUInt16LE(off) !== RES_STRING_POOL) throw new Error('String pool chunk expected');
  const headerSize = buf.readUInt16LE(off + 2);
  const size = buf.readUInt32LE(off + 4);
  const stringCount = buf.readUInt32LE(off + 8);
  const styleCount = buf.readUInt32LE(off + 12);
  const flags = buf.readUInt32LE(off + 16);
  const stringsStart = buf.readUInt32LE(off + 20);
  if (styleCount !== 0) throw new Error('Styled string pools are not supported');
  const utf8 = (flags & 0x100) !== 0;
  const strings = [];
  for (let i = 0; i < stringCount; i++) {
    let p = off + stringsStart + buf.readUInt32LE(off + headerSize + i * 4);
    if (utf8) {
      if (buf[p++] & 0x80) p++; // UTF-16 length (1 or 2 bytes) — not needed
      let n = buf[p++];
      if (n & 0x80) n = ((n & 0x7f) << 8) | buf[p++];
      strings.push(buf.toString('utf8', p, p + n));
    } else {
      let n = buf.readUInt16LE(p);
      p += 2;
      if (n & 0x8000) {
        n = ((n & 0x7fff) << 16) | buf.readUInt16LE(p);
        p += 2;
      }
      strings.push(buf.toString('utf16le', p, p + n * 2));
    }
  }
  return { size, strings };
}

/** Serialises a string pool as UTF-16 (unambiguous for emoji / non-Latin app names). */
function writeStringPool(strings) {
  const headerSize = 28;
  const offsets = Buffer.alloc(strings.length * 4);
  const chunks = [];
  let cursor = 0;
  strings.forEach((str, i) => {
    offsets.writeUInt32LE(cursor, i * 4);
    const units = str.length;
    const wide = units > 0x7fff;
    const entry = Buffer.alloc((wide ? 4 : 2) + units * 2 + 2);
    let p = 0;
    if (wide) {
      entry.writeUInt16LE(((units >>> 16) & 0x7fff) | 0x8000, 0);
      entry.writeUInt16LE(units & 0xffff, 2);
      p = 4;
    } else {
      entry.writeUInt16LE(units, 0);
      p = 2;
    }
    entry.write(str, p, 'utf16le');
    chunks.push(entry);
    cursor += entry.length;
  });
  const pad = (4 - (cursor % 4)) % 4;
  if (pad) chunks.push(Buffer.alloc(pad));
  const data = Buffer.concat(chunks);
  const header = Buffer.alloc(headerSize);
  const stringsStart = headerSize + offsets.length;
  header.writeUInt16LE(RES_STRING_POOL, 0);
  header.writeUInt16LE(headerSize, 2);
  header.writeUInt32LE(stringsStart + data.length, 4);
  header.writeUInt32LE(strings.length, 8);
  header.writeUInt32LE(0, 12); // styleCount
  header.writeUInt32LE(0, 16); // flags: UTF-16, unsorted
  header.writeUInt32LE(stringsStart, 20);
  header.writeUInt32LE(0, 24); // stylesStart
  return Buffer.concat([header, offsets, data]);
}

function patchManifest(src, { replacements, versionCode, removePermissions }) {
  if (src.readUInt16LE(0) !== RES_XML) throw new Error('Not a binary XML file');
  const fileHeaderSize = src.readUInt16LE(2);
  const pool = readStringPool(src, fileHeaderSize);
  const seen = new Set();
  const strings = pool.strings.map((s) => {
    if (replacements.has(s)) {
      seen.add(s);
      return replacements.get(s);
    }
    return s;
  });
  for (const key of replacements.keys()) {
    if (!seen.has(key)) throw new Error(`Template is missing manifest string "${key}"`);
  }

  const rest = Buffer.from(src.subarray(fileHeaderSize + pool.size));

  // Walk the remaining chunks: set android:versionCode and drop the
  // <uses-permission> elements (start + end chunk) the app did not ask for.
  const kept = [];
  const removed = [];
  let resourceIds = [];
  let patchedVersion = false;
  let skipNextEnd = false;
  for (let off = 0; off + 8 <= rest.length; ) {
    const type = rest.readUInt16LE(off);
    const headerSize = rest.readUInt16LE(off + 2);
    const size = rest.readUInt32LE(off + 4);
    if (size < 8 || off + size > rest.length) throw new Error('Corrupt XML chunk');
    let keep = true;
    if (type === RES_XML_RESOURCE_MAP) {
      resourceIds = [];
      for (let p = off + headerSize; p + 4 <= off + size; p += 4) resourceIds.push(rest.readUInt32LE(p));
    } else if (type === RES_XML_START_ELEMENT) {
      const ext = off + headerSize;
      const element = pool.strings[rest.readUInt32LE(ext + 4)];
      const attrStart = rest.readUInt16LE(ext + 8);
      const attrSize = rest.readUInt16LE(ext + 10);
      const attrCount = rest.readUInt16LE(ext + 12);
      for (let i = 0; i < attrCount; i++) {
        const a = ext + attrStart + i * attrSize;
        const nameIdx = rest.readUInt32LE(a + 4);
        if (resourceIds[nameIdx] === ATTR_VERSION_CODE) {
          rest.writeUInt32LE(versionCode >>> 0, a + 16);
          patchedVersion = true;
        }
        if (element === 'uses-permission' && rest[a + 15] === TYPE_STRING) {
          const value = pool.strings[rest.readUInt32LE(a + 16)];
          if (removePermissions.has(value)) {
            keep = false;
            removed.push(value);
          }
        }
      }
      if (!keep) skipNextEnd = true;
    } else if (type === RES_XML_END_ELEMENT && skipNextEnd) {
      keep = false;
      skipNextEnd = false;
    }
    if (keep) kept.push(rest.subarray(off, off + size));
    off += size;
  }
  if (!patchedVersion) throw new Error('versionCode attribute not found in template manifest');
  for (const name of removePermissions) {
    if (!removed.includes(name)) throw new Error(`Template is missing permission ${name}`);
  }

  const body = Buffer.concat(kept);
  const newPool = writeStringPool(strings);
  const header = Buffer.from(src.subarray(0, fileHeaderSize));
  header.writeUInt32LE(fileHeaderSize + newPool.length + body.length, 4);
  return Buffer.concat([header, newPool, body]);
}

function patchResourceTable(src, packageName) {
  const buf = Buffer.from(src);
  if (buf.readUInt16LE(0) !== RES_TABLE) throw new Error('Not a resource table');
  let off = buf.readUInt16LE(2);
  while (off + 8 <= buf.length) {
    const type = buf.readUInt16LE(off);
    const size = buf.readUInt32LE(off + 4);
    if (type === RES_TABLE_PACKAGE) {
      const nameField = buf.subarray(off + 12, off + 12 + 256);
      nameField.fill(0);
      nameField.write(packageName.slice(0, 127), 0, 'utf16le');
      return buf;
    }
    if (size < 8) break;
    off += size;
  }
  throw new Error('Package chunk not found in resource table');
}

// ---------------------------------------------------------------------- ZIP

function dosDateTime(date) {
  const time = (date.getUTCHours() << 11) | (date.getUTCMinutes() << 5) | (date.getUTCSeconds() >> 1);
  const day = ((date.getUTCFullYear() - 1980) << 9) | ((date.getUTCMonth() + 1) << 5) | date.getUTCDate();
  return { time, day };
}

/** Writes every entry STORED and 4-byte aligned (same layout `zipalign -p 4` produces). */
function writeZip(entries, date) {
  const { time, day } = dosDateTime(date);
  const locals = [];
  const centrals = [];
  let offset = 0;
  for (const entry of entries) {
    const name = Buffer.from(entry.name, 'utf8');
    const crc = crc32(entry.data);
    const pad = (4 - ((offset + 30 + name.length) % 4)) % 4;
    const local = Buffer.alloc(30 + name.length + pad);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(10, 4); // version needed
    local.writeUInt16LE(0, 6); // flags
    local.writeUInt16LE(0, 8); // method: stored
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(day, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(entry.data.length, 18);
    local.writeUInt32LE(entry.data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(pad, 28);
    name.copy(local, 30);

    const central = Buffer.alloc(46 + name.length);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(10, 4); // version made by
    central.writeUInt16LE(10, 6); // version needed
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(day, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(entry.data.length, 20);
    central.writeUInt32LE(entry.data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt32LE(offset, 42);
    name.copy(central, 46);

    locals.push(local, entry.data);
    centrals.push(central);
    offset += local.length + entry.data.length;
  }
  const contents = Buffer.concat(locals);
  const centralDir = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralDir.length, 12);
  eocd.writeUInt32LE(contents.length, 16);
  return { contents, centralDir, eocd };
}

// ------------------------------------------------- APK Signature Scheme v2

const SIG_ECDSA_SHA256 = 0x0201;
const V2_BLOCK_ID = 0x7109871a;
const CHUNK = 1024 * 1024;

function contentDigest(sections) {
  const digests = [];
  for (const section of sections) {
    for (let off = 0; off < section.length; off += CHUNK) {
      const chunk = section.subarray(off, Math.min(off + CHUNK, section.length));
      digests.push(sha256(Buffer.from([0xa5]), u32(chunk.length), chunk));
    }
  }
  return sha256(Buffer.from([0x5a]), u32(digests.length), ...digests);
}

function signV2({ contents, centralDir, eocd }, keystore) {
  // The EOCD is digested with its central-directory offset pointing at the
  // signing block start, which is exactly the unsigned layout.
  const digest = contentDigest([contents, centralDir, eocd]);

  const signedData = Buffer.concat([
    lp(lp(u32(SIG_ECDSA_SHA256), lp(digest))), // digests
    lp(lp(keystore.certDer)), // certificates
    lp(), // additional attributes
  ]);
  const signature = crypto.sign('sha256', signedData, keystore.privateKey);
  const signer = Buffer.concat([
    lp(signedData),
    lp(lp(u32(SIG_ECDSA_SHA256), lp(signature))),
    lp(keystore.spki),
  ]);
  const v2Value = lp(lp(signer));

  const pair = Buffer.concat([u64(4 + v2Value.length), u32(V2_BLOCK_ID), v2Value]);
  const blockSize = pair.length + 8 + 16;
  const block = Buffer.concat([u64(blockSize), pair, u64(blockSize), Buffer.from('APK Sig Block 42', 'ascii')]);

  const finalEocd = Buffer.from(eocd);
  finalEocd.writeUInt32LE(contents.length + block.length, 16);
  return Buffer.concat([contents, block, centralDir, finalEocd]);
}

// ------------------------------------------------------------ public API

/**
 * @param {object} spec
 * @param {string} spec.packageName
 * @param {string} spec.appName
 * @param {string} spec.versionName
 * @param {number} spec.versionCode
 * @param {object} spec.config            runtime config written to assets/web2apk.json
 * @param {{camera:boolean, microphone:boolean, location:boolean}} spec.permissions
 * @param {{legacy?:Buffer, foreground?:Buffer, background?:Buffer}} spec.icons
 * @param {{privateKey:crypto.KeyObject, spki:Buffer, certDer:Buffer}} keystore
 */
export function buildApk(spec, keystore) {
  const log = [];
  const t0 = Date.now();
  const step = (message) => log.push({ t: Date.now() - t0, message });

  const files = new Map();
  for (const [name, b64] of Object.entries(TEMPLATE_FILES)) files.set(name, Buffer.from(b64, 'base64'));
  step(`Loaded Android shell template (${files.size} entries, minSdk 24 → targetSdk 34)`);

  const replacements = new Map([
    [PLACEHOLDER_PACKAGE, spec.packageName],
    [PLACEHOLDER_LABEL, spec.appName],
    [PLACEHOLDER_VERSION, spec.versionName],
  ]);
  const dropped = [];
  const removePermissions = new Set();
  for (const [flag, names] of Object.entries(OPTIONAL_PERMISSIONS)) {
    if (spec.permissions?.[flag]) continue;
    for (const name of names) removePermissions.add(name);
    dropped.push(flag);
  }
  files.set(
    'AndroidManifest.xml',
    patchManifest(files.get('AndroidManifest.xml'), {
      replacements,
      versionCode: spec.versionCode,
      removePermissions,
    }),
  );
  step(`Patched AndroidManifest.xml → ${spec.packageName} v${spec.versionName} (${spec.versionCode})`);
  const kept = Object.keys(OPTIONAL_PERMISSIONS).filter((k) => !dropped.includes(k));
  step(`Permissions: internet, network-state${kept.length ? ', ' + kept.join(', ') : ''}`);

  files.set('resources.arsc', patchResourceTable(files.get('resources.arsc'), spec.packageName));
  step('Rewrote resources.arsc package entry');

  const iconTargets = {
    legacy: 'ic_launcher.png',
    foreground: 'ic_launcher_foreground.png',
    background: 'ic_launcher_background.png',
  };
  let replaced = 0;
  for (const [key, suffix] of Object.entries(iconTargets)) {
    const data = spec.icons?.[key];
    if (!data) continue;
    const target = [...files.keys()].find((n) => n.endsWith('/' + suffix));
    if (!target) throw new Error(`Template is missing ${suffix}`);
    files.set(target, data);
    replaced++;
  }
  step(replaced ? `Embedded launcher icon (${replaced} layers, adaptive + legacy)` : 'Using default launcher icon');

  const configJson = Buffer.from(JSON.stringify(spec.config, null, 2), 'utf8');
  files.set('assets/web2apk.json', configJson);
  step(`Wrote assets/web2apk.json → ${spec.config.url}`);

  const order = ['AndroidManifest.xml', 'classes.dex', 'resources.arsc'];
  const names = [...order, ...[...files.keys()].filter((n) => !order.includes(n)).sort()];
  const zip = writeZip(names.map((name) => ({ name, data: files.get(name) })), new Date());
  step(`Packed ${names.length} entries, stored + 4-byte aligned`);

  const apk = signV2(zip, keystore);
  step('Signed with APK Signature Scheme v2 (ECDSA P-256 / SHA-256)');

  const digest = sha256(apk).toString('hex');
  step(`Finished ${apk.length.toLocaleString('en-US')} bytes · sha256 ${digest.slice(0, 16)}…`);
  return { apk, sha256: digest, log };
}
