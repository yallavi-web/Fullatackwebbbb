// Resolves who is calling: the browser's workspace key (X-Workspace-Key) or an
// API key (Authorization: Bearer w2a_...). An API key never stores the
// workspace key in the clear: it is AES-256-GCM wrapped with a key derived from
// the API key itself, so only a request that presents the key can unwrap it.
import crypto from 'node:crypto';

const WORKSPACE_KEY = /^[A-Za-z0-9_-]{32,128}$/;
const API_KEY = /^w2a_[A-Za-z0-9_-]{43}$/;

const digest = (label, token) => crypto.createHash('sha256').update(`${label}\n${token}`).digest();

export const hashApiKey = (token) => digest('web2apk/api-key/v1', token).toString('hex');

export function workspaceFromHeader(req) {
  const key = String(req.headers['x-workspace-key'] || '');
  return WORKSPACE_KEY.test(key) ? key : null;
}

export function newApiKey(workspaceKey) {
  const token = 'w2a_' + crypto.randomBytes(32).toString('base64url');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', digest('web2apk/api-key-wrap/v1', token), iv);
  const body = Buffer.concat([cipher.update(workspaceKey, 'utf8'), cipher.final()]);
  return {
    token,
    prefix: token.slice(0, 12),
    hash: hashApiKey(token),
    wrapped: Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64'),
  };
}

function unwrap(token, wrapped) {
  const raw = Buffer.from(wrapped, 'base64');
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    digest('web2apk/api-key-wrap/v1', token),
    raw.subarray(0, 12),
  );
  decipher.setAuthTag(raw.subarray(12, 28));
  return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8');
}

/** @returns {Promise<{key: string|null, error?: string, via?: 'api-key'|'workspace'}>} */
export async function resolveWorkspace(supabase, req) {
  const header = String(req.headers.authorization || '');
  const bearer = /^Bearer\s+/i.test(header) ? header.replace(/^Bearer\s+/i, '').trim() : '';
  if (bearer) {
    const rejected = { key: null, error: 'This API key is not valid or has been revoked' };
    if (!API_KEY.test(bearer)) return rejected;
    const { data, error } = await supabase
      .from('api_keys')
      .select('id, wrapped_key')
      .eq('key_hash', hashApiKey(bearer))
      .maybeSingle();
    if (error) throw error;
    if (!data) return rejected;
    let key;
    try {
      key = unwrap(bearer, data.wrapped_key);
    } catch {
      return rejected;
    }
    if (!WORKSPACE_KEY.test(key)) return rejected;
    await supabase.from('api_keys').update({ last_used_at: new Date().toISOString() }).eq('id', data.id);
    return { key, via: 'api-key' };
  }
  const key = workspaceFromHeader(req);
  return key ? { key, via: 'workspace' } : { key: null };
}
