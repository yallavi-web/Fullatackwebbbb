// Minimal Telegram Bot API client. Error messages never include the request URL,
// because the URL carries the bot token.
const TOKEN = /^\d{5,15}:[A-Za-z0-9_-]{30,64}$/;

export const validToken = (token) => TOKEN.test(token);

export function tgClient(token, { apiBase = 'https://api.telegram.org' } = {}) {
  const base = `${apiBase}/bot${token}`;

  async function request(url, init, timeoutMs) {
    try {
      return await fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
    } catch (err) {
      const e = new Error(err?.name === 'TimeoutError' ? 'Telegram did not respond in time' : 'Telegram could not be reached');
      e.code = 0;
      throw e;
    }
  }

  async function api(method, init, timeoutMs) {
    const res = await request(`${base}/${method}`, init, timeoutMs);
    const data = await res.json().catch(() => null);
    if (!data || data.ok !== true) {
      const e = new Error(data?.description || `Telegram API error (${res.status})`);
      e.code = data?.error_code || res.status;
      throw e;
    }
    return data.result;
  }

  const call = (method, params = {}, timeoutMs = 10000) =>
    api(method, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) }, timeoutMs);

  /** Files must be uploaded as multipart: Telegram only fetches PDF/ZIP/GIF by URL. */
  function sendDocument(chatId, buffer, fileName, extra = {}) {
    const form = new FormData();
    form.append('chat_id', String(chatId));
    form.append('document', new Blob([buffer], { type: 'application/vnd.android.package-archive' }), fileName);
    if (extra.caption) {
      form.append('caption', extra.caption);
      form.append('parse_mode', 'HTML');
    }
    if (extra.keyboard) form.append('reply_markup', JSON.stringify({ inline_keyboard: extra.keyboard }));
    return api('sendDocument', { method: 'POST', body: form }, 25000);
  }

  async function downloadFile(fileId, maxBytes = 5 * 1024 * 1024) {
    const file = await call('getFile', { file_id: fileId });
    if (!file.file_path) throw new Error('Telegram did not return the file');
    if (file.file_size && file.file_size > maxBytes) throw new Error('That file is too large');
    const res = await request(`${apiBase}/file/bot${token}/${file.file_path}`, {}, 10000);
    if (!res.ok) throw new Error('The file could not be downloaded from Telegram');
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > maxBytes) throw new Error('That file is too large');
    return buf;
  }

  return { call, sendDocument, downloadFile };
}
