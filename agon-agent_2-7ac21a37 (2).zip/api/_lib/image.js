// Turns a PNG/JPG (a Telegram photo or a website icon) into the three launcher
// icon layers the APK template expects. Pure JS, no native image libraries.
import { PNG } from 'pngjs';
import jpeg from 'jpeg-js';

const LEGACY = 192; // mipmap-xxxhdpi launcher icon
const ADAPTIVE = 432; // adaptive icon layer (108dp)
const VIEWPORT = 288; // visible part of an adaptive icon (72dp)
const MAX_SIDE = 4096;

export function decodeImage(buf) {
  if (buf.length > 24 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    if (buf.readUInt32BE(16) > MAX_SIDE || buf.readUInt32BE(20) > MAX_SIDE) throw new Error('That image is too large');
    const png = PNG.sync.read(buf);
    return { width: png.width, height: png.height, data: png.data };
  }
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) {
    const img = jpeg.decode(buf, { useTArray: true, formatAsRGBA: true, maxResolutionInMP: 17, maxMemoryUsageInMB: 256 });
    return { width: img.width, height: img.height, data: img.data };
  }
  throw new Error('Only PNG and JPG images can be used as an icon');
}

/** Icons that already fill their frame (opaque edges) are used edge to edge. */
function analyze({ width: w, height: h, data }) {
  const inset = (n) => Math.min(n - 1, Math.round(n * 0.02));
  const xs = [inset(w), Math.floor(w / 2), w - 1 - inset(w)];
  const ys = [inset(h), Math.floor(h / 2), h - 1 - inset(h)];
  let r = 0;
  let g = 0;
  let b = 0;
  let n = 0;
  for (let yi = 0; yi < 3; yi++) {
    for (let xi = 0; xi < 3; xi++) {
      if (xi === 1 && yi === 1) continue;
      const o = (ys[yi] * w + xs[xi]) * 4;
      if (data[o + 3] < 245) return { fullBleed: false, color: [255, 255, 255] };
      r += data[o];
      g += data[o + 1];
      b += data[o + 2];
      n++;
    }
  }
  return { fullBleed: true, color: [Math.round(r / n), Math.round(g / n), Math.round(b / n)] };
}

/** Area-averaging resample of a source rectangle (alpha-weighted), bilinear when enlarging. */
function resample(src, sx, sy, sw, sh, dw, dh) {
  const out = new Uint8ClampedArray(dw * dh * 4);
  const xr = sw / dw;
  const yr = sh / dh;
  const { data, width, height } = src;
  for (let y = 0; y < dh; y++) {
    for (let x = 0; x < dw; x++) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      let weight = 0;
      const add = (px, py, w) => {
        const cx = Math.min(width - 1, Math.max(0, px));
        const cy = Math.min(height - 1, Math.max(0, py));
        const o = (cy * width + cx) * 4;
        const al = data[o + 3] * w;
        r += data[o] * al;
        g += data[o + 1] * al;
        b += data[o + 2] * al;
        a += al;
        weight += w;
      };
      if (xr <= 1 || yr <= 1) {
        const fx = sx + (x + 0.5) * xr - 0.5;
        const fy = sy + (y + 0.5) * yr - 0.5;
        const x0 = Math.floor(fx);
        const y0 = Math.floor(fy);
        const tx = fx - x0;
        const ty = fy - y0;
        add(x0, y0, (1 - tx) * (1 - ty));
        add(x0 + 1, y0, tx * (1 - ty));
        add(x0, y0 + 1, (1 - tx) * ty);
        add(x0 + 1, y0 + 1, tx * ty);
      } else {
        const x0 = sx + x * xr;
        const x1 = x0 + xr;
        const y0 = sy + y * yr;
        const y1 = y0 + yr;
        for (let py = Math.floor(y0); py < Math.ceil(y1); py++) {
          const wy = Math.min(py + 1, y1) - Math.max(py, y0);
          for (let px = Math.floor(x0); px < Math.ceil(x1); px++) {
            add(px, py, (Math.min(px + 1, x1) - Math.max(px, x0)) * wy);
          }
        }
      }
      if (a > 0) {
        const o = (y * dw + x) * 4;
        out[o] = r / a;
        out[o + 1] = g / a;
        out[o + 2] = b / a;
        out[o + 3] = a / weight;
      }
    }
  }
  return { data: out, w: dw, h: dh };
}

function compose(size, art, bg, radius) {
  const out = Buffer.alloc(size * size * 4);
  if (bg) {
    for (let o = 0; o < out.length; o += 4) {
      out[o] = bg[0];
      out[o + 1] = bg[1];
      out[o + 2] = bg[2];
      out[o + 3] = 255;
    }
  }
  const ox = Math.round((size - art.w) / 2);
  const oy = Math.round((size - art.h) / 2);
  for (let y = 0; y < art.h; y++) {
    const ty = y + oy;
    if (ty < 0 || ty >= size) continue;
    for (let x = 0; x < art.w; x++) {
      const tx = x + ox;
      if (tx < 0 || tx >= size) continue;
      const s = (y * art.w + x) * 4;
      const a = art.data[s + 3] / 255;
      if (a === 0) continue;
      const t = (ty * size + tx) * 4;
      const under = (out[t + 3] / 255) * (1 - a);
      const total = a + under;
      out[t] = Math.round((art.data[s] * a + out[t] * under) / total);
      out[t + 1] = Math.round((art.data[s + 1] * a + out[t + 1] * under) / total);
      out[t + 2] = Math.round((art.data[s + 2] * a + out[t + 2] * under) / total);
      out[t + 3] = Math.round(total * 255);
    }
  }
  if (radius) {
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const cx = Math.min(Math.max(x + 0.5, radius), size - radius);
        const cy = Math.min(Math.max(y + 0.5, radius), size - radius);
        const cover = Math.max(0, Math.min(1, radius - Math.hypot(x + 0.5 - cx, y + 0.5 - cy) + 0.5));
        if (cover < 1) out[(y * size + x) * 4 + 3] = Math.round(out[(y * size + x) * 4 + 3] * cover);
      }
    }
  }
  return PNG.sync.write({ width: size, height: size, data: out });
}

/** @returns {{legacy: Buffer, foreground: Buffer, background: Buffer}} */
export function renderIconLayers(img) {
  if (!img.width || !img.height) throw new Error('That image is empty');
  const { fullBleed, color } = analyze(img);
  const scale = fullBleed ? 1 : 0.62;
  // Edge-to-edge images are centre-cropped to a square; logos keep their shape.
  const side = Math.min(img.width, img.height);
  const sx = fullBleed ? (img.width - side) / 2 : 0;
  const sy = fullBleed ? (img.height - side) / 2 : 0;
  const sw = fullBleed ? side : img.width;
  const sh = fullBleed ? side : img.height;
  const fit = (box) => {
    const ratio = Math.min(box / sw, box / sh);
    return resample(img, sx, sy, sw, sh, Math.max(1, Math.round(sw * ratio)), Math.max(1, Math.round(sh * ratio)));
  };
  return {
    legacy: compose(LEGACY, fit(LEGACY * scale), color, LEGACY * 0.22),
    foreground: compose(ADAPTIVE, fit(VIEWPORT * scale), null, 0),
    background: compose(ADAPTIVE, { data: new Uint8ClampedArray(0), w: 0, h: 0 }, color, 0),
  };
}
