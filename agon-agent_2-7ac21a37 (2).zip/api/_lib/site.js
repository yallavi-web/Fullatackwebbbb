// Reads a website's own metadata (title, web manifest, theme colour, icons) so
// the builder can pre-fill the form. Fetches happen server-side to avoid CORS.
import dns from 'node:dns/promises';
import net from 'node:net';

const UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;

function ipv4Private(ip) {
  const [a, b] = ip.split('.').map(Number);
  return (
    a === 0 || a === 10 || a === 127 || a >= 224 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  );
}

function isPrivateAddress(ip) {
  if (net.isIPv4(ip)) return ipv4Private(ip);
  const lower = ip.toLowerCase();
  if (lower === '::1' || lower === '::') return true;
  if (lower.startsWith('::ffff:')) {
    const v4 = lower.slice(7);
    return net.isIPv4(v4) ? ipv4Private(v4) : true;
  }
  return /^f[cd]/.test(lower) || /^fe[89ab]/.test(lower);
}

async function assertPublicHost(hostname) {
  const host = hostname.replace(/^\[|\]$/g, '').toLowerCase();
  const blocked = () => new Error('That address is not reachable from the build server');
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw blocked();
    return;
  }
  if (host === 'localhost' || /\.(localhost|local|internal)$/.test(host)) throw blocked();
  let addresses;
  try {
    addresses = await dns.lookup(host, { all: true });
  } catch {
    throw new Error(`Could not find a website at ${host}`);
  }
  if (!addresses.length || addresses.some((a) => isPrivateAddress(a.address))) throw blocked();
}

async function safeFetch(startUrl, { maxBytes, accept, deadline }) {
  let url = new URL(startUrl);
  for (let hop = 0; hop < 6; hop++) {
    if (url.protocol !== 'http:' && url.protocol !== 'https:') throw new Error('Unsupported URL scheme');
    await assertPublicHost(url.hostname);
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new Error('The website took too long to respond');
    const res = await fetch(url, {
      redirect: 'manual',
      headers: { 'User-Agent': UA, Accept: accept, 'Accept-Language': 'en' },
      signal: AbortSignal.timeout(remaining),
    });
    const location = res.headers.get('location');
    if (res.status >= 300 && res.status < 400 && location) {
      if (res.body) await res.body.cancel().catch(() => {});
      url = new URL(location, url);
      continue;
    }
    const chunks = [];
    let total = 0;
    let truncated = false;
    if (res.body) {
      const reader = res.body.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.length;
        if (total > maxBytes) {
          chunks.push(value.subarray(0, value.length - (total - maxBytes)));
          truncated = true;
          await reader.cancel().catch(() => {});
          break;
        }
        chunks.push(value);
      }
    }
    return {
      url,
      ok: res.ok,
      status: res.status,
      contentType: (res.headers.get('content-type') || '').toLowerCase(),
      body: Buffer.concat(chunks),
      truncated,
    };
  }
  throw new Error('The website redirected too many times');
}

function decodeEntities(s) {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;|&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&');
}

function parseTags(html, tagName) {
  const tags = [];
  const tagRe = new RegExp(`<${tagName}\\b[^>]*>`, 'gi');
  const attrRe = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g;
  let m;
  while ((m = tagRe.exec(html))) {
    const attrs = {};
    let a;
    attrRe.lastIndex = 0;
    while ((a = attrRe.exec(m[0]))) {
      const safe = () => {
        try {
          return decodeEntities(a[2] ?? a[3] ?? a[4] ?? '');
        } catch {
          return a[2] ?? a[3] ?? a[4] ?? '';
        }
      };
      attrs[a[1].toLowerCase()] = safe().trim();
    }
    tags.push(attrs);
  }
  return tags;
}

function normaliseColor(value) {
  if (typeof value !== 'string') return null;
  const v = value.trim();
  if (!HEX.test(v)) return null;
  const hex = v.length === 4 ? '#' + [...v.slice(1)].map((c) => c + c).join('') : v;
  return hex.toUpperCase();
}

function sizeOf(sizes) {
  if (!sizes) return 0;
  if (/any/i.test(sizes)) return 512;
  const all = [...String(sizes).matchAll(/(\d+)x(\d+)/gi)].map((m) => Number(m[1]));
  return all.length ? Math.max(...all) : 0;
}

function brandFromHost(hostname) {
  const parts = hostname.split('.').filter(Boolean);
  if (parts.length < 2) return hostname;
  const tld = parts[parts.length - 1];
  const second = parts[parts.length - 2];
  const label = tld.length === 2 && second.length <= 3 && parts.length >= 3 ? parts[parts.length - 3] : second;
  return label.charAt(0).toUpperCase() + label.slice(1);
}

function pickName({ manifest, meta, title, hostname }) {
  const candidates = [
    manifest?.short_name,
    meta['application-name'],
    meta['apple-mobile-web-app-title'],
    meta['og:site_name'],
    manifest?.name,
  ];
  for (const c of candidates) {
    if (typeof c === 'string' && c.trim() && [...c.trim()].length <= 30) return c.trim();
  }
  if (title) {
    const parts = title.split(/\s+[-–—|·•:]\s+/).map((s) => s.trim()).filter(Boolean);
    const short = parts.filter((p) => [...p].length >= 2 && [...p].length <= 24).sort((a, b) => a.length - b.length)[0];
    if (short) return short;
  }
  return brandFromHost(hostname);
}

function sniffImage(buf, contentType) {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.toString('ascii', 0, 4) === 'GIF8') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  if (buf[0] === 0 && buf[1] === 0 && buf[2] === 1 && buf[3] === 0) return 'image/x-icon';
  const head = buf.toString('utf8', 0, Math.min(buf.length, 2048)).toLowerCase();
  if (head.includes('<svg') || contentType.includes('svg')) return head.includes('<svg') ? 'image/svg+xml' : null;
  return null;
}

/** @param {URL} target */
export async function readSite(target, { timeoutMs = 9000, rasterOnly = false } = {}) {
  const deadline = Date.now() + timeoutMs;
  const page = await safeFetch(target, {
    maxBytes: 700 * 1024,
    accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5',
    deadline,
  });
  const html = page.body.toString('utf8');
  const baseUrl = page.url;

  const titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  let title = '';
  if (titleMatch) {
    try {
      title = decodeEntities(titleMatch[1]).replace(/\s+/g, ' ').trim();
    } catch {
      title = titleMatch[1].replace(/\s+/g, ' ').trim();
    }
  }

  const meta = {};
  for (const tag of parseTags(html, 'meta')) {
    const key = (tag.name || tag.property || '').toLowerCase();
    if (key && tag.content && !(key in meta)) meta[key] = tag.content;
  }

  const candidates = [];
  let manifestHref = null;
  for (const tag of parseTags(html, 'link')) {
    if (!tag.href) continue;
    const rel = (tag.rel || '').toLowerCase().split(/\s+/);
    if (rel.includes('manifest') && !manifestHref) manifestHref = tag.href;
    const isSvg = /\.svg(\?|$)/i.test(tag.href) || (tag.type || '').includes('svg');
    if (rel.includes('apple-touch-icon') || rel.includes('apple-touch-icon-precomposed')) {
      candidates.push({ href: tag.href, size: sizeOf(tag.sizes) || 180, source: 'apple-touch-icon', base: baseUrl });
    } else if (rel.includes('icon')) {
      candidates.push({ href: tag.href, size: sizeOf(tag.sizes) || (isSvg ? 256 : 32), source: 'favicon', base: baseUrl });
    }
  }

  let manifest = null;
  if (manifestHref) {
    try {
      const manifestUrl = new URL(manifestHref, baseUrl);
      const m = await safeFetch(manifestUrl, { maxBytes: 300 * 1024, accept: 'application/manifest+json,application/json,*/*', deadline });
      if (m.ok && !m.truncated) {
        manifest = JSON.parse(m.body.toString('utf8').replace(/^\uFEFF/, ''));
        for (const icon of Array.isArray(manifest.icons) ? manifest.icons : []) {
          if (!icon || typeof icon.src !== 'string') continue;
          const maskableOnly = typeof icon.purpose === 'string' && !/\bany\b/.test(icon.purpose) && /maskable|monochrome/.test(icon.purpose);
          if (/monochrome/.test(icon.purpose || '') && !/any|maskable/.test(icon.purpose)) continue;
          candidates.push({
            href: icon.src,
            size: (sizeOf(icon.sizes) || 192) + (maskableOnly ? 0 : 1),
            source: 'manifest',
            base: manifestUrl,
          });
        }
      }
    } catch {
      manifest = null;
    }
  }

  // Prefer the largest icon up to 512px; anything bigger is just more bytes.
  candidates.sort((a, b) => Math.min(b.size, 513) - Math.min(a.size, 513));
  const queue = candidates.slice(0, 3);
  queue.push({ href: '/favicon.ico', size: 16, source: 'favicon', base: baseUrl });

  let icon = null;
  let iconSource = null;
  const tried = new Set();
  for (const candidate of queue) {
    if (deadline - Date.now() < 400) break;
    try {
      const iconUrl = new URL(candidate.href, candidate.base);
      if (iconUrl.protocol === 'data:' || tried.has(iconUrl.href)) continue;
      tried.add(iconUrl.href);
      const img = await safeFetch(iconUrl, { maxBytes: 1536 * 1024, accept: 'image/*,*/*;q=0.5', deadline });
      if (!img.ok || img.truncated) continue;
      const mime = sniffImage(img.body, img.contentType);
      if (!mime) continue;
      if (rasterOnly && mime !== 'image/png' && mime !== 'image/jpeg') continue;
      icon = `data:${mime};base64,${img.body.toString('base64')}`;
      iconSource = candidate.source;
      break;
    } catch {
      // try the next candidate
    }
  }

  const hostname = target.hostname.replace(/^www\./, '');
  const orientation = typeof manifest?.orientation === 'string' ? manifest.orientation : '';
  return {
    url: baseUrl.toString(),
    reachable: page.ok,
    status: page.status,
    name: pickName({ manifest, meta, title, hostname }),
    title,
    description: (meta.description || meta['og:description'] || '').slice(0, 200),
    themeColor: normaliseColor(manifest?.theme_color) || normaliseColor(meta['theme-color']),
    backgroundColor: normaliseColor(manifest?.background_color),
    orientation: orientation.startsWith('portrait') ? 'portrait' : orientation.startsWith('landscape') ? 'landscape' : null,
    hasManifest: Boolean(manifest),
    icon,
    iconSource,
  };
}
