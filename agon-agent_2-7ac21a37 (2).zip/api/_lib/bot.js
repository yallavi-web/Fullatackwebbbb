// The Telegram bot: a step-by-step APK builder with Back / Next buttons that
// runs on the same build pipeline, database and storage as the website.
import crypto from 'node:crypto';
import { BUCKET, ICON_FILES, Invalid, createBuildFor, deleteBuildFor, normalizeTelegramHandle } from './service.js';
import { ownerHash } from './keystore.js';
import { parseShareCode, telegramWorkspaceKey } from './secret.js';
import { readSite } from './site.js';
import { decodeImage, renderIconLayers } from './image.js';

const STEPS = ['url', 'name', 'icon', 'package', 'version', 'color', 'options', 'telegram', 'review'];
const TITLES = {
  url: 'Website',
  name: 'App name',
  icon: 'Icon',
  package: 'Package ID',
  version: 'Version',
  color: 'Theme colour',
  options: 'Options',
  telegram: 'Telegram button',
  review: 'Review',
};
const FLAGS = [
  ['splash', 'Splash screen'],
  ['fullscreen', 'Fullscreen'],
  ['navBar', 'Navigation bar'],
  ['keepScreenOn', 'Keep screen on'],
  ['zoom', 'Pinch to zoom'],
  ['confirmExit', 'Confirm exit'],
  ['blockScreenshots', 'Block screenshots'],
  ['camera', 'Camera'],
  ['microphone', 'Microphone'],
  ['location', 'Location'],
];
const ORIENTATIONS = ['auto', 'portrait', 'landscape'];
const PACKAGE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
const VERSION = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,23}$/;
const MAX_IMAGE = 5 * 1024 * 1024;

export const COMMANDS = [
  { command: 'new', description: 'Build a new app' },
  { command: 'builds', description: 'My apps' },
  { command: 'status', description: 'My plan and trial' },
  { command: 'cancel', description: 'Cancel the current setup' },
  { command: 'help', description: 'How it works' },
];

const MENU = [
  [
    { text: '🔨 New app', callback_data: 'm:new' },
    { text: '📦 My apps', callback_data: 'm:apps' },
  ],
  [
    { text: '⏳ My plan', callback_data: 'm:plan' },
    { text: '❓ Help', callback_data: 'm:help' },
  ],
];
const BACK_TO_MENU = [[{ text: '⬅ Menu', callback_data: 'm:menu' }]];

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const kb = (n) => (n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(2)} MB`);

function timeLeft(ms) {
  const minutes = Math.max(1, Math.round(ms / 60000));
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours} h ${minutes % 60} min`;
  return `${Math.floor(hours / 24)} days`;
}

const dateText = (d) =>
  `${new Date(d).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'UTC' })} UTC`;

// ------------------------------------------------------------------ access

/** Who may build right now: blocked → pending approval → unlimited → paid → free trial → expired. */
export function accessOf(user, settings, now = Date.now()) {
  if (user.status === 'blocked') return { ok: false, reason: 'blocked' };
  if (settings.access.botAccess === 'approved' && !user.approved) return { ok: false, reason: 'pending' };
  if (user.unlimited) return { ok: true, kind: 'unlimited' };
  const until = user.access_until ? new Date(user.access_until).getTime() : 0;
  if (until > now) return { ok: true, kind: 'paid', until };
  const trialEnd = new Date(user.trial_started_at || 0).getTime() + settings.access.trialHours * 3600000;
  if (trialEnd > now) return { ok: true, kind: 'trial', until: trialEnd };
  return { ok: false, reason: 'expired' };
}

function contactLine(settings) {
  return settings.access.contact ? `Message @${esc(settings.access.contact)} to continue.` : 'Contact the admin to continue.';
}

function planText(user, settings) {
  const a = accessOf(user, settings);
  if (a.reason === 'blocked') return '⛔ Your access to this bot is blocked.';
  if (a.reason === 'pending') return `🕓 Your account is waiting for approval. ${contactLine(settings)}`;
  if (a.reason === 'expired') return `⌛ Your free trial has ended. ${contactLine(settings)}`;
  if (a.kind === 'unlimited') return '✅ You have unlimited access.';
  if (a.kind === 'paid') return `✅ Access until ${dateText(a.until)} (${timeLeft(a.until - Date.now())} left).`;
  return `🎁 Free trial: ${timeLeft(a.until - Date.now())} left (ends ${dateText(a.until)}).`;
}

// --------------------------------------------------------------- messaging

const send = (ctx, chatId, text, keyboard) =>
  ctx.tg.call('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    link_preview_options: { is_disabled: true },
    ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
  });

/** Edits the message the button belongs to, or sends a new one when that isn't possible. */
async function show(ctx, chatId, messageId, text, keyboard) {
  if (messageId) {
    try {
      await ctx.tg.call('editMessageText', {
        chat_id: chatId,
        message_id: messageId,
        text,
        parse_mode: 'HTML',
        link_preview_options: { is_disabled: true },
        reply_markup: { inline_keyboard: keyboard || [] },
      });
      return;
    } catch (err) {
      if (/not modified/i.test(err?.message || '')) return;
    }
  }
  await send(ctx, chatId, text, keyboard);
}

// ------------------------------------------------------------------ follow

function followRows(ctx) {
  const f = ctx.settings.follow || {};
  const rows = [];
  if (f.channel) rows.push([{ text: `📣 Join @${f.channel}`, url: `https://t.me/${f.channel}` }]);
  for (const link of f.links || []) rows.push([{ text: `🔗 ${link.label}`, url: link.url }]);
  return rows;
}

const followGate = (ctx) => [
  [{ text: `📣 Join @${ctx.settings.follow.channel}`, url: `https://t.me/${ctx.settings.follow.channel}` }],
  [{ text: '✅ I’ve joined', callback_data: 'fj' }],
];

/** True when no channel is required, or Telegram confirms this person is in it. */
async function hasJoined(ctx, user) {
  const f = ctx.settings.follow || {};
  if (!f.required || !f.channel) return true;
  try {
    const member = await ctx.tg.call('getChatMember', { chat_id: `@${f.channel}`, user_id: user.id });
    return ['creator', 'administrator', 'member'].includes(member.status) || (member.status === 'restricted' && member.is_member === true);
  } catch (err) {
    // The bot can no longer see the channel (e.g. it was removed as admin): don't lock everyone out.
    console.error('follow check failed:', err?.message || err);
    return true;
  }
}

const askToFollow = (ctx, user, messageId) =>
  show(
    ctx,
    user.chat_id,
    messageId,
    `📣 <b>One step first</b>\n\nJoin @${esc(ctx.settings.follow.channel)} to build apps with this bot, then tap “I’ve joined”.`,
    followGate(ctx),
  );

// ------------------------------------------------------------------- users

async function loadUser(ctx, from, chatId, updateId) {
  const { supabase, settings } = ctx;
  const now = new Date().toISOString();
  const profile = settings.privacy.storeProfiles
    ? { username: from.username || null, first_name: String(from.first_name || '').slice(0, 64) || null }
    : { username: null, first_name: null };

  const existing = await supabase.from('tg_users').select('*').eq('id', from.id).maybeSingle();
  if (existing.error) throw existing.error;
  if (existing.data) {
    // Telegram re-sends an update when the webhook did not answer; never handle it twice.
    if (Number(existing.data.last_update_id) === updateId) return { user: null, isNew: false };
    const { data, error } = await supabase
      .from('tg_users')
      .update({ chat_id: chatId, ...profile, last_seen_at: now, last_update_id: updateId })
      .eq('id', from.id)
      .select()
      .single();
    if (error) throw error;
    return { user: data, isNew: false };
  }

  const { data, error } = await supabase
    .from('tg_users')
    .insert({
      id: from.id,
      chat_id: chatId,
      ...profile,
      status: 'active',
      approved: false,
      unlimited: false,
      trial_started_at: now, // the free trial starts with the first message
      access_until: null,
      builds_count: 0,
      state: null,
      owner_hash: ownerHash(telegramWorkspaceKey(from.id)),
      last_update_id: updateId,
      created_at: now,
      last_seen_at: now,
    })
    .select()
    .single();
  if (error) throw error;
  return { user: data, isNew: true };
}

async function saveState(ctx, user, state) {
  user.state = state;
  const { error } = await ctx.supabase.from('tg_users').update({ state }).eq('id', user.id);
  if (error) throw error;
}

// ------------------------------------------------------------ draft helpers

const newDraft = () => ({
  url: '',
  name: '',
  packageName: '',
  versionName: '1.0.0',
  versionCode: 1,
  themeColor: '#22C36F',
  backgroundColor: '#FFFFFF',
  orientation: 'auto',
  splash: true,
  fullscreen: false,
  navBar: false,
  keepScreenOn: false,
  zoom: false,
  confirmExit: false,
  blockScreenshots: false,
  camera: false,
  microphone: false,
  location: false,
  telegram: '',
  icon: 'default', // default | site | photo | kept
  iconPath: '',
  siteIconPath: '',
  fromBuild: null,
  siteReached: true,
});

function normalizeUrl(input) {
  let value = String(input || '').trim();
  if (!value || /\s/.test(value)) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) value = `https://${value}`;
  try {
    const url = new URL(value);
    if ((url.protocol !== 'http:' && url.protocol !== 'https:') || !url.hostname.includes('.')) return null;
    return url.toString();
  } catch {
    return null;
  }
}

function suggestPackage(url) {
  const parts = new URL(url).hostname
    .replace(/^www\./, '')
    .split('.')
    .filter(Boolean)
    .reverse()
    .map((segment) => {
      const s = segment.toLowerCase().replace(/[^a-z0-9_]/g, '_');
      return /^[a-z]/.test(s) ? s : `x${s}`;
    });
  if (parts.length < 2) parts.unshift('app');
  return [...parts, 'webapp'].join('.').slice(0, 100);
}

function brandFromHost(hostname) {
  const parts = hostname.replace(/^www\./, '').split('.').filter(Boolean);
  const tld = parts[parts.length - 1] || '';
  const second = parts[parts.length - 2] || hostname;
  const label = tld.length === 2 && second.length <= 3 && parts.length >= 3 ? parts[parts.length - 3] : second;
  return cap(label);
}

async function storeDraftIcons(ctx, user, layers) {
  const prefix = `drafts/${user.id}/${crypto.randomBytes(6).toString('hex')}`;
  const bucket = ctx.supabase.storage.from(BUCKET);
  const results = await Promise.all(
    Object.entries(ICON_FILES).map(([key, file]) =>
      bucket.upload(`${prefix}/${file}`, layers[key], { contentType: 'image/png', upsert: true }),
    ),
  );
  const failed = results.find((r) => r.error);
  if (failed) throw failed.error;
  return prefix;
}

async function loadDraftIcons(ctx, prefix) {
  const bucket = ctx.supabase.storage.from(BUCKET);
  const icons = {};
  for (const [key, file] of Object.entries(ICON_FILES)) {
    const res = await bucket.download(`${prefix}/${file}`);
    if (res.error || !res.data) throw new Invalid('icon', 'Your icon is no longer available — go back and choose it again.');
    icons[key] = Buffer.from(await res.data.arrayBuffer());
  }
  return icons;
}

async function dropDraftIcons(ctx, ...prefixes) {
  const paths = prefixes.filter(Boolean).flatMap((p) => Object.values(ICON_FILES).map((f) => `${p}/${f}`));
  if (!paths.length) return;
  try {
    await ctx.supabase.storage.from(BUCKET).remove(paths);
  } catch {
    // Draft files are disposable; a failed clean-up must not break the chat.
  }
}

// ------------------------------------------------------------- wizard views

const iconLabel = (d) =>
  ({ default: 'default icon in your theme colour', site: "the website's own icon", photo: 'your photo', kept: 'icon from the previous version' })[d.icon];

function navRows(step, d) {
  const i = STEPS.indexOf(step);
  const first = [];
  if (i > 0) first.push({ text: '⬅ Back', callback_data: 'w:back' });
  if (step !== 'review' && (step !== 'url' || d.url)) first.push({ text: 'Next ➡', callback_data: 'w:next' });
  const last = [];
  if (d.url && step !== 'url' && step !== 'review') last.push({ text: '⏭ Review & build', callback_data: 'w:review' });
  last.push({ text: '✖ Cancel', callback_data: 'w:cancel' });
  return [first, last].filter((row) => row.length);
}

function reviewText(d) {
  const on = FLAGS.filter(([key]) => d[key]).map(([, label]) => label);
  return [
    `🌐 ${esc(d.url)}`,
    `📛 Name: <b>${esc(d.name)}</b>`,
    `📦 Package: <code>${esc(d.packageName)}</code>`,
    `🔢 Version: ${esc(d.versionName)} (build ${d.versionCode})`,
    `🖼 Icon: ${iconLabel(d)}`,
    `🎨 Theme colour: <code>${d.themeColor}</code>`,
    `📐 Orientation: ${cap(d.orientation)}`,
    `⚙️ Switched on: ${on.length ? on.join(', ') : 'nothing extra'}`,
    `✈️ Telegram button: ${d.telegram ? esc(`t.me/${d.telegram}`) : 'none'}`,
  ].join('\n');
}

function stepView(state, note = '') {
  const { step, draft: d } = state;
  const head = `${note ? `${note}\n\n` : ''}<b>Step ${STEPS.indexOf(step) + 1} of ${STEPS.length} · ${TITLES[step]}</b>\n\n`;
  const rows = [];
  let body = '';
  if (step === 'url') {
    body = d.url
      ? `Current: ${esc(d.url)}\n\nSend a different website address, or tap Next.`
      : 'Send the website address your app should open, for example <code>example.com</code>';
  } else if (step === 'name') {
    body =
      `${d.siteReached ? '' : 'I could not read that website, so these details are a best guess. You can still build.\n\n'}` +
      `Current: <b>${esc(d.name)}</b>\n\nSend a new name (up to 40 characters), or tap Next to keep it.`;
  } else if (step === 'icon') {
    body = `Current: ${iconLabel(d)}.\n\nSend a photo (or a PNG/JPG file) to use it as the app icon, or choose below.`;
    const choice = [];
    if (d.siteIconPath) choice.push({ text: `${d.icon === 'site' ? '✅ ' : ''}🌐 Website icon`, callback_data: 'w:ic:site' });
    choice.push({ text: `${d.icon === 'default' ? '✅ ' : ''}🎨 Default icon`, callback_data: 'w:ic:def' });
    rows.push(choice);
  } else if (step === 'package') {
    body =
      `Current: <code>${esc(d.packageName)}</code>\n\nThis is the app's unique ID on the phone. ` +
      `${d.fromBuild ? 'Keep it the same so the new version installs over the old one. ' : ''}` +
      'Send a new one like <code>com.example.app</code>, or tap Next.';
  } else if (step === 'version') {
    body = `Current: <b>${esc(d.versionName)}</b> (build ${d.versionCode})\n\nSend a new version like <code>1.2.0</code>, or tap Next.`;
  } else if (step === 'color') {
    body = `Current: <code>${d.themeColor}</code>\n\nUsed for the status bar and loading bar. Send a hex colour like <code>#FF6600</code>, or tap Next.`;
  } else if (step === 'options') {
    body = 'Tap an option to switch it on or off. Camera, microphone and location are only requested if you switch them on.';
    for (let i = 0; i < FLAGS.length; i += 2) {
      rows.push(FLAGS.slice(i, i + 2).map(([key, label]) => ({ text: `${d[key] ? '✅' : '⬜'} ${label}`, callback_data: `w:t:${key}` })));
    }
    rows.push([{ text: `🔄 Orientation: ${cap(d.orientation)}`, callback_data: 'w:o' }]);
  } else if (step === 'telegram') {
    body =
      `Current: ${d.telegram ? esc(`t.me/${d.telegram}`) : 'no button'}\n\n` +
      'Optional: add a floating button inside the app that opens your Telegram channel or chat. Send <code>@yourchannel</code>, or tap Next.';
    if (d.telegram) rows.push([{ text: '🚫 No button', callback_data: 'w:tg:none' }]);
  } else {
    body = `${reviewText(d)}\n\nReady? Tap Build APK.`;
    rows.push([{ text: '🔨 Build APK', callback_data: 'w:build' }]);
  }
  return { text: head + body, keyboard: [...rows, ...navRows(step, d)] };
}

function denial(ctx, user) {
  return planText(user, ctx.settings);
}

// --------------------------------------------------------------- wizard flow

async function clearWizard(ctx, user) {
  const d = user.state?.draft;
  if (d) await dropDraftIcons(ctx, d.iconPath, d.siteIconPath);
  await saveState(ctx, user, null);
}

async function startWizard(ctx, user, messageId, urlText) {
  if (!accessOf(user, ctx.settings).ok) return show(ctx, user.chat_id, messageId, denial(ctx, user), BACK_TO_MENU);
  if (!(await hasJoined(ctx, user))) return askToFollow(ctx, user, messageId);
  if (user.state?.draft) await dropDraftIcons(ctx, user.state.draft.iconPath, user.state.draft.siteIconPath);
  user.state = { step: 'url', draft: newDraft(), at: Date.now() };
  if (urlText) return onWizardInput(ctx, user, { text: urlText });
  await saveState(ctx, user, user.state);
  const view = stepView(user.state);
  return show(ctx, user.chat_id, messageId, view.text, view.keyboard);
}

/** Reads the website and pre-fills name, package ID, colours and (when it is a PNG/JPG) the icon. */
async function applySite(ctx, user, d, url) {
  const host = new URL(url).hostname;
  let info = null;
  try {
    info = await (ctx.readSite || readSite)(new URL(url), { timeoutMs: 5000, rasterOnly: true });
  } catch {
    info = null;
  }
  await dropDraftIcons(ctx, d.iconPath, d.siteIconPath);
  const name = String(info?.name || brandFromHost(host)).replace(/[\u0000-\u001f]+/g, ' ').trim();
  Object.assign(d, {
    url,
    name: [...name].slice(0, 40).join('') || 'My App',
    packageName: suggestPackage(url),
    themeColor: info?.themeColor || '#22C36F',
    backgroundColor: info?.backgroundColor || '#FFFFFF',
    orientation: info?.orientation || 'auto',
    icon: 'default',
    iconPath: '',
    siteIconPath: '',
    fromBuild: null,
    versionCode: 1,
    siteReached: Boolean(info),
  });
  if (info?.icon) {
    try {
      const raw = Buffer.from(info.icon.slice(info.icon.indexOf(',') + 1), 'base64');
      d.siteIconPath = await storeDraftIcons(ctx, user, renderIconLayers(decodeImage(raw)));
      d.icon = 'site';
    } catch {
      // The default icon stays selected.
    }
  }
}

function pickImage(msg) {
  if (Array.isArray(msg.photo) && msg.photo.length) {
    const sizes = [...msg.photo].sort((a, b) => b.width - a.width);
    return (sizes.find((p) => Math.max(p.width, p.height) <= 1280) || sizes[sizes.length - 1]).file_id;
  }
  const doc = msg.document;
  if (doc && /^image\/(png|jpeg)$/.test(doc.mime_type || '') && (doc.file_size || 0) <= MAX_IMAGE) return doc.file_id;
  return null;
}

async function onWizardInput(ctx, user, msg) {
  const state = user.state;
  const d = state.draft;
  const chatId = user.chat_id;
  const text = String(msg.text || '').trim();
  const fail = (message) => send(ctx, chatId, message);
  let note = '';

  if (state.step === 'url') {
    const url = normalizeUrl(text);
    if (!url) return fail('That doesn’t look like a website address. Send something like <code>example.com</code>');
    await ctx.tg.call('sendChatAction', { chat_id: chatId, action: 'typing' }).catch(() => {});
    await applySite(ctx, user, d, url);
  } else if (state.step === 'name') {
    if (!text) return fail('Send the app name as text, or tap Next.');
    if ([...text].length > 40) return fail('Keep the app name under 40 characters.');
    d.name = text.replace(/[\u0000-\u001f]+/g, ' ').trim();
  } else if (state.step === 'icon') {
    const fileId = pickImage(msg);
    if (!fileId) return fail('Send a photo or a PNG/JPG file to use as the icon, or use the buttons above.');
    let layers;
    try {
      layers = renderIconLayers(decodeImage(await ctx.tg.downloadFile(fileId, MAX_IMAGE)));
    } catch {
      return fail('That image could not be used. Try another photo (PNG or JPG).');
    }
    const prefix = await storeDraftIcons(ctx, user, layers);
    await dropDraftIcons(ctx, d.iconPath);
    d.iconPath = prefix;
    d.icon = 'photo';
    note = '✅ Icon updated.';
  } else if (state.step === 'package') {
    const id = text.toLowerCase();
    if (!PACKAGE.test(id) || id.length > 100) {
      return fail('Use lowercase letters, digits and dots, with at least two parts — for example <code>com.example.app</code>');
    }
    d.packageName = id;
  } else if (state.step === 'version') {
    if (!VERSION.test(text)) return fail('Use up to 24 letters, digits or dots, for example <code>1.2.0</code>');
    d.versionName = text;
  } else if (state.step === 'color') {
    let hex = text.replace(/^#/, '');
    if (/^[0-9a-fA-F]{3}$/.test(hex)) hex = [...hex].map((c) => c + c).join('');
    if (!/^[0-9a-fA-F]{6}$/.test(hex)) return fail('Send a hex colour like <code>#FF6600</code>');
    d.themeColor = `#${hex.toUpperCase()}`;
  } else if (state.step === 'options') {
    return fail('Use the buttons above to switch options on or off, then tap Next.');
  } else if (state.step === 'telegram') {
    const handle = normalizeTelegramHandle(text);
    if (!handle) return fail('Send a Telegram username or link like <code>@yourchannel</code>, or tap Next to skip.');
    d.telegram = handle;
  } else {
    return fail('Tap “Build APK” above, or Back to change something.');
  }

  state.step = STEPS[Math.min(STEPS.indexOf(state.step) + 1, STEPS.length - 1)];
  state.at = Date.now();
  await saveState(ctx, user, state);
  const view = stepView(state, note);
  return send(ctx, chatId, view.text, view.keyboard);
}

async function onWizardButton(ctx, user, action, messageId) {
  const state = user.state;
  const chatId = user.chat_id;
  if (!state?.step) return show(ctx, chatId, messageId, 'This setup has ended. Start a new one any time.', MENU);
  if (action === 'build') return doBuild(ctx, user, messageId);
  if (state.step === 'building') return undefined;
  const d = state.draft;
  const i = STEPS.indexOf(state.step);

  if (action === 'cancel') {
    await clearWizard(ctx, user);
    return show(ctx, chatId, messageId, 'Cancelled — nothing was built.', MENU);
  }
  if (action === 'next') {
    if (state.step !== 'url' || d.url) state.step = STEPS[Math.min(i + 1, STEPS.length - 1)];
  } else if (action === 'back') {
    state.step = STEPS[Math.max(i - 1, 0)];
  } else if (action === 'review') {
    if (d.url) state.step = 'review';
  } else if (action === 'o') {
    d.orientation = ORIENTATIONS[(ORIENTATIONS.indexOf(d.orientation) + 1) % ORIENTATIONS.length];
  } else if (action === 'ic:site') {
    if (d.siteIconPath) d.icon = 'site';
  } else if (action === 'ic:def') {
    d.icon = 'default';
  } else if (action === 'tg:none') {
    d.telegram = '';
  } else if (action.startsWith('t:')) {
    const flag = action.slice(2);
    if (FLAGS.some(([key]) => key === flag)) d[flag] = !d[flag];
  }
  state.at = Date.now();
  await saveState(ctx, user, state);
  const view = stepView(state);
  return show(ctx, chatId, messageId, view.text, view.keyboard);
}

// --------------------------------------------------------- build and install

const INSTALL_GUIDE = [
  '<b>How to install</b>',
  '',
  '1. Tap the APK file in this chat, then tap Open or Install.',
  '2. If Android asks, allow Telegram to install unknown apps, go back and tap Install again.',
  '3. If Play Protect says it doesn’t recognise the developer, choose “Install anyway”.',
  '4. To update later, build a new version and install it over the old one — your app data is kept.',
].join('\n');

const afterBuildKeyboard = (build) => [
  [
    { text: '📲 How to install', callback_data: 'guide' },
    { text: '⬇ Download link', url: build.apk_url },
  ],
  [
    { text: '🔁 New version', callback_data: `bn:${build.id}` },
    { text: '📦 My apps', callback_data: 'm:apps' },
  ],
];

async function sendApk(ctx, chatId, row, apk, lead) {
  const caption = `${lead} <b>${esc(row.app_name)}</b> v${esc(row.version_name)}\n<code>${esc(row.package_name)}</code> · ${kb(row.apk_size)}\n\nTap the file to install it on this phone.`;
  let bytes = apk;
  try {
    if (!bytes) {
      const res = await ctx.supabase.storage.from(BUCKET).download(`${row.storage_prefix}/app.apk`);
      if (res.error || !res.data) throw new Error('missing');
      bytes = Buffer.from(await res.data.arrayBuffer());
    }
    await ctx.tg.sendDocument(chatId, bytes, row.file_name, { caption, keyboard: afterBuildKeyboard(row) });
  } catch {
    // The build exists even if the upload to Telegram failed: hand over the link.
    await send(ctx, chatId, `${caption}\n\nThe file could not be attached, so here is the download link:\n${esc(row.apk_url)}`, afterBuildKeyboard(row));
  }
}

async function doBuild(ctx, user, messageId) {
  const chatId = user.chat_id;
  const state = user.state;
  if (!state?.draft) return show(ctx, chatId, messageId, 'This setup has ended. Start a new one any time.', MENU);
  if (!accessOf(user, ctx.settings).ok) return show(ctx, chatId, messageId, denial(ctx, user), BACK_TO_MENU);
  if (state.step === 'review' && !(await hasJoined(ctx, user))) return askToFollow(ctx, user, messageId);
  // A build that has been "running" for two minutes was interrupted; let it be retried.
  const stale = state.step === 'building' && Date.now() - (state.at || 0) > 120000;
  if (state.step !== 'review' && !stale) return undefined;

  // Claim the build so a double tap cannot start two.
  const building = { ...state, step: 'building', at: Date.now() };
  const claim = await ctx.supabase
    .from('tg_users')
    .update({ state: building })
    .eq('id', user.id)
    .eq('state->>step', state.step)
    .select('id');
  if (claim.error) throw claim.error;
  if (!claim.data?.length) return undefined;
  user.state = building;

  const d = state.draft;
  await show(ctx, chatId, messageId, `🔨 Building <b>${esc(d.name)}</b>…`, []);
  await ctx.tg.call('sendChatAction', { chat_id: chatId, action: 'upload_document' }).catch(() => {});

  try {
    const icons = d.icon === 'photo' ? await loadDraftIcons(ctx, d.iconPath) : d.icon === 'site' ? await loadDraftIcons(ctx, d.siteIconPath) : undefined;
    const body = {
      name: d.name,
      url: d.url,
      packageName: d.packageName,
      versionName: d.versionName,
      versionCode: d.versionCode,
      themeColor: d.themeColor,
      backgroundColor: d.backgroundColor,
      orientation: d.orientation,
      telegram: d.telegram,
      ...Object.fromEntries(FLAGS.map(([key]) => [key, d[key] === true])),
      ...(d.icon === 'kept' ? { iconsFromBuild: d.fromBuild } : {}),
    };
    const result = await createBuildFor(ctx.supabase, telegramWorkspaceKey(user.id), body, { icons });
    await ctx.supabase.from('tg_users').update({ state: null, builds_count: (user.builds_count || 0) + 1 }).eq('id', user.id);
    user.state = null;
    await dropDraftIcons(ctx, d.iconPath, d.siteIconPath);
    await show(ctx, chatId, messageId, `✅ <b>${esc(d.name)}</b> v${esc(d.versionName)} is built. The APK is below.`, []);
    await sendApk(ctx, chatId, result.row, result.apk, '✅');
  } catch (err) {
    await saveState(ctx, user, { ...state, step: 'review', at: Date.now() });
    const reason = err instanceof Invalid ? esc(err.message) : 'Something went wrong while building. Please try again in a moment.';
    if (!(err instanceof Invalid)) console.error('bot build failed:', err?.message || err);
    const view = stepView(user.state, `⚠️ ${reason}`);
    await send(ctx, chatId, view.text, view.keyboard);
  }
  return undefined;
}

async function ownBuild(ctx, user, id) {
  const { data, error } = await ctx.supabase.from('builds').select('*').eq('id', id).eq('owner_hash', user.owner_hash).maybeSingle();
  if (error) throw error;
  return data;
}

async function showApps(ctx, user, messageId) {
  const { data, error } = await ctx.supabase
    .from('builds')
    .select('*')
    .eq('owner_hash', user.owner_hash)
    .order('created_at', { ascending: false })
    .limit(8);
  if (error) throw error;
  if (!data.length) {
    return show(ctx, user.chat_id, messageId, 'You haven’t built any apps yet.', [[{ text: '🔨 New app', callback_data: 'm:new' }], ...BACK_TO_MENU]);
  }
  const rows = data.map((b) => [{ text: `${b.app_name} · v${b.version_name}`.slice(0, 60), callback_data: `b:${b.id}` }]);
  return show(ctx, user.chat_id, messageId, '<b>My apps</b>\n\nPick one to install it again, build a new version or delete it.', [...rows, ...BACK_TO_MENU]);
}

async function onBuildButton(ctx, user, action, id, messageId) {
  const chatId = user.chat_id;
  const row = await ownBuild(ctx, user, id);
  if (!row) return show(ctx, chatId, messageId, 'That app is no longer stored.', [[{ text: '📦 My apps', callback_data: 'm:apps' }]]);

  if (action === 'b') {
    const text = `<b>${esc(row.app_name)}</b> v${esc(row.version_name)} (build ${row.version_code})\n<code>${esc(row.package_name)}</code>\n${esc(row.url)}\n${kb(row.apk_size)} · built ${dateText(row.created_at)}`;
    return show(ctx, chatId, messageId, text, [
      [
        { text: '📲 Send APK', callback_data: `bs:${row.id}` },
        { text: '🔁 New version', callback_data: `bn:${row.id}` },
      ],
      [
        { text: '🗑 Delete', callback_data: `bd:${row.id}` },
        { text: '⬅ Back', callback_data: 'm:apps' },
      ],
    ]);
  }
  if (action === 'bs') {
    await ctx.tg.call('sendChatAction', { chat_id: chatId, action: 'upload_document' }).catch(() => {});
    return sendApk(ctx, chatId, row, null, '📦');
  }
  if (action === 'bd') {
    return show(ctx, chatId, messageId, `Delete <b>${esc(row.app_name)}</b> v${esc(row.version_name)}? The stored APK is removed for good.`, [
      [
        { text: '🗑 Yes, delete', callback_data: `bdy:${row.id}` },
        { text: 'Keep', callback_data: `b:${row.id}` },
      ],
    ]);
  }
  if (action === 'bdy') {
    await deleteBuildFor(ctx.supabase, user.owner_hash, row.id);
    return showApps(ctx, user, messageId);
  }
  if (action === 'bn') {
    if (!accessOf(user, ctx.settings).ok) return show(ctx, chatId, messageId, denial(ctx, user), BACK_TO_MENU);
    if (!(await hasJoined(ctx, user))) return askToFollow(ctx, user, messageId);
    if (user.state?.draft) await dropDraftIcons(ctx, user.state.draft.iconPath, user.state.draft.siteIconPath);
    const o = row.options || {};
    const draft = {
      ...newDraft(),
      ...Object.fromEntries(FLAGS.map(([key]) => [key, o[key] === true])),
      url: row.url,
      name: row.app_name,
      packageName: row.package_name,
      versionName: row.version_name,
      versionCode: row.version_code + 1,
      themeColor: row.theme_color,
      backgroundColor: row.background_color,
      orientation: ORIENTATIONS.includes(row.orientation) ? row.orientation : 'auto',
      telegram: o.telegram || '',
      icon: 'kept',
      fromBuild: row.id,
    };
    await saveState(ctx, user, { step: 'review', draft, at: Date.now() });
    const view = stepView(user.state, `🔁 New version of <b>${esc(row.app_name)}</b> — the build number was raised to ${draft.versionCode}. Use Back to change anything.`);
    return send(ctx, chatId, view.text, view.keyboard);
  }
  return undefined;
}

/** t.me/<bot>?start=<code> from the website: hand over that build as a file. */
async function deliverShared(ctx, user, buildId) {
  const { data, error } = await ctx.supabase.from('builds').select('*').eq('id', buildId).maybeSingle();
  if (error) throw error;
  if (!data) return send(ctx, user.chat_id, 'That app is no longer available — it may have been deleted.', MENU);
  await ctx.tg.call('sendChatAction', { chat_id: user.chat_id, action: 'upload_document' }).catch(() => {});
  return sendApk(ctx, user.chat_id, data, null, '📦');
}

// ------------------------------------------------------------------ routing

function welcomeText(ctx, user) {
  const { site, access } = ctx.settings;
  return [
    `<b>Welcome to ${esc(site.name)}</b> 👋`,
    '',
    'Turn any website into an Android app (APK) without leaving Telegram: send a link, set the name and icon, and install the file I send back.',
    ...(access.welcome ? ['', esc(access.welcome)] : []),
    '',
    planText(user, ctx.settings),
  ].join('\n');
}

const HELP = [
  '<b>How it works</b>',
  '',
  '1. Tap “New app” (or send /new) and send your website address.',
  '2. Go through the steps with Next and Back: name, icon, package ID, version, colour, options.',
  '3. Tap “Build APK”. The signed APK arrives in this chat — tap it to install.',
  '',
  '/new — build an app\n/builds — your apps\n/status — your plan\n/cancel — stop the current setup',
].join('\n');

async function onMessage(ctx, user, msg) {
  const chatId = user.chat_id;
  const access = accessOf(user, ctx.settings);
  if (access.reason === 'blocked' || access.reason === 'pending') return send(ctx, chatId, denial(ctx, user));

  const text = String(msg.text || '').trim();
  if (text.startsWith('/')) {
    const [raw, ...rest] = text.split(/\s+/);
    const command = raw.slice(1).split('@')[0].toLowerCase();
    if (command === 'start') {
      const shared = parseShareCode(rest[0]);
      if (shared) return deliverShared(ctx, user, shared);
      return send(ctx, chatId, welcomeText(ctx, user), [...MENU, ...followRows(ctx)]);
    }
    if (command === 'new' || command === 'build') return startWizard(ctx, user, undefined, rest[0]);
    if (command === 'builds' || command === 'apps') return showApps(ctx, user);
    if (command === 'status' || command === 'plan') return send(ctx, chatId, planText(user, ctx.settings), MENU);
    if (command === 'help') return send(ctx, chatId, HELP, MENU);
    if (command === 'cancel') {
      const had = Boolean(user.state?.step);
      await clearWizard(ctx, user);
      return send(ctx, chatId, had ? 'Cancelled — nothing was built.' : 'There is nothing to cancel.', MENU);
    }
    return send(ctx, chatId, 'I don’t know that command. Pick an option:', MENU);
  }

  if (user.state?.step === 'building') return send(ctx, chatId, 'Your app is being built — one moment.');
  if (user.state?.step) return onWizardInput(ctx, user, msg);
  if (normalizeUrl(text)) return startWizard(ctx, user, undefined, text);
  return send(ctx, chatId, 'Send a website address to turn it into an app, or pick an option:', MENU);
}

async function onButton(ctx, user, query) {
  const chatId = user.chat_id;
  const data = String(query.data || '');
  // Only text messages can be edited in place; buttons under an APK file get a new message.
  const messageId = typeof query.message?.text === 'string' ? query.message.message_id : undefined;
  const access = accessOf(user, ctx.settings);
  if (access.reason === 'blocked' || access.reason === 'pending') return show(ctx, chatId, messageId, denial(ctx, user), []);

  if (data === 'm:menu') return show(ctx, chatId, messageId, welcomeText(ctx, user), [...MENU, ...followRows(ctx)]);
  if (data === 'm:new') return startWizard(ctx, user, messageId);
  if (data === 'm:apps') return showApps(ctx, user, messageId);
  if (data === 'm:plan') return show(ctx, chatId, messageId, planText(user, ctx.settings), BACK_TO_MENU);
  if (data === 'm:help') return show(ctx, chatId, messageId, HELP, BACK_TO_MENU);
  if (data === 'guide') return send(ctx, chatId, INSTALL_GUIDE);
  if (data === 'fj') {
    if (!(await hasJoined(ctx, user))) {
      return send(ctx, chatId, `⚠️ I can’t see you in @${esc(ctx.settings.follow.channel)} yet. Join it, then tap “I’ve joined” again.`, followGate(ctx));
    }
    if (user.state?.step && user.state.step !== 'building') {
      const view = stepView(user.state, '✅ Thanks for joining!');
      return show(ctx, chatId, messageId, view.text, view.keyboard);
    }
    return show(ctx, chatId, messageId, '✅ Thanks for joining! You can build apps now.', MENU);
  }
  if (data.startsWith('w:')) return onWizardButton(ctx, user, data.slice(2), messageId);
  const m = /^(b|bs|bn|bd|bdy):(\d{1,12})$/.exec(data);
  if (m) return onBuildButton(ctx, user, m[1], Number(m[2]), messageId);
  return undefined;
}

/** Entry point for one Telegram update. ctx = { supabase, tg, settings }. */
export async function handleUpdate(ctx, update) {
  const query = update?.callback_query;
  const msg = update?.message;
  const from = query?.from || msg?.from;
  const chat = query?.message?.chat || msg?.chat;
  if (!from || from.is_bot || !chat) return;
  if (query) await ctx.tg.call('answerCallbackQuery', { callback_query_id: query.id }).catch(() => {});
  if (chat.type !== 'private') {
    if (msg?.text?.startsWith('/')) await send(ctx, chat.id, 'Please message me in a private chat to build apps.');
    return;
  }
  const { user } = await loadUser(ctx, from, chat.id, Number(update.update_id));
  if (!user) return;
  if (query) await onButton(ctx, user, query);
  else await onMessage(ctx, user, msg);
}
