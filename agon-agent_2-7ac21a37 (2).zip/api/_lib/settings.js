// Admin-editable settings, one row per group in app_settings.
import { Invalid } from './service.js';

export const DEFAULTS = {
  site: { name: 'Web2APK', tagline: '', logoUrl: '', logoPath: '' },
  access: { trialHours: 24, botAccess: 'open', webBuilder: true, apiKeys: true, contact: '', welcome: '' },
  privacy: { storeProfiles: true, retentionDays: 0, idleMinutes: 30 },
  follow: { channel: '', required: false, links: [] },
};

export async function loadSettings(supabase) {
  const { data, error } = await supabase.from('app_settings').select('key, value');
  if (error) throw error;
  const rows = Object.fromEntries((data || []).map((r) => [r.key, r.value || {}]));
  return {
    site: { ...DEFAULTS.site, ...rows.site },
    access: { ...DEFAULTS.access, ...rows.access },
    privacy: { ...DEFAULTS.privacy, ...rows.privacy },
    follow: { ...DEFAULTS.follow, ...rows.follow },
    bot: rows.bot && rows.bot.token ? rows.bot : null,
  };
}

export async function saveSetting(supabase, key, value) {
  const { error } = await supabase
    .from('app_settings')
    .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: 'key' });
  if (error) throw error;
}

export async function dropSetting(supabase, key) {
  const { error } = await supabase.from('app_settings').delete().eq('key', key);
  if (error) throw error;
}

const str = (v) => (typeof v === 'string' ? v.trim() : '');

function int(value, field, min, max, label) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new Invalid(field, `${label} must be a whole number from ${min} to ${max}`);
  }
  return n;
}

export function cleanSite(input, current) {
  const name = str(input?.name);
  if (!name) throw new Invalid('name', 'Give the site a name');
  if ([...name].length > 30) throw new Invalid('name', 'Keep the site name under 30 characters');
  const tagline = str(input?.tagline);
  if ([...tagline].length > 220) throw new Invalid('tagline', 'Keep the tagline under 220 characters');
  return { ...current, name, tagline };
}

export function cleanAccess(input) {
  let contact = str(input?.contact)
    .replace(/^(https?:\/\/)?(www\.)?(t|telegram)\.me\//i, '')
    .replace(/^@/, '');
  if (contact && !/^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(contact)) {
    throw new Invalid('contact', 'Enter a Telegram username like @yourname, or leave it empty');
  }
  const welcome = str(input?.welcome);
  if ([...welcome].length > 300) throw new Invalid('welcome', 'Keep the welcome message under 300 characters');
  return {
    trialHours: int(input?.trialHours, 'trialHours', 0, 720, 'Trial length'),
    botAccess: input?.botAccess === 'approved' ? 'approved' : 'open',
    webBuilder: input?.webBuilder !== false,
    apiKeys: input?.apiKeys !== false,
    contact,
    welcome,
  };
}

export function cleanPrivacy(input) {
  return {
    storeProfiles: input?.storeProfiles !== false,
    retentionDays: int(input?.retentionDays, 'retentionDays', 0, 365, 'Retention'),
    idleMinutes: int(input?.idleMinutes, 'idleMinutes', 5, 240, 'Auto-lock'),
  };
}

/** Follow system: one Telegram channel the bot can verify, plus up to 5 plain links. */
export function cleanFollow(input) {
  const channel = str(input?.channel)
    .replace(/^(https?:\/\/)?(www\.)?(t|telegram)\.me\//i, '')
    .replace(/^@/, '')
    .replace(/[/?#].*$/, '');
  if (channel && !/^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(channel)) {
    throw new Invalid('channel', 'Enter the public username of your channel or group, like @yourchannel');
  }
  const required = input?.required === true;
  if (required && !channel) throw new Invalid('channel', 'Add your Telegram channel before making it required');

  const raw = (Array.isArray(input?.links) ? input.links : []).filter((l) => str(l?.label) || str(l?.url));
  if (raw.length > 5) throw new Invalid('links', 'You can add up to 5 links');
  const links = raw.map((l) => {
    const label = str(l?.label);
    if (!label || [...label].length > 24) throw new Invalid('links', 'Give every link a name of up to 24 characters');
    let url;
    try {
      url = new URL(str(l?.url));
    } catch {
      throw new Invalid('links', `“${label}” needs a full link starting with https://`);
    }
    if (url.protocol !== 'https:') throw new Invalid('links', `“${label}” needs a link starting with https://`);
    return { label, url: url.toString() };
  });
  return { channel, required, links };
}
