// Server-side secrets derived from the deployment's service key. Nothing here is
// stored: rotating that key invalidates sealed values, share codes and webhooks.
import crypto from 'node:crypto';

function root() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error('Server secret is not configured');
  return key;
}

const derive = (label) => crypto.createHmac('sha256', root()).update(label).digest();

/** AES-256-GCM, used to keep the Telegram bot token encrypted at rest. */
export function seal(plain) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', derive('web2apk/seal/v1'), iv);
  const body = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64');
}

export function unseal(sealed) {
  const raw = Buffer.from(String(sealed), 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', derive('web2apk/seal/v1'), raw.subarray(0, 12));
  decipher.setAuthTag(raw.subarray(12, 28));
  return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8');
}

export function sign(label, value, length = 16) {
  return crypto.createHmac('sha256', derive(label)).update(String(value)).digest('base64url').slice(0, length);
}

export function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/** Start parameter for t.me/<bot>?start=…, which makes the bot hand over one build. */
export const shareCode = (buildId) => `b${buildId}_${sign('web2apk/share/v1', buildId)}`;

export function parseShareCode(code) {
  const m = /^b(\d{1,12})_([A-Za-z0-9_-]{16})$/.exec(String(code || ''));
  if (!m) return null;
  return safeEqual(m[2], sign('web2apk/share/v1', m[1])) ? Number(m[1]) : null;
}

/** Stable signing workspace for a Telegram user, so their updates install over old versions. */
export const telegramWorkspaceKey = (telegramId) =>
  crypto.createHmac('sha256', derive('web2apk/tg-workspace/v1')).update(String(telegramId)).digest('hex');

export const webhookSecret = (botId) => sign('web2apk/webhook/v1', botId, 43);
