// Telegram webhook. Telegram proves each call with the secret header that was
// registered together with the webhook URL.
import supabase from './db-client.js';
import { loadSettings } from './_lib/settings.js';
import { safeEqual, unseal, webhookSecret } from './_lib/secret.js';
import { tgClient } from './_lib/tg.js';
import { handleUpdate } from './_lib/bot.js';

export const config = { maxDuration: 30 };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  let settings;
  try {
    settings = await loadSettings(supabase);
  } catch (err) {
    console.error('telegram webhook: settings unavailable:', err?.message || err);
    return res.status(500).json({ error: 'Temporarily unavailable' });
  }
  const bot = settings.bot;
  if (!bot) return res.status(503).json({ error: 'No bot is connected' });
  if (!safeEqual(req.headers['x-telegram-bot-api-secret-token'] || '', webhookSecret(bot.id))) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  let token;
  try {
    token = unseal(bot.token);
  } catch {
    return res.status(503).json({ error: 'The bot needs to be reconnected' });
  }

  if (req.body && typeof req.body === 'object') {
    try {
      await handleUpdate({ supabase, tg: tgClient(token), settings }, req.body);
    } catch (err) {
      console.error('telegram update failed:', err?.message || err);
    }
  }
  // Always acknowledge, otherwise Telegram keeps re-sending the same update.
  return res.status(200).json({ ok: true });
}
