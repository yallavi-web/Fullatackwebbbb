// Express server for Web2APK.
//
// Vercel does not use this file: there, every file in /api is its own
// serverless function. This runs the very same handlers (and serves the built
// site from /dist) as one Node process, for a VPS or a local machine:
//
//   npm run build            (in the project root)
//   cd server && npm install && npm start
//
// It needs the same environment variables as the Vercel project, read from the
// environment or from the project's .env file: NEXT_PUBLIC_SUPABASE_URL,
// NEXT_PUBLIC_SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY.
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import express from 'express';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');

try {
  process.loadEnvFile(path.join(root, '.env'));
} catch {
  // No .env file: the variables must already be set in the environment.
}

// One route per file in /api, exactly as on Vercel.
const ROUTES = ['admin', 'builds', 'config', 'keys', 'presets', 'site-info', 'telegram'];
const handlers = {};
for (const name of ROUTES) {
  // Loaded after the .env file, because the database client reads it on import.
  handlers[name] = (await import(pathToFileURL(path.join(root, 'api', `${name}.js`)).href)).default;
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true); // behind a reverse proxy that terminates HTTPS

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
  if (req.path.startsWith('/fhl')) res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  next();
});

app.use('/api', express.json({ limit: '6mb' }));
app.all('/api/:name', async (req, res) => {
  const handler = handlers[req.params.name];
  if (!handler) return res.status(404).json({ error: 'Not found' });
  try {
    return await handler(req, res);
  } catch (err) {
    console.error(`/api/${req.params.name} failed:`, err?.message || err);
    if (!res.headersSent) res.status(500).json({ error: 'Server error' });
    return undefined;
  }
});
app.use('/api', (err, _req, res, _next) => {
  // Malformed or oversized JSON bodies end up here.
  res.status(err?.status === 413 ? 413 : 400).json({ error: err?.status === 413 ? 'Request is too large' : 'Invalid request body' });
});

// The built site: the public page at /, the admin panel at /fhl/admin/.
app.use(express.static(path.join(root, 'dist')));
app.use((_req, res) => res.status(404).type('text/plain').send('Not found'));

export default app;

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT) || 3000;
  app.listen(port, () => console.log(`Web2APK server listening on http://localhost:${port}`));
}
