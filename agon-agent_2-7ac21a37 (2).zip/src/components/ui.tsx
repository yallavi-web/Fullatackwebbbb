import type { ReactNode } from 'react';
import { HEX_RE } from '../lib/util';

export const inputClass =
  'w-full min-w-0 rounded-md border-2 border-ink bg-white px-3 py-2.5 text-[15px] text-ink placeholder:text-ink-faint ' +
  'outline-none transition-shadow focus-visible:shadow-hard-sm focus-visible:ring-2 focus-visible:ring-droid ' +
  'aria-[invalid=true]:border-signal aria-[invalid=true]:bg-signal-wash/40';

export function StepCard({
  step,
  title,
  hint,
  children,
}: {
  step: string;
  title: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b-2 border-ink px-4 py-3 sm:px-6">
        <span className="font-mono text-xs font-bold tracking-widest text-droid-deep">{step}</span>
        <h2 className="font-display text-xl font-bold tracking-tight">{title}</h2>
        {hint && <p className="w-full text-sm text-ink-soft sm:ml-auto sm:w-auto">{hint}</p>}
      </header>
      <div className="space-y-5 px-4 py-5 sm:px-6">{children}</div>
    </section>
  );
}

export function Field({
  id,
  label,
  error,
  hint,
  children,
  className = '',
}: {
  id: string;
  label: string;
  error?: string;
  hint?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div id={`field-${id}`} className={`min-w-0 scroll-mt-24 ${className}`}>
      <label htmlFor={id} className="mb-1.5 block font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
        {label}
      </label>
      {children}
      {error ? (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm font-medium text-signal-deep">
          {error}
        </p>
      ) : hint ? (
        <p className="mt-1.5 text-sm text-ink-soft">{hint}</p>
      ) : null}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  description,
  icon,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
  description?: string;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`group flex w-full min-w-0 items-center gap-3 rounded-md border-2 px-3 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid focus-visible:ring-offset-2 focus-visible:ring-offset-card ${
        checked ? 'border-ink bg-droid-wash' : 'border-ink/25 bg-white hover:border-ink'
      }`}
    >
      {icon && <span className="shrink-0 text-ink-soft">{icon}</span>}
      <span className="min-w-0 flex-1">
        <span className="block text-[15px] font-semibold leading-tight">{label}</span>
        {description && <span className="mt-0.5 block text-[13px] leading-snug text-ink-soft">{description}</span>}
      </span>
      <span
        aria-hidden
        className={`relative h-6 w-11 shrink-0 rounded-full border-2 border-ink transition-colors ${
          checked ? 'bg-droid' : 'bg-paper-deep'
        }`}
      >
        <span
          className={`absolute top-0.5 h-4 w-4 rounded-full bg-ink transition-[left] duration-150 ${
            checked ? 'left-[22px]' : 'left-0.5'
          }`}
        />
      </span>
    </button>
  );
}

export function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
}) {
  return (
    <div className="min-w-0">
      <p className="mb-1.5 font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">{label}</p>
      <div role="radiogroup" aria-label={label} className="flex overflow-hidden rounded-md border-2 border-ink bg-white">
        {options.map((option, i) => (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={value === option.value}
            onClick={() => onChange(option.value)}
            className={`min-w-0 flex-1 px-2 py-2.5 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-droid-deep ${
              i > 0 ? 'border-l-2 border-ink' : ''
            } ${value === option.value ? 'bg-ink text-paper' : 'text-ink hover:bg-droid-wash'}`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export function ColorField({
  id,
  label,
  value,
  onChange,
  error,
  hint,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  hint?: string;
}) {
  const valid = HEX_RE.test(value);
  return (
    <Field id={id} label={label} error={error} hint={hint}>
      <div className="flex min-w-0 items-stretch gap-2">
        <label
          className="relative block h-[46px] w-[46px] shrink-0 cursor-pointer overflow-hidden rounded-md border-2 border-ink focus-within:ring-2 focus-within:ring-droid"
          style={{ backgroundColor: valid ? value : '#FFFFFF' }}
        >
          <span className="sr-only">Pick {label.toLowerCase()}</span>
          <input
            type="color"
            value={valid ? value : '#FFFFFF'}
            onChange={(e) => onChange(e.target.value.toUpperCase())}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </label>
        <input
          id={id}
          type="text"
          value={value}
          spellCheck={false}
          maxLength={7}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? `${id}-error` : undefined}
          onChange={(e) => {
            let v = e.target.value.trim().toUpperCase();
            if (v && !v.startsWith('#')) v = '#' + v;
            onChange(v);
          }}
          className={`${inputClass} font-mono`}
        />
      </div>
    </Field>
  );
}

export function Spinner({ className = '' }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={`inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-r-transparent ${className}`}
    />
  );
}
