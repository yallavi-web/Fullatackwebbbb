import { useState } from 'react';
import { Check, Copy, KeyRound } from 'lucide-react';
import type { Signing } from '../lib/types';
import { getWorkspaceKey, isValidWorkspaceKey } from '../lib/api';
import { fingerprint } from '../lib/util';
import { inputClass } from './ui';

interface Props {
  signing: Signing | null;
  loading: boolean;
  onRestore: (key: string) => void;
}

export default function SigningCard({ signing, loading, onRestore }: Props) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [value, setValue] = useState('');
  const [error, setError] = useState<string | null>(null);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(getWorkspaceKey());
      setCopied(true);
      setCopyError(false);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopyError(true);
    }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const key = value.trim().toLowerCase();
    if (!isValidWorkspaceKey(key)) {
      setError('A workspace key is 64 hexadecimal characters.');
      return;
    }
    onRestore(key);
    setValue('');
    setError(null);
    setRestoring(false);
  };

  const buttonClass =
    'inline-flex items-center justify-center gap-1.5 rounded-md border-2 border-ink bg-white px-3 py-2 text-sm font-bold transition-colors hover:bg-droid-wash focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card';

  return (
    <div className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex items-center gap-2 border-b-2 border-ink px-4 py-3 sm:px-6">
        <KeyRound size={18} />
        <h2 className="font-display text-xl font-bold tracking-tight">Signing key</h2>
      </header>
      <div className="space-y-4 px-4 py-5 sm:px-6">
        <p className="text-sm leading-relaxed text-ink-soft">
          Every APK from this browser is signed with the same private key, so Android installs a new build over the old
          one and keeps its data. The key is derived from a secret stored only in this browser.
        </p>

        <div className="rounded-md border-2 border-ink/20 bg-white px-3 py-2.5">
          <p className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Certificate SHA-256</p>
          <p className="mt-1 break-all font-mono text-[13px]">
            {loading ? 'Loading…' : signing ? fingerprint(signing.fingerprint, 32) : 'Created with your first build'}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={copy} className={buttonClass}>
            {copied ? <Check size={15} /> : <Copy size={15} />}
            {copied ? 'Key copied' : 'Copy backup key'}
          </button>
          <button type="button" onClick={() => setRestoring((v) => !v)} aria-expanded={restoring} className={buttonClass}>
            Restore a key
          </button>
        </div>
        {copyError && (
          <p role="alert" className="text-sm font-medium text-signal-deep">
            Your browser blocked clipboard access. Allow it for this page and try again.
          </p>
        )}

        {restoring && (
          <form onSubmit={submit} className="space-y-2" noValidate>
            <label htmlFor="restore-key" className="block font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
              Backup key
            </label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <input
                id="restore-key"
                type="text"
                value={value}
                spellCheck={false}
                autoComplete="off"
                aria-invalid={Boolean(error)}
                aria-describedby={error ? 'restore-key-error' : undefined}
                onChange={(e) => {
                  setValue(e.target.value);
                  setError(null);
                }}
                placeholder="64 hex characters"
                className={`${inputClass} font-mono text-[13px]`}
              />
              <button
                type="submit"
                className="inline-flex shrink-0 items-center justify-center rounded-md border-2 border-ink bg-droid px-3 py-2 text-sm font-bold transition-colors hover:bg-droid/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-card"
              >
                Use this key
              </button>
            </div>
            {error ? (
              <p id="restore-key-error" role="alert" className="text-sm font-medium text-signal-deep">
                {error}
              </p>
            ) : (
              <p className="text-[13px] text-ink-soft">
                Replaces this browser's key and shows the builds made with the restored one. Copy the current key first
                if you still need it.
              </p>
            )}
          </form>
        )}
      </div>
    </div>
  );
}
