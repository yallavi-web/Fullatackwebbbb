import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Check, Copy, Download, Hammer, RotateCcw, Send } from 'lucide-react';
import type { BuildState } from '../lib/types';
import { fingerprint, formatBytes, telegramLink } from '../lib/util';
import { Spinner } from './ui';

interface Props {
  state: BuildState;
  disabledReason: string | null;
  botUsername?: string | null;
  onBuild: () => void;
  onReset: () => void;
}

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1600);
        } catch {
          setCopied(false);
        }
      }}
      className="inline-flex shrink-0 items-center gap-1 rounded border border-ink/30 px-1.5 py-0.5 font-mono text-[11px] font-bold text-ink-soft transition-colors hover:border-ink hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep"
      aria-label={label}
    >
      {copied ? <Check size={12} /> : <Copy size={12} />}
      {copied ? 'copied' : 'copy'}
    </button>
  );
}

export default function BuildPanel({ state, disabledReason, botUsername, onBuild, onReset }: Props) {
  const [visible, setVisible] = useState(0);
  const [qr, setQr] = useState<string | null>(null);
  const consoleRef = useRef<HTMLDivElement>(null);

  const log = state.status === 'done' ? state.log : null;
  const apkUrl = state.status === 'done' ? state.build.apk_url : null;

  // Replay the server's build log line by line.
  useEffect(() => {
    if (!log) {
      setVisible(0);
      return;
    }
    setVisible(0);
    const timer = window.setInterval(() => {
      setVisible((n) => {
        if (n >= log.length) {
          window.clearInterval(timer);
          return n;
        }
        return n + 1;
      });
    }, 70);
    return () => window.clearInterval(timer);
  }, [log]);

  useEffect(() => {
    const el = consoleRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [visible, state.status]);

  useEffect(() => {
    let cancelled = false;
    setQr(null);
    if (!apkUrl) return;
    QRCode.toDataURL(apkUrl, { margin: 1, width: 240, color: { dark: '#17160F', light: '#FFFFFF' } })
      .then((url) => {
        if (!cancelled) setQr(url);
      })
      .catch(() => {
        if (!cancelled) setQr(null);
      });
    return () => {
      cancelled = true;
    };
  }, [apkUrl]);

  const building = state.status === 'building';
  const finished = state.status === 'done' && log !== null && visible >= log.length;

  return (
    <div className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <div className="p-4">
        <button
          type="button"
          onClick={onBuild}
          disabled={building || Boolean(disabledReason)}
          className="flex w-full items-center justify-center gap-2.5 rounded-lg border-2 border-ink bg-droid px-4 py-3.5 font-display text-lg font-extrabold tracking-tight text-ink shadow-hard-sm transition-all hover:-translate-x-px hover:-translate-y-px hover:shadow-hard active:translate-x-0.5 active:translate-y-0.5 active:shadow-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:cursor-not-allowed disabled:bg-paper-deep disabled:text-ink-soft disabled:shadow-none disabled:hover:translate-x-0 disabled:hover:translate-y-0"
        >
          {building ? <Spinner /> : <Hammer size={20} strokeWidth={2.5} />}
          {building ? 'Assembling APK…' : state.status === 'done' ? 'Build again' : 'Build APK'}
        </button>
        {disabledReason && !building && <p className="mt-2 text-center text-[13px] text-ink-soft">{disabledReason}</p>}
      </div>

      {state.status !== 'idle' && (
        <div className="border-t-2 border-ink">
          <div
            ref={consoleRef}
            role="log"
            aria-live="polite"
            className="console-scroll max-h-56 overflow-y-auto bg-console px-4 py-3 font-mono text-[12px] leading-relaxed text-console-text"
          >
            {building && (
              <>
                <p className="break-all">
                  <span className="text-droid">$</span> web2apk build {state.packageName}
                </p>
                <p className="text-console-dim">
                  sending spec to the build server<span className="console-caret">█</span>
                </p>
              </>
            )}
            {state.status === 'done' && log && (
              <>
                <p className="break-all">
                  <span className="text-droid">$</span> web2apk build {state.build.package_name}
                </p>
                {log.slice(0, visible).map((line, i) => (
                  <p key={i} className="flex gap-2">
                    <span className="shrink-0 text-console-dim">{String(line.t).padStart(4, '\u00a0')}ms</span>
                    <span className="min-w-0 break-words">{line.message}</span>
                  </p>
                ))}
                {finished ? (
                  <p className="mt-1 font-bold text-droid">✓ BUILD SUCCESSFUL</p>
                ) : (
                  <p className="console-caret text-console-dim">█</p>
                )}
              </>
            )}
            {state.status === 'error' && (
              <>
                <p>
                  <span className="text-droid">$</span> web2apk build
                </p>
                <p className="break-words font-bold text-signal">✗ {state.error}</p>
              </>
            )}
          </div>

          {state.status === 'error' && (
            <div role="alert" className="border-t-2 border-ink bg-signal-wash px-4 py-3 text-sm">
              <p className="font-semibold">The build didn't finish.</p>
              <p className="mt-0.5 text-ink-soft">{state.error} Fix the issue above and build again.</p>
            </div>
          )}

          {state.status === 'done' && finished && (
            <div className="reveal space-y-4 border-t-2 border-ink p-4">
              <div className="flex items-start gap-3">
                <img
                  src={state.build.icon_url}
                  alt=""
                  className="h-12 w-12 shrink-0 rounded-[13px] border border-ink/15 bg-paper-deep"
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-display text-lg font-bold leading-tight">{state.build.app_name}</p>
                  <p className="break-all font-mono text-[12px] text-ink-soft">{state.build.file_name}</p>
                </div>
                <span className="stamp shrink-0" aria-label="Signed with signature scheme v2">
                  SIGNED·V2
                </span>
              </div>

              <a
                href={state.build.apk_url}
                download={state.build.file_name}
                className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-ink bg-ink px-4 py-3 font-display text-base font-bold text-paper shadow-hard-sm transition-all hover:bg-droid-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid focus-visible:ring-offset-2 focus-visible:ring-offset-card"
              >
                <Download size={18} strokeWidth={2.5} />
                Download APK · {formatBytes(state.build.apk_size)}
              </a>

              <a
                href={telegramLink(state.build, botUsername)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-ink bg-telegram px-4 py-2.5 font-display text-base font-bold text-ink shadow-hard-sm transition-all hover:bg-telegram/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-card"
              >
                <Send size={17} strokeWidth={2.5} />
                {botUsername && state.build.share_code ? 'Get the file in Telegram' : 'Send to Telegram'}
              </a>

              <div className="flex items-center gap-4 rounded-lg border-2 border-dashed border-ink/40 p-3">
                <div className="h-[104px] w-[104px] shrink-0 overflow-hidden rounded border border-ink/20 bg-white">
                  {qr ? (
                    <img src={qr} alt="QR code linking to the APK download" className="h-full w-full" />
                  ) : (
                    <span className="flex h-full w-full items-center justify-center text-ink-soft">
                      <Spinner />
                    </span>
                  )}
                </div>
                <p className="min-w-0 text-[13px] leading-snug text-ink-soft">
                  <span className="block font-semibold text-ink">Install on your phone</span>
                  Scan with your Android camera, download, then tap the file and allow installs from your browser.
                </p>
              </div>

              <dl className="space-y-1.5 font-mono text-[11px] text-ink-soft">
                <div className="flex items-center gap-2">
                  <dt className="w-14 shrink-0 font-bold uppercase tracking-wider">sha-256</dt>
                  <dd className="min-w-0 flex-1 truncate">{state.build.sha256}</dd>
                  <CopyButton value={state.build.sha256} label="Copy APK SHA-256" />
                </div>
                <div className="flex items-center gap-2">
                  <dt className="w-14 shrink-0 font-bold uppercase tracking-wider">signer</dt>
                  <dd className="min-w-0 flex-1 truncate">{fingerprint(state.build.cert_sha256, 10)}</dd>
                  <CopyButton value={state.build.cert_sha256} label="Copy certificate fingerprint" />
                </div>
              </dl>

              <button
                type="button"
                onClick={onReset}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-soft underline decoration-ink/30 underline-offset-4 hover:text-ink hover:decoration-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep"
              >
                <RotateCcw size={14} />
                Start a new app
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
