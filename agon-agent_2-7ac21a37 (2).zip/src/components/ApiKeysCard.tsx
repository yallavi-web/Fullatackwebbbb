import { useCallback, useEffect, useState } from 'react';
import { Check, Copy, Plus, TerminalSquare, Trash2 } from 'lucide-react';
import { api } from '../lib/api';
import type { ApiKey } from '../lib/types';
import { timeAgo } from '../lib/util';
import { Spinner, inputClass } from './ui';

const buttonClass =
  'inline-flex items-center justify-center gap-1.5 rounded-md border-2 border-ink px-3 py-2 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:cursor-not-allowed disabled:opacity-50';

const message = (err: unknown, fallback: string) => (err instanceof Error ? err.message : fallback);

export default function ApiKeysCard() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [nameError, setNameError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [copied, setCopied] = useState<'token' | 'curl' | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const fetchKeys = useCallback(async () => {
    try {
      setKeys(await api.keys());
      setError(null);
    } catch (err) {
      setError(message(err, 'Unexpected error'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchKeys();
  }, [fetchKeys]);

  const copy = async (what: 'token' | 'curl', value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(what);
      setActionError(null);
      window.setTimeout(() => setCopied(null), 1800);
    } catch {
      setActionError('Your browser blocked clipboard access. Select the text and copy it by hand.');
    }
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setNameError('Give the key a name so you can recognise it later');
      return;
    }
    setCreating(true);
    setActionError(null);
    try {
      const result = await api.createKey(trimmed);
      setToken(result.token);
      setName('');
      setNameError(null);
      await fetchKeys();
    } catch (err) {
      setNameError(message(err, 'The key could not be created'));
    } finally {
      setCreating(false);
    }
  };

  const revoke = async (key: ApiKey) => {
    setBusyId(key.id);
    setActionError(null);
    try {
      await api.deleteKey(key.id);
      if (token && token.startsWith(key.key_prefix)) setToken(null);
      setConfirmId(null);
      await fetchKeys();
    } catch (err) {
      setActionError(message(err, 'The key could not be revoked'));
    } finally {
      setBusyId(null);
    }
  };

  const curl = [
    `curl -X POST ${window.location.origin}/api/builds \\`,
    `  -H "Authorization: Bearer ${token ?? 'w2a_YOUR_KEY'}" \\`,
    '  -H "Content-Type: application/json" \\',
    `  -d '{"name":"My App","url":"https://example.com","packageName":"com.example.app","versionCode":1}'`,
  ].join('\n');

  return (
    <div className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-center gap-x-3 gap-y-1 border-b-2 border-ink px-4 py-3 sm:px-6">
        <TerminalSquare size={18} />
        <h2 className="font-display text-xl font-bold tracking-tight">API keys</h2>
        <p className="w-full text-sm text-ink-soft sm:ml-auto sm:w-auto">Build APKs from scripts, CI or your own bot</p>
      </header>

      <div className="grid gap-6 px-4 py-5 sm:px-6 lg:grid-cols-2">
        <div className="min-w-0 space-y-4">
          <form onSubmit={create} noValidate>
            <label htmlFor="api-key-name" className="mb-1.5 block font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
              New key name
            </label>
            <div className="flex flex-col gap-2 sm:flex-row">
              <input
                id="api-key-name"
                type="text"
                maxLength={40}
                autoComplete="off"
                placeholder="e.g. Deploy script"
                value={name}
                aria-invalid={Boolean(nameError)}
                aria-describedby={nameError ? 'api-key-name-error' : undefined}
                onChange={(e) => {
                  setName(e.target.value);
                  setNameError(null);
                }}
                className={inputClass}
              />
              <button type="submit" disabled={creating} className={`${buttonClass} shrink-0 bg-droid hover:bg-droid/80`}>
                {creating ? <Spinner /> : <Plus size={16} strokeWidth={2.5} />}
                Create key
              </button>
            </div>
            {nameError && (
              <p id="api-key-name-error" role="alert" className="mt-1.5 text-sm font-medium text-signal-deep">
                {nameError}
              </p>
            )}
          </form>

          {token && (
            <div role="status" className="reveal rounded-md border-2 border-ink bg-droid-wash p-3">
              <p className="text-sm font-semibold">Copy your key now — it won’t be shown again.</p>
              <div className="mt-2 flex items-start gap-2">
                <code className="min-w-0 flex-1 break-all rounded border border-ink/25 bg-white px-2 py-1.5 font-mono text-[12px]">{token}</code>
                <button type="button" onClick={() => copy('token', token)} className={`${buttonClass} shrink-0 bg-white px-2.5 hover:bg-paper-deep`}>
                  {copied === 'token' ? <Check size={15} /> : <Copy size={15} />}
                  {copied === 'token' ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>
          )}

          {actionError && (
            <p role="alert" className="text-sm font-medium text-signal-deep">
              {actionError}
            </p>
          )}

          {loading ? (
            <ul aria-busy="true" className="space-y-2">
              {[0, 1].map((i) => (
                <li key={i} className="h-14 animate-pulse rounded-md bg-ink/10" />
              ))}
            </ul>
          ) : error ? (
            <div role="alert" className="flex flex-wrap items-center gap-3 rounded-md border-2 border-signal bg-signal-wash px-3 py-2.5">
              <p className="min-w-0 flex-1 text-sm">
                <span className="font-semibold">Couldn’t load your API keys.</span> {error}
              </p>
              <button
                type="button"
                onClick={() => {
                  setLoading(true);
                  fetchKeys();
                }}
                className={`${buttonClass} bg-white hover:bg-paper-deep`}
              >
                Try again
              </button>
            </div>
          ) : keys.length === 0 ? (
            <p className="rounded-md border-2 border-dashed border-ink/30 px-3 py-4 text-sm text-ink-soft">
              No API keys yet. Create one to build APKs without opening this page.
            </p>
          ) : (
            <ul className="divide-y-2 divide-ink/10 rounded-md border-2 border-ink/20 bg-white">
              {keys.map((key) => (
                <li key={key.id} className="flex flex-wrap items-center gap-x-3 gap-y-2 px-3 py-2.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-semibold leading-tight">{key.name}</p>
                    <p className="truncate font-mono text-[12px] text-ink-soft">
                      {key.key_prefix}… · created {timeAgo(key.created_at)} ·{' '}
                      {key.last_used_at ? `used ${timeAgo(key.last_used_at)}` : 'never used'}
                    </p>
                  </div>
                  {confirmId === key.id ? (
                    <div className="flex shrink-0 items-center gap-2">
                      <button type="button" onClick={() => revoke(key)} disabled={busyId === key.id} className={`${buttonClass} bg-signal hover:bg-signal/80`}>
                        {busyId === key.id ? <Spinner /> : <Trash2 size={15} />}
                        Revoke
                      </button>
                      <button type="button" onClick={() => setConfirmId(null)} disabled={busyId === key.id} className={`${buttonClass} bg-white hover:bg-paper-deep`}>
                        Keep
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmId(key.id)}
                      aria-label={`Revoke API key ${key.name}`}
                      className={`${buttonClass} shrink-0 bg-white px-2.5 hover:bg-signal-wash`}
                    >
                      <Trash2 size={15} />
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="min-w-0 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <p className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Build with one request</p>
            <button type="button" onClick={() => copy('curl', curl)} className={`${buttonClass} bg-white px-2.5 py-1 hover:bg-droid-wash`}>
              {copied === 'curl' ? <Check size={14} /> : <Copy size={14} />}
              {copied === 'curl' ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="console-scroll overflow-x-auto rounded-md border-2 border-ink bg-console p-3 font-mono text-[12px] leading-relaxed text-console-text">
            <code>{curl}</code>
          </pre>
          <ul className="space-y-1.5 text-[13px] leading-snug text-ink-soft">
            <li>
              The response holds <code className="font-mono text-ink">build.apk_url</code>, the download link for the signed APK.
            </li>
            <li>
              Every option in the builder works as a JSON field, e.g. <code className="font-mono text-ink">navBar</code>,{' '}
              <code className="font-mono text-ink">telegram</code>, <code className="font-mono text-ink">themeColor</code>. Without{' '}
              <code className="font-mono text-ink">icons</code> the app gets a default icon in its theme colour.
            </li>
            <li>
              <code className="font-mono text-ink">GET /api/builds</code> lists your builds. API builds are signed with this workspace’s key and
              appear in the list above.
            </li>
            <li>A key gives full access to this workspace’s builds — keep it private and revoke it if it leaks.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
