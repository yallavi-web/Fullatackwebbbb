import { useState } from 'react';
import { ChevronLeft, ChevronRight, Home, RotateCw, Send, Share2 } from 'lucide-react';
import { hostOf, readableOn } from '../lib/util';

interface Props {
  name: string;
  url: string;
  themeColor: string;
  backgroundColor: string;
  iconUrl: string | null;
  fullscreen: boolean;
  splash: boolean;
  navBar: boolean;
  telegram: boolean;
}

function StatusBar({ color }: { color: string }) {
  return (
    <div className="flex items-center justify-between px-4 pt-2 pb-1 font-mono text-[10px] font-bold" style={{ color }}>
      <span>9:41</span>
      <span className="flex items-center gap-1" aria-hidden>
        <span className="flex items-end gap-[2px]">
          <i className="block h-[4px] w-[3px] rounded-[1px] bg-current" />
          <i className="block h-[6px] w-[3px] rounded-[1px] bg-current" />
          <i className="block h-[8px] w-[3px] rounded-[1px] bg-current" />
        </span>
        <span className="block h-[9px] w-[18px] rounded-[3px] border border-current p-[1px]">
          <i className="block h-full w-3/4 rounded-[1px] bg-current" />
        </span>
      </span>
    </div>
  );
}

function AppIcon({ iconUrl, size }: { iconUrl: string | null; size: number }) {
  return (
    <span
      className="block overflow-hidden bg-paper-deep shadow-[0_3px_8px_rgba(23,22,15,0.25)]"
      style={{ width: size, height: size, borderRadius: size * 0.28 }}
    >
      {iconUrl ? (
        <img src={iconUrl} alt="" className="h-full w-full object-cover" draggable={false} />
      ) : (
        <span className="block h-full w-full animate-pulse bg-ink/10" />
      )}
    </span>
  );
}

export default function PhonePreview({ name, url, themeColor, backgroundColor, iconUrl, fullscreen, splash, navBar, telegram }: Props) {
  const [view, setView] = useState<'home' | 'launch'>('home');
  const label = name.trim() || 'Your app';
  const host = hostOf(url) || 'your-site.com';
  const onTheme = readableOn(themeColor);
  const onBackground = readableOn(backgroundColor);

  return (
    <div className="rounded-xl border-2 border-ink bg-card p-4 shadow-hard">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Preview</p>
        <div role="tablist" aria-label="Preview screen" className="flex overflow-hidden rounded-md border-2 border-ink text-xs font-bold">
          {(['home', 'launch'] as const).map((v, i) => (
            <button
              key={v}
              role="tab"
              type="button"
              aria-selected={view === v}
              onClick={() => setView(v)}
              className={`px-3 py-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-droid-deep ${
                i > 0 ? 'border-l-2 border-ink' : ''
              } ${view === v ? 'bg-ink text-paper' : 'bg-white hover:bg-droid-wash'}`}
            >
              {v === 'home' ? 'Launcher' : 'On launch'}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto w-[228px] rounded-[38px] border-2 border-ink bg-ink p-[7px] shadow-hard-sm">
        <div className="relative h-[420px] overflow-hidden rounded-[30px]">
          {view === 'home' ? (
            <div className="phone-wallpaper flex h-full flex-col">
              <StatusBar color="#17160F" />
              <div className="grid flex-1 grid-cols-4 content-start gap-x-2 gap-y-4 px-3 pt-6">
                <div className="col-span-2 row-span-1 flex flex-col items-center gap-1.5">
                  <AppIcon iconUrl={iconUrl} size={62} />
                  <span className="w-full truncate px-1 text-center text-[11px] font-semibold leading-tight text-ink">{label}</span>
                </div>
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="flex flex-col items-center gap-1.5 pt-2" aria-hidden>
                    <span className="block h-[40px] w-[40px] rounded-[12px] bg-ink/10" />
                    <span className="block h-[5px] w-7 rounded-full bg-ink/10" />
                  </div>
                ))}
              </div>
              <div className="mx-3 mb-4 flex justify-around rounded-[20px] bg-white/45 px-2 py-2.5" aria-hidden>
                {Array.from({ length: 4 }).map((_, i) => (
                  <span key={i} className="block h-[36px] w-[36px] rounded-[11px] bg-ink/15" />
                ))}
              </div>
            </div>
          ) : (
            <div className="flex h-full flex-col" style={{ backgroundColor }}>
              {!fullscreen && (
                <div style={{ backgroundColor: themeColor }}>
                  <StatusBar color={onTheme} />
                </div>
              )}
              <div className="h-[3px] w-2/3" style={{ backgroundColor: themeColor }} aria-hidden />
              <div className="flex flex-1 flex-col items-center justify-center gap-6">
                {splash ? (
                  <>
                    <AppIcon iconUrl={iconUrl} size={76} />
                    <span
                      aria-hidden
                      className="block h-5 w-5 animate-spin rounded-full border-2 border-r-transparent"
                      style={{ borderColor: onBackground, borderRightColor: 'transparent', opacity: 0.6 }}
                    />
                  </>
                ) : (
                  <div className="w-full space-y-2 px-5" aria-hidden>
                    {[80, 100, 92, 60].map((w, i) => (
                      <span key={i} className="block h-2.5 rounded-full" style={{ width: `${w}%`, backgroundColor: onBackground, opacity: 0.12 }} />
                    ))}
                  </div>
                )}
              </div>
              <p className="truncate px-4 pb-4 text-center font-mono text-[10px]" style={{ color: onBackground, opacity: 0.7 }}>
                loading {host}
              </p>
              {telegram && (
                <span
                  aria-hidden
                  className="absolute right-3 flex h-9 w-9 items-center justify-center rounded-full bg-telegram text-white"
                  style={{ bottom: navBar ? 72 : 40 }}
                >
                  <Send size={15} strokeWidth={2.5} />
                </span>
              )}
              {navBar && (
                <div aria-hidden className="flex items-center justify-around px-2 py-2" style={{ backgroundColor: themeColor, color: onTheme }}>
                  <ChevronLeft size={15} className="opacity-40" />
                  <ChevronRight size={15} className="opacity-40" />
                  <Home size={14} />
                  <RotateCw size={14} />
                  <Share2 size={14} />
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <p className="mt-4 text-center text-[13px] leading-snug text-ink-soft">
        {view === 'home'
          ? 'How the icon and label appear in the app drawer.'
          : fullscreen
            ? 'Fullscreen: system bars are hidden while the site loads.'
            : 'Status bar takes the theme colour while the site loads.'}
      </p>
    </div>
  );
}
