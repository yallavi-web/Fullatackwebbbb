import { useRef } from 'react';
import { Camera, ImageUp, MapPin, Mic, Search, Type, Wand2 } from 'lucide-react';
import { normalizeTelegram } from '../lib/util';
import type { BuilderConfig, FieldErrors, IconSource, Orientation, ExternalLinks, Preset } from '../lib/types';
import { ColorField, Field, Segmented, Spinner, StepCard, Toggle, inputClass } from './ui';

export interface SiteStatus {
  status: 'idle' | 'loading' | 'done' | 'error';
  message?: string;
}

interface Props {
  cfg: BuilderConfig;
  errors: FieldErrors;
  update: (patch: Partial<BuilderConfig>) => void;
  site: SiteStatus;
  onFetchDetails: () => void;
  presets: Preset[];
  presetsLoading: boolean;
  presetsError: string | null;
  onPreset: (preset: Preset) => void;
  onSuggestPackage: () => void;
  icon: IconSource;
  iconPreview: string | null;
  iconBg: string;
  iconScale: number;
  onIconBg: (value: string) => void;
  onIconScale: (value: number) => void;
  onIconFile: (file: File) => void;
  onIconLetter: () => void;
}

const smallButton =
  'inline-flex items-center justify-center gap-1.5 rounded-md border-2 border-ink bg-white px-3 py-2 text-sm font-bold transition-colors hover:bg-droid-wash focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:cursor-not-allowed disabled:opacity-50';

const primaryButton =
  'inline-flex items-center justify-center gap-2 rounded-md border-2 border-ink bg-ink px-4 py-2.5 text-sm font-bold text-paper transition-colors hover:bg-droid-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:cursor-wait disabled:opacity-70';

export default function BuilderForm(props: Props) {
  const { cfg, errors, update, site, icon } = props;
  const fileRef = useRef<HTMLInputElement>(null);

  const describe = (key: keyof FieldErrors) => (errors[key] ? `${key}-error` : undefined);

  return (
    <form
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        props.onFetchDetails();
      }}
      className="space-y-6"
    >
      <StepCard step="01" title="Website" hint="The page your app opens">
        <Field id="url" label="Website URL" error={errors.url}>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              id="url"
              type="url"
              inputMode="url"
              autoComplete="url"
              spellCheck={false}
              placeholder="https://your-site.com"
              value={cfg.url}
              aria-invalid={Boolean(errors.url)}
              aria-describedby={describe('url')}
              onChange={(e) => update({ url: e.target.value })}
              className={`${inputClass} font-mono`}
            />
            <button type="submit" disabled={site.status === 'loading'} className={`${primaryButton} shrink-0`}>
              {site.status === 'loading' ? <Spinner /> : <Search size={16} strokeWidth={2.5} />}
              {site.status === 'loading' ? 'Reading site…' : 'Fetch details'}
            </button>
          </div>
        </Field>
        {site.status !== 'idle' && site.message && (
          <p
            role={site.status === 'error' ? 'alert' : 'status'}
            className={`-mt-2 rounded-md border-2 px-3 py-2 text-sm ${
              site.status === 'error'
                ? 'border-signal bg-signal-wash'
                : site.status === 'done'
                  ? 'border-droid-deep/40 bg-droid-wash'
                  : 'border-ink/20 bg-white text-ink-soft'
            }`}
          >
            {site.message}
          </p>
        )}

        <div>
          <p className="mb-2 font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Or start from an example</p>
          {props.presetsLoading ? (
            <div className="flex flex-wrap gap-2" aria-busy="true">
              {[72, 96, 84, 110].map((w) => (
                <span key={w} className="h-9 animate-pulse rounded-full bg-ink/10" style={{ width: w }} />
              ))}
            </div>
          ) : props.presetsError ? (
            <p className="text-sm text-ink-soft">Examples couldn't be loaded ({props.presetsError}). You can still enter any URL above.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {props.presets.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  title={preset.tagline}
                  onClick={() => props.onPreset(preset)}
                  className="inline-flex items-center gap-2 rounded-full border-2 border-ink bg-white py-1.5 pl-2 pr-3.5 text-sm font-semibold transition-all hover:-translate-y-0.5 hover:shadow-hard-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card"
                >
                  <span className="block h-4 w-4 rounded-full border border-ink/40" style={{ backgroundColor: preset.theme_color }} aria-hidden />
                  {preset.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </StepCard>

      <StepCard step="02" title="Identity" hint="How Android knows your app">
        <Field id="name" label="App name" error={errors.name} hint="Shown under the icon. Short names fit best.">
          <input
            id="name"
            type="text"
            maxLength={40}
            autoComplete="off"
            placeholder="My App"
            value={cfg.name}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={describe('name')}
            onChange={(e) => update({ name: e.target.value })}
            className={inputClass}
          />
        </Field>

        <Field
          id="packageName"
          label="Package ID"
          error={errors.packageName}
          hint="Unique ID in reverse-domain form. Keep it the same across versions so updates install over each other."
        >
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              id="packageName"
              type="text"
              spellCheck={false}
              autoCapitalize="none"
              autoComplete="off"
              maxLength={100}
              placeholder="com.example.app"
              value={cfg.packageName}
              aria-invalid={Boolean(errors.packageName)}
              aria-describedby={describe('packageName')}
              onChange={(e) => update({ packageName: e.target.value.toLowerCase().replace(/\s+/g, '') })}
              className={`${inputClass} font-mono`}
            />
            <button type="button" onClick={props.onSuggestPackage} className={`${smallButton} shrink-0`}>
              <Wand2 size={15} />
              From URL
            </button>
          </div>
        </Field>

        <div className="grid gap-5 sm:grid-cols-2">
          <Field id="versionName" label="Version name" error={errors.versionName} hint="What people see, e.g. 1.2.0">
            <input
              id="versionName"
              type="text"
              spellCheck={false}
              maxLength={24}
              value={cfg.versionName}
              aria-invalid={Boolean(errors.versionName)}
              aria-describedby={describe('versionName')}
              onChange={(e) => update({ versionName: e.target.value })}
              className={`${inputClass} font-mono`}
            />
          </Field>
          <Field id="versionCode" label="Version code" error={errors.versionCode} hint="Whole number; raise it for each update">
            <input
              id="versionCode"
              type="number"
              inputMode="numeric"
              min={1}
              step={1}
              value={Number.isFinite(cfg.versionCode) ? cfg.versionCode : ''}
              aria-invalid={Boolean(errors.versionCode)}
              aria-describedby={describe('versionCode')}
              onChange={(e) => update({ versionCode: e.target.value === '' ? NaN : Number(e.target.value) })}
              className={`${inputClass} font-mono`}
            />
          </Field>
        </div>
      </StepCard>

      <StepCard step="03" title="Icon" hint="Adaptive + legacy layers are generated for you">
        <div id="field-icon" className="flex scroll-mt-24 flex-col gap-5 sm:flex-row sm:items-start">
          <div className="flex shrink-0 items-center gap-4 sm:flex-col sm:items-center sm:gap-2">
            <span className="block h-24 w-24 overflow-hidden rounded-[27px] border-2 border-ink bg-paper-deep shadow-hard-sm">
              {props.iconPreview ? (
                <img src={props.iconPreview} alt="Current app icon" className="h-full w-full object-cover" />
              ) : (
                <span className="block h-full w-full animate-pulse bg-ink/10" />
              )}
            </span>
            <span className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
              {icon.kind === 'letter' ? 'Letter icon' : icon.kind === 'kept' ? 'From last build' : icon.origin === 'site' ? 'From website' : 'Uploaded'}
            </span>
          </div>

          <div className="min-w-0 flex-1 space-y-4">
            <div className="flex flex-wrap gap-2">
              <input
                ref={fileRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/svg+xml,image/gif,image/x-icon"
                className="sr-only"
                tabIndex={-1}
                aria-hidden
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) props.onIconFile(file);
                  e.target.value = '';
                }}
              />
              <button type="button" onClick={() => fileRef.current?.click()} className={smallButton}>
                <ImageUp size={15} />
                Upload image
              </button>
              <button type="button" onClick={props.onIconLetter} disabled={icon.kind === 'letter'} className={smallButton}>
                <Type size={15} />
                Use a letter
              </button>
            </div>
            {errors.icon && (
              <p role="alert" className="text-sm font-medium text-signal-deep">
                {errors.icon}
              </p>
            )}

            {icon.kind === 'kept' ? (
              <p className="text-sm leading-relaxed text-ink-soft">
                This version reuses the icon from the build you're updating. Upload an image or switch to a letter to change it.
              </p>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                <ColorField id="iconBg" label="Icon background" value={props.iconBg} onChange={props.onIconBg} />
                <div className="min-w-0">
                  <label htmlFor="iconScale" className="mb-1.5 block font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
                    Artwork size · {Math.round(props.iconScale * 100)}%
                  </label>
                  <input
                    id="iconScale"
                    type="range"
                    min={40}
                    max={100}
                    step={1}
                    value={Math.round(props.iconScale * 100)}
                    onChange={(e) => props.onIconScale(Number(e.target.value) / 100)}
                    className="range mt-3 w-full"
                  />
                </div>
              </div>
            )}
            <p className="text-[13px] leading-snug text-ink-soft">
              PNG, JPG, WebP or SVG. Square artwork of 512 px or more looks sharpest. Launchers crop icons to their own shape, so keep important details near the centre.
            </p>
          </div>
        </div>
      </StepCard>

      <StepCard step="04" title="Look & behaviour">
        <div className="grid gap-5 sm:grid-cols-2">
          <ColorField
            id="themeColor"
            label="Theme colour"
            value={cfg.themeColor}
            error={errors.themeColor}
            hint="Status bar and loading bar"
            onChange={(v) => update({ themeColor: v })}
          />
          <ColorField
            id="backgroundColor"
            label="Launch background"
            value={cfg.backgroundColor}
            error={errors.backgroundColor}
            hint="Behind the splash and offline screens"
            onChange={(v) => update({ backgroundColor: v })}
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <Segmented<Orientation>
            label="Orientation"
            value={cfg.orientation}
            onChange={(v) => update({ orientation: v })}
            options={[
              { value: 'auto', label: 'Auto' },
              { value: 'portrait', label: 'Portrait' },
              { value: 'landscape', label: 'Landscape' },
            ]}
          />
          <Segmented<ExternalLinks>
            label="Links to other sites"
            value={cfg.externalLinks}
            onChange={(v) => update({ externalLinks: v })}
            options={[
              { value: 'inapp', label: 'Stay in app' },
              { value: 'browser', label: 'Open browser' },
            ]}
          />
        </div>

        <div className="grid gap-2.5 sm:grid-cols-2">
          <Toggle checked={cfg.splash} onChange={(v) => update({ splash: v })} label="Splash screen" description="Icon on your launch colour while the site loads" />
          <Toggle checked={cfg.fullscreen} onChange={(v) => update({ fullscreen: v })} label="Fullscreen" description="Hide the status and navigation bars" />
          <Toggle checked={cfg.keepScreenOn} onChange={(v) => update({ keepScreenOn: v })} label="Keep screen on" description="For dashboards, kiosks and recipes" />
          <Toggle checked={cfg.zoom} onChange={(v) => update({ zoom: v })} label="Pinch to zoom" description="Let people zoom the page" />
          <Toggle checked={cfg.confirmExit} onChange={(v) => update({ confirmExit: v })} label="Confirm before exit" description="Back twice to close the app" />
          <Toggle checked={cfg.desktopMode} onChange={(v) => update({ desktopMode: v })} label="Request desktop site" description="Identify as a desktop browser" />
          <Toggle checked={cfg.navBar} onChange={(v) => update({ navBar: v })} label="Navigation bar" description="Back, forward, home, reload and share buttons" />
          <Toggle checked={cfg.blockScreenshots} onChange={(v) => update({ blockScreenshots: v })} label="Block screenshots" description="Hide the app from screenshots and screen recording" />
        </div>
      </StepCard>

      <StepCard step="05" title="Permissions" hint="Only ask for what your site uses">
        <div className="grid gap-2.5 sm:grid-cols-3">
          <Toggle checked={cfg.camera} onChange={(v) => update({ camera: v })} label="Camera" icon={<Camera size={18} />} />
          <Toggle checked={cfg.microphone} onChange={(v) => update({ microphone: v })} label="Microphone" icon={<Mic size={18} />} />
          <Toggle checked={cfg.location} onChange={(v) => update({ location: v })} label="Location" icon={<MapPin size={18} />} />
        </div>
        <p className="text-[13px] leading-snug text-ink-soft">
          Internet access is always included. Anything left off is removed from the manifest entirely, and Android still asks the person before your site can use a permission you enable.
        </p>
      </StepCard>

      <StepCard step="06" title="Extras" hint="Optional">
        <Field
          id="telegram"
          label="Telegram button"
          error={errors.telegram}
          hint={
            normalizeTelegram(cfg.telegram)
              ? `Adds a floating button that opens t.me/${normalizeTelegram(cfg.telegram)} in Telegram.`
              : 'Adds a floating button that opens your Telegram channel, group or chat. Leave empty for none.'
          }
        >
          <input
            id="telegram"
            type="text"
            spellCheck={false}
            autoCapitalize="none"
            autoComplete="off"
            maxLength={120}
            placeholder="@yourchannel or t.me/yourchannel"
            value={cfg.telegram}
            aria-invalid={Boolean(errors.telegram)}
            aria-describedby={describe('telegram')}
            onChange={(e) => update({ telegram: e.target.value })}
            className={`${inputClass} font-mono`}
          />
        </Field>
        <Field
          id="customCss"
          label="Custom CSS"
          error={errors.customCss}
          hint={`Added to every page, e.g. to hide the site's header or footer. ${cfg.customCss.length.toLocaleString('en-US')} / 4,000 · Sites with a strict security policy may ignore it.`}
        >
          <textarea
            id="customCss"
            rows={4}
            spellCheck={false}
            placeholder="header, footer { display: none !important; }"
            value={cfg.customCss}
            aria-invalid={Boolean(errors.customCss)}
            aria-describedby={describe('customCss')}
            onChange={(e) => update({ customCss: e.target.value })}
            className={`${inputClass} resize-y font-mono text-[13px] leading-relaxed`}
          />
        </Field>
      </StepCard>
    </form>
  );
}
