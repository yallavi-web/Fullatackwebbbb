import { useState } from 'react';
import { Download, PackageOpen, RefreshCw, Send, Trash2 } from 'lucide-react';
import type { Build } from '../lib/types';
import { formatBytes, telegramLink, timeAgo } from '../lib/util';
import { Spinner } from './ui';

interface Props {
  builds: Build[];
  botUsername?: string | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onRebuild: (build: Build) => void;
  onDelete: (build: Build) => Promise<void>;
}

function Row({ build, botUsername, onRebuild, onDelete }: { build: Build; botUsername?: string | null; onRebuild: Props['onRebuild']; onDelete: Props['onDelete'] }) {
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const remove = async () => {
    setDeleting(true);
    setError(null);
    try {
      await onDelete(build);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete this build');
      setDeleting(false);
      setConfirming(false);
    }
  };

  const actionClass =
    'inline-flex items-center justify-center gap-1.5 rounded-md border-2 border-ink px-3 py-2 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:opacity-50';

  return (
    <li className="flex flex-col gap-3 px-4 py-4 sm:px-6 md:flex-row md:items-center md:gap-4">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <img
          src={build.icon_url}
          alt=""
          loading="lazy"
          className="h-12 w-12 shrink-0 rounded-[13px] border border-ink/15 bg-paper-deep"
        />
        <div className="min-w-0">
          <p className="flex min-w-0 items-baseline gap-2">
            <span className="truncate font-display text-lg font-bold leading-tight">{build.app_name}</span>
            <span className="shrink-0 rounded border border-ink/30 px-1.5 font-mono text-[11px] font-bold text-ink-soft">
              v{build.version_name}
            </span>
          </p>
          <p className="truncate font-mono text-[12px] text-ink-soft">{build.package_name}</p>
          <p className="truncate text-[13px] text-ink-soft">
            {formatBytes(build.apk_size)} · {timeAgo(build.created_at)} · {build.url.replace(/^https?:\/\//, '').replace(/\/$/, '')}
          </p>
          {error && (
            <p role="alert" className="mt-1 text-sm font-medium text-signal-deep">
              {error}
            </p>
          )}
        </div>
      </div>

      <div className="flex shrink-0 flex-wrap items-center gap-2">
        {confirming ? (
          <>
            <span className="text-sm font-semibold">Delete this APK?</span>
            <button type="button" onClick={remove} disabled={deleting} className={`${actionClass} bg-signal text-ink hover:bg-signal/80`}>
              {deleting ? <Spinner /> : <Trash2 size={15} />}
              Delete
            </button>
            <button type="button" onClick={() => setConfirming(false)} disabled={deleting} className={`${actionClass} bg-white hover:bg-paper-deep`}>
              Keep
            </button>
          </>
        ) : (
          <>
            <a href={build.apk_url} download={build.file_name} className={`${actionClass} bg-droid text-ink hover:bg-droid/80`}>
              <Download size={15} strokeWidth={2.5} />
              Download
            </a>
            <a
              href={telegramLink(build, botUsername)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Send ${build.app_name} ${build.version_name} to Telegram`}
              title="Send to Telegram"
              className={`${actionClass} bg-telegram px-2.5 text-ink hover:bg-telegram/80`}
            >
              <Send size={15} strokeWidth={2.5} />
            </a>
            <button
              type="button"
              onClick={() => onRebuild(build)}
              aria-label={`Build a new version of ${build.app_name}`}
              title="Build a new version"
              className={`${actionClass} bg-white px-2.5 hover:bg-droid-wash sm:px-3`}
            >
              <RefreshCw size={15} />
              <span className="hidden sm:inline">New version</span>
            </button>
            <button
              type="button"
              onClick={() => setConfirming(true)}
              aria-label={`Delete ${build.app_name} ${build.version_name}`}
              className={`${actionClass} bg-white px-2.5 hover:bg-signal-wash`}
            >
              <Trash2 size={15} />
            </button>
          </>
        )}
      </div>
    </li>
  );
}

export default function BuildHistory({ builds, botUsername, loading, error, onRetry, onRebuild, onDelete }: Props) {
  return (
    <div className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b-2 border-ink px-4 py-3 sm:px-6">
        <h2 className="font-display text-xl font-bold tracking-tight">Your builds</h2>
        <p className="text-sm text-ink-soft">
          {loading ? 'Loading…' : `${builds.length} stored for this browser`}
        </p>
      </header>

      {loading ? (
        <ul aria-busy="true" className="divide-y-2 divide-ink/10">
          {[0, 1].map((i) => (
            <li key={i} className="flex items-center gap-3 px-4 py-4 sm:px-6">
              <span className="h-12 w-12 shrink-0 animate-pulse rounded-[13px] bg-ink/10" />
              <span className="flex-1 space-y-2">
                <span className="block h-4 w-40 max-w-full animate-pulse rounded bg-ink/10" />
                <span className="block h-3 w-64 max-w-full animate-pulse rounded bg-ink/10" />
              </span>
            </li>
          ))}
        </ul>
      ) : error ? (
        <div role="alert" className="flex flex-wrap items-center gap-3 bg-signal-wash px-4 py-5 sm:px-6">
          <p className="min-w-0 flex-1 text-sm">
            <span className="font-semibold">Couldn't load your builds.</span> {error}
          </p>
          <button
            type="button"
            onClick={onRetry}
            className="rounded-md border-2 border-ink bg-white px-3 py-2 text-sm font-bold hover:bg-paper-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep"
          >
            Try again
          </button>
        </div>
      ) : builds.length === 0 ? (
        <div className="flex flex-col items-center gap-2 px-4 py-10 text-center sm:px-6">
          <PackageOpen size={30} className="text-ink-soft" />
          <p className="font-display text-lg font-bold">Nothing built yet</p>
          <p className="max-w-sm text-sm text-ink-soft">
            APKs you build are kept here so you can download them again or ship an updated version later.
          </p>
          <a
            href="#builder"
            className="mt-2 rounded-md border-2 border-ink bg-droid px-4 py-2 text-sm font-bold shadow-hard-sm hover:bg-droid/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-card"
          >
            Build your first APK
          </a>
        </div>
      ) : (
        <ul className="divide-y-2 divide-ink/10">
          {builds.map((build) => (
            <Row key={build.id} build={build} botUsername={botUsername} onRebuild={onRebuild} onDelete={onDelete} />
          ))}
        </ul>
      )}
    </div>
  );
}
