import { Cpu, FileCog, ShieldCheck, Smartphone } from 'lucide-react';

const STAGES = [
  {
    icon: Cpu,
    title: 'A compiled Android shell',
    body: 'Each APK starts from a small native WebView app written in Java and compiled to DEX. It handles the back button, file uploads, downloads, fullscreen video, external app links and an offline retry screen.',
  },
  {
    icon: FileCog,
    title: 'Patched for your site',
    body: 'The build server rewrites the binary AndroidManifest (package ID, label, version, permissions), the resource table and the launcher icon layers, then adds your URL and options as a config asset.',
  },
  {
    icon: ShieldCheck,
    title: 'Aligned and signed',
    body: 'Entries are stored 4-byte aligned and the archive is signed with APK Signature Scheme v2 using an ECDSA P-256 key that belongs to your browser, so Android accepts it as a normal installable package.',
  },
];

const INSTALL = [
  'Open the download on your Android phone — scanning the QR code is the quickest way.',
  'Tap the downloaded .apk. Android asks once to allow installs from your browser or file manager.',
  'If Play Protect says it doesn’t recognise the developer, choose “Install anyway”. That notice appears for any app not distributed through Google Play.',
  'To update later, build a new version with a higher version code and install it over the old one.',
];

const LIMITS = [
  'Runs on Android 7.0 (API 24) and newer.',
  'The app needs a connection: it loads your live site, so site changes appear without rebuilding.',
  'Made for sideloading and direct sharing. Google Play only accepts App Bundles (.aab), which this tool doesn’t produce.',
  'No push notifications or other native plugins — the app is your website in a dedicated window.',
  'Only wrap sites you own or have permission to repackage.',
];

export default function Guide() {
  return (
    <section id="how" className="scroll-mt-6 py-14 sm:py-20">
      <p className="font-mono text-xs font-bold uppercase tracking-widest text-droid-deep">Under the hood</p>
      <h2 className="mt-2 max-w-2xl font-display text-3xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl">
        What actually happens when you press Build
      </h2>

      <ol className="mt-8 grid gap-5 md:grid-cols-3">
        {STAGES.map((stage, i) => (
          <li key={stage.title} className="rounded-xl border-2 border-ink bg-card p-5 shadow-hard">
            <div className="flex items-center justify-between">
              <span className="flex h-11 w-11 items-center justify-center rounded-lg border-2 border-ink bg-droid">
                <stage.icon size={22} strokeWidth={2.2} />
              </span>
              <span className="font-display text-4xl font-extrabold text-ink/15" aria-hidden>
                {i + 1}
              </span>
            </div>
            <h3 className="mt-4 font-display text-xl font-bold tracking-tight">{stage.title}</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{stage.body}</p>
          </li>
        ))}
      </ol>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <div className="rounded-xl border-2 border-ink bg-ink p-5 text-paper shadow-hard sm:p-6">
          <h3 className="flex items-center gap-2 font-display text-xl font-bold tracking-tight">
            <Smartphone size={20} />
            Installing the APK
          </h3>
          <ol className="mt-4 space-y-3">
            {INSTALL.map((step, i) => (
              <li key={i} className="flex gap-3 text-[15px] leading-relaxed text-paper/85">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-droid font-mono text-xs font-bold text-ink">
                  {i + 1}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="rounded-xl border-2 border-ink bg-card p-5 shadow-hard sm:p-6">
          <h3 className="font-display text-xl font-bold tracking-tight">Good to know</h3>
          <ul className="mt-4 space-y-3">
            {LIMITS.map((item, i) => (
              <li key={i} className="flex gap-3 text-[15px] leading-relaxed text-ink-soft">
                <span className="mt-[9px] block h-2 w-2 shrink-0 bg-signal" aria-hidden />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
