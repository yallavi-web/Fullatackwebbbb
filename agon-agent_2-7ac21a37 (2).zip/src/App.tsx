import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowRight, Send } from 'lucide-react';
import BuilderForm, { type SiteStatus } from './components/BuilderForm';
import PhonePreview from './components/PhonePreview';
import BuildPanel from './components/BuildPanel';
import BuildHistory from './components/BuildHistory';
import SigningCard from './components/SigningCard';
import ApiKeysCard from './components/ApiKeysCard';
import Guide from './components/Guide';
import { ApiError, api, setWorkspaceKey } from './lib/api';
import { analyzeImage, loadImage, readFileAsDataUrl, renderIcons } from './lib/icon';
import type {
  Build,
  BuildState,
  BuilderConfig,
  FieldErrors,
  IconSource,
  Preset,
  RenderedIcons,
  Signing,
  SiteConfig,
} from './lib/types';
import { HEX_RE, PACKAGE_RE, VERSION_RE, firstLetter, normalizeTelegram, normalizeUrl, suggestPackage, trialLabel } from './lib/util';

const DEFAULT_CONFIG: BuilderConfig = {
  url: '',
  name: '',
  packageName: '',
  versionName: '1.0.0',
  versionCode: 1,
  themeColor: '#22C36F',
  backgroundColor: '#FFFFFF',
  orientation: 'auto',
  fullscreen: false,
  keepScreenOn: false,
  zoom: false,
  splash: true,
  confirmExit: false,
  desktopMode: false,
  externalLinks: 'inapp',
  camera: false,
  microphone: false,
  location: false,
  navBar: false,
  blockScreenshots: false,
  telegram: '',
  customCss: '',
};

const DEFAULT_ICON_BG = '#22C36F';
const FIELD_ORDER: (keyof FieldErrors)[] = [
  'url',
  'name',
  'packageName',
  'versionName',
  'versionCode',
  'icon',
  'themeColor',
  'backgroundColor',
  'telegram',
  'customCss',
];

function validate(cfg: BuilderConfig): FieldErrors {
  const errors: FieldErrors = {};
  if (!cfg.url.trim()) errors.url = 'Enter the website your app should open';
  else if (!normalizeUrl(cfg.url)) errors.url = 'That doesn’t look like a website address. Try https://example.com';
  if (!cfg.name.trim()) errors.name = 'Give your app a name';
  if (!cfg.packageName) errors.packageName = 'Add a package ID, e.g. com.example.app';
  else if (!PACKAGE_RE.test(cfg.packageName))
    errors.packageName = 'Use at least two dot-separated parts, each starting with a letter: com.example.app';
  if (!VERSION_RE.test(cfg.versionName.trim())) errors.versionName = 'Use letters, digits, dots or dashes, e.g. 1.2.0';
  if (!Number.isInteger(cfg.versionCode) || cfg.versionCode < 1 || cfg.versionCode > 2100000000)
    errors.versionCode = 'Enter a whole number of 1 or more';
  if (!HEX_RE.test(cfg.themeColor)) errors.themeColor = 'Use a hex colour like #22C36F';
  if (!HEX_RE.test(cfg.backgroundColor)) errors.backgroundColor = 'Use a hex colour like #FFFFFF';
  if (normalizeTelegram(cfg.telegram) === null)
    errors.telegram = 'Enter a Telegram username, channel or t.me link, e.g. @mychannel';
  if (cfg.customCss.length > 4000) errors.customCss = 'Keep custom CSS under 4,000 characters';
  return errors;
}

export default function App() {
  const [cfg, setCfg] = useState<BuilderConfig>(DEFAULT_CONFIG);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [site, setSite] = useState<SiteStatus>({ status: 'idle' });
  const touched = useRef({ name: false, packageName: false, iconBg: false });

  const [icon, setIcon] = useState<IconSource>({ kind: 'letter' });
  const [iconBg, setIconBg] = useState(DEFAULT_ICON_BG);
  const [iconScale, setIconScale] = useState(0.62);
  const [rendered, setRendered] = useState<RenderedIcons | null>(null);

  const [presets, setPresets] = useState<Preset[]>([]);
  const [presetsLoading, setPresetsLoading] = useState(true);
  const [presetsError, setPresetsError] = useState<string | null>(null);

  const [builds, setBuilds] = useState<Build[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [signing, setSigning] = useState<Signing | null>(null);
  const [buildsLoading, setBuildsLoading] = useState(true);
  const [buildsError, setBuildsError] = useState<string | null>(null);

  const [buildState, setBuildState] = useState<BuildState>({ status: 'idle' });
  const siteRequest = useRef(0);
  const panelRef = useRef<HTMLDivElement>(null);
  const [workspaceRev, setWorkspaceRev] = useState(0);
  const [config, setConfig] = useState<SiteConfig | null>(null);
  const brand = config?.site.name || 'Web2APK';
  const botName = config?.bot?.username ?? null;

  // ------------------------------------------------------------ data loading

  const fetchBuilds = useCallback(async () => {
    try {
      const data = await api.builds();
      setBuilds(data.builds);
      setTotal(data.total);
      setSigning(data.signing);
      setBuildsError(null);
    } catch (err) {
      setBuildsError(err instanceof Error ? err.message : 'Unexpected error');
    } finally {
      setBuildsLoading(false);
    }
  }, []);

  const fetchPresets = useCallback(async () => {
    try {
      setPresets(await api.presets());
      setPresetsError(null);
    } catch (err) {
      setPresetsError(err instanceof Error ? err.message : 'unexpected error');
    } finally {
      setPresetsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBuilds();
    fetchPresets();
    // Branding and feature switches set by the admin; the defaults apply if this fails.
    api.config().then(setConfig).catch(() => undefined);
  }, [fetchBuilds, fetchPresets]);

  useEffect(() => {
    if (!config) return;
    document.title = `${config.site.name} — Turn any website into a real Android APK`;
    const link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (link && config.site.logoUrl) {
      link.removeAttribute('type');
      link.href = config.site.logoUrl;
    }
  }, [config]);

  // ------------------------------------------------------------- icon render

  const letter = firstLetter(cfg.name);
  const safeIconBg = HEX_RE.test(iconBg) ? iconBg : DEFAULT_ICON_BG;

  useEffect(() => {
    if (icon.kind === 'kept') {
      setRendered(null);
      return;
    }
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      try {
        const image = icon.kind === 'image' ? await loadImage(icon.src) : null;
        const out = await renderIcons({ image, letter, bg: safeIconBg, scale: iconScale });
        if (!cancelled) setRendered(out);
      } catch {
        if (!cancelled) {
          setIcon({ kind: 'letter' });
          setErrors((e) => ({ ...e, icon: 'That image couldn’t be used, so a letter icon was generated instead.' }));
        }
      }
    }, 60);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [icon, letter, safeIconBg, iconScale]);

  const iconPreview = icon.kind === 'kept' ? icon.previewUrl : (rendered?.preview ?? null);

  // ------------------------------------------------------------ form helpers

  const update = useCallback((patch: Partial<BuilderConfig>) => {
    if ('name' in patch) touched.current.name = true;
    if ('packageName' in patch) touched.current.packageName = true;
    setCfg((current) => {
      const next = { ...current, ...patch };
      if ('url' in patch && !touched.current.packageName) {
        next.packageName = suggestPackage(patch.url || '') || current.packageName;
      }
      return next;
    });
    setErrors((current) => {
      const next = { ...current };
      for (const key of Object.keys(patch)) delete next[key as keyof FieldErrors];
      return next;
    });
  }, []);

  const useImageAsIcon = useCallback(async (src: string, origin: 'upload' | 'site') => {
    const image = await loadImage(src);
    const analysis = analyzeImage(image);
    touched.current.iconBg = true;
    setIconBg(analysis.fullBleed && analysis.color ? analysis.color : '#FFFFFF');
    setIconScale(analysis.fullBleed ? 1 : 0.62);
    setIcon({ kind: 'image', src, origin });
    setErrors((e) => ({ ...e, icon: undefined }));
  }, []);

  const fetchDetails = useCallback(
    async (urlInput: string) => {
      const target = normalizeUrl(urlInput);
      if (!target) {
        setErrors((e) => ({ ...e, url: urlInput.trim() ? 'That doesn’t look like a website address. Try https://example.com' : 'Enter the website your app should open' }));
        return;
      }
      const requestId = ++siteRequest.current;
      setSite({ status: 'loading', message: `Reading ${new URL(target).hostname}…` });
      try {
        const info = await api.siteInfo(target);
        if (requestId !== siteRequest.current) return;
        setCfg((current) => ({
          ...current,
          url: target,
          name: touched.current.name && current.name.trim() ? current.name : info.name.slice(0, 40),
          packageName: touched.current.packageName && current.packageName ? current.packageName : suggestPackage(target),
          themeColor: info.themeColor ?? current.themeColor,
          backgroundColor: info.backgroundColor ?? current.backgroundColor,
          orientation: info.orientation ?? current.orientation,
        }));
        setErrors((e) => ({ ...e, url: undefined, name: undefined, packageName: undefined }));

        let iconNote = 'No usable icon was found, so a letter icon is used.';
        if (info.icon) {
          try {
            await useImageAsIcon(info.icon, 'site');
            iconNote = `Icon taken from the site's ${info.iconSource === 'manifest' ? 'web manifest' : info.iconSource === 'apple-touch-icon' ? 'touch icon' : 'favicon'}.`;
          } catch {
            iconNote = 'The site icon couldn’t be decoded, so a letter icon is used.';
          }
        } else if (!touched.current.iconBg && info.themeColor) {
          setIconBg(info.themeColor);
        }
        if (requestId !== siteRequest.current) return;
        setSite({
          status: 'done',
          message: info.reachable
            ? `Found “${info.name}”. ${iconNote} Review the details below.`
            : `The site answered with HTTP ${info.status}, so details may be incomplete. ${iconNote}`,
        });
      } catch (err) {
        if (requestId !== siteRequest.current) return;
        setSite({
          status: 'error',
          message: `${err instanceof Error ? err.message : 'The site could not be read'}. You can still fill in the details by hand and build.`,
        });
      }
    },
    [useImageAsIcon],
  );

  const applyPreset = (preset: Preset) => {
    touched.current = { name: true, packageName: true, iconBg: false };
    setCfg({
      ...DEFAULT_CONFIG,
      url: preset.url,
      name: preset.name,
      packageName: preset.package_name,
      themeColor: preset.theme_color,
      backgroundColor: preset.background_color,
      location: preset.needs_location,
    });
    setErrors({});
    setIcon({ kind: 'letter' });
    setIconBg(preset.theme_color);
    setIconScale(0.62);
    setBuildState({ status: 'idle' });
    fetchDetails(preset.url);
  };

  const onIconFile = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      setErrors((e) => ({ ...e, icon: 'That image is over 5 MB. Choose a smaller file.' }));
      return;
    }
    try {
      await useImageAsIcon(await readFileAsDataUrl(file), 'upload');
    } catch (err) {
      setErrors((e) => ({ ...e, icon: err instanceof Error ? `${err.message}. Try a PNG or JPG.` : 'That image could not be used.' }));
    }
  };

  // ------------------------------------------------------------------ build

  const scrollToField = (key: string) => {
    const el = document.getElementById(`field-${key}`);
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const input = el.querySelector<HTMLElement>('input, textarea');
    input?.focus({ preventScroll: true });
  };

  const build = async () => {
    const found = validate(cfg);
    setErrors(found);
    const first = FIELD_ORDER.find((key) => found[key]);
    if (first) {
      scrollToField(first);
      return;
    }
    if (icon.kind !== 'kept' && !rendered) return;

    const url = normalizeUrl(cfg.url) as string;
    setBuildState({ status: 'building', packageName: cfg.packageName });
    // Bring the build console into view when it sits below the fold (mobile).
    const panel = panelRef.current;
    if (panel) {
      const top = panel.getBoundingClientRect().top;
      if (top < 0 || top > window.innerHeight * 0.35) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    try {
      const result = await api.createBuild({
        ...cfg,
        url,
        name: cfg.name.trim(),
        versionName: cfg.versionName.trim(),
        ...(icon.kind === 'kept'
          ? { iconsFromBuild: icon.buildId }
          : { icons: { legacy: rendered!.legacy, foreground: rendered!.foreground, background: rendered!.background } }),
      });
      setBuildState({ status: 'done', build: result.build, log: result.log });
      fetchBuilds();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unexpected error';
      if (err instanceof ApiError && err.field) {
        setErrors((e) => ({ ...e, [err.field as string]: message }));
        scrollToField(err.field);
      }
      setBuildState({ status: 'error', error: message });
    }
  };

  const resetBuilder = () => {
    touched.current = { name: false, packageName: false, iconBg: false };
    setCfg(DEFAULT_CONFIG);
    setErrors({});
    setSite({ status: 'idle' });
    setIcon({ kind: 'letter' });
    setIconBg(DEFAULT_ICON_BG);
    setIconScale(0.62);
    setBuildState({ status: 'idle' });
    document.getElementById('builder')?.scrollIntoView({ behavior: 'smooth' });
  };

  const rebuild = (source: Build) => {
    touched.current = { name: true, packageName: true, iconBg: true };
    setCfg({
      ...DEFAULT_CONFIG,
      ...(source.options || {}),
      url: source.url,
      name: source.app_name,
      packageName: source.package_name,
      versionName: source.version_name,
      versionCode: source.version_code + 1,
      themeColor: source.theme_color,
      backgroundColor: source.background_color,
      orientation: source.orientation,
    });
    setErrors({});
    setSite({
      status: 'done',
      message: `Loaded ${source.app_name} v${source.version_name}. The version code was raised to ${source.version_code + 1} — adjust anything else, then build.`,
    });
    setIcon({ kind: 'kept', buildId: source.id, previewUrl: source.icon_url });
    setBuildState({ status: 'idle' });
    document.getElementById('builder')?.scrollIntoView({ behavior: 'smooth' });
  };

  const deleteBuild = async (target: Build) => {
    await api.deleteBuild(target.id);
    if (icon.kind === 'kept' && icon.buildId === target.id) setIcon({ kind: 'letter' });
    if (buildState.status === 'done' && buildState.build.id === target.id) setBuildState({ status: 'idle' });
    await fetchBuilds();
  };

  const restoreKey = (key: string) => {
    setWorkspaceKey(key);
    setWorkspaceRev((n) => n + 1);
    if (icon.kind === 'kept') setIcon({ kind: 'letter' });
    setBuildState({ status: 'idle' });
    setBuildsLoading(true);
    fetchBuilds();
  };

  const disabledReason = useMemo(() => {
    if (config && !config.webBuilder) {
      return botName ? `Building here is switched off — use @${botName} on Telegram instead.` : 'Building on the website is switched off right now.';
    }
    if (icon.kind !== 'kept' && !rendered) return 'Preparing the icon…';
    return null;
  }, [icon, rendered, config, botName]);

  // ----------------------------------------------------------------- render

  return (
    <div className="min-h-screen">
      <a
        href="#builder"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:border-2 focus:border-ink focus:bg-droid focus:px-3 focus:py-2 focus:font-bold"
      >
        Skip to the builder
      </a>

      <header className="border-b-2 border-ink bg-paper/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <a href="#top" className="flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-4 focus-visible:ring-offset-paper">
            {config?.site.logoUrl ? (
              <img src={config.site.logoUrl} alt="" className="h-9 w-9 shrink-0 rounded-lg border-2 border-ink object-cover shadow-hard-sm" />
            ) : (
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border-2 border-ink bg-droid shadow-hard-sm">
                <ArrowRight size={20} strokeWidth={3} />
              </span>
            )}
            <span className="max-w-[7.5rem] truncate font-display text-xl font-extrabold tracking-tight sm:max-w-xs">{brand}</span>
          </a>
          <nav aria-label="Sections" className="flex items-center gap-1 text-sm font-semibold sm:gap-2">
            {[
              ['#builder', 'Builder'],
              ['#builds', 'Builds'],
              ['#how', 'Guide'],
            ].map(([href, label]) => (
              <a
                key={href}
                href={href}
                className="whitespace-nowrap rounded-md px-2 py-1.5 hover:bg-ink hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep sm:px-3"
              >
                {label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main id="top" className="mx-auto max-w-6xl px-4 sm:px-6">
        <section className="reveal py-10 sm:py-16">
          <p className="inline-flex items-center gap-2 rounded-full border-2 border-ink bg-card px-3 py-1 font-mono text-[11px] font-bold uppercase tracking-widest">
            <span className="block h-2 w-2 rounded-full bg-droid" aria-hidden />
            {total ? `${total.toLocaleString('en-US')} app${total === 1 ? '' : 's'} built and hosted` : 'Build server online'}
          </p>
          <h1 className="mt-5 max-w-4xl font-display text-[2.6rem] font-extrabold leading-[0.95] tracking-tight sm:text-7xl">
            Any website in,{' '}
            <span className="whitespace-nowrap">
              a real{' '}
              <span className="relative inline-block -rotate-2 rounded-lg border-2 border-ink bg-droid px-2.5 pb-1 shadow-hard">.apk</span>{' '}
              out.
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-ink-soft sm:text-xl">
            {config?.site.tagline ||
              'Paste a URL and get a signed Android app you can install straight away. The package is assembled, aligned and signed on the server in about a second — no Android Studio, no account.'}
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3">
            <a
              href="#builder"
              className="inline-flex items-center gap-2 rounded-lg border-2 border-ink bg-ink px-5 py-3 font-display text-lg font-bold text-paper shadow-hard-sm transition-colors hover:bg-droid-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid focus-visible:ring-offset-2 focus-visible:ring-offset-paper"
            >
              Start building
              <ArrowDown size={18} strokeWidth={2.5} />
            </a>
            {botName && (
              <a
                href={`https://t.me/${botName}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border-2 border-ink bg-telegram px-5 py-3 font-display text-lg font-bold text-ink shadow-hard-sm transition-colors hover:bg-telegram/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-paper"
              >
                <Send size={18} strokeWidth={2.5} />
                Build in Telegram
              </a>
            )}
            <ul className="flex flex-wrap gap-2 font-mono text-[12px] font-bold">
              {['≈ 45 KB per app', 'Android 7.0+', 'Signature scheme v2', ...(botName && config && config.trialHours > 0 ? [`${trialLabel(config.trialHours)} free trial in the bot`] : [])].map((fact) => (
                <li key={fact} className="rounded border border-ink/40 px-2 py-1">
                  {fact}
                </li>
              ))}
            </ul>
          </div>
        </section>

        {config && (
          <section id="bot" aria-label="Telegram bot" className="mb-8 scroll-mt-6 rounded-xl border-2 border-ink bg-card shadow-hard">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-3 px-4 py-4 sm:px-6">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border-2 border-ink bg-telegram">
                <Send size={20} strokeWidth={2.5} />
              </span>
              <div className="min-w-0 flex-1 basis-64">
                <p className="flex flex-wrap items-center gap-2">
                  <span className="font-display text-xl font-bold leading-tight tracking-tight">
                    {botName ? `Build in Telegram with @${botName}` : 'Telegram bot'}
                  </span>
                  <span
                    className={`rounded border px-1.5 py-0.5 font-mono text-[11px] font-bold ${
                      botName ? 'border-droid-deep/50 bg-droid-wash text-droid-deep' : 'border-signal bg-signal-wash text-signal-deep'
                    }`}
                  >
                    {botName ? 'Connected' : 'Not connected yet'}
                  </span>
                </p>
                <p className="mt-1 text-[15px] leading-relaxed text-ink-soft">
                  {botName
                    ? 'Send the bot a link, set the name and icon with Back and Next buttons, and the signed APK arrives in your chat ready to install.'
                    : 'The Telegram bot is not available right now. You can still build your app on this page.'}
                  {config.trialHours > 0 && ` New bot users get a ${trialLabel(config.trialHours)} free trial.`}
                </p>
              </div>
              {botName ? (
                <a
                  href={`https://t.me/${botName}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg border-2 border-ink bg-telegram px-4 py-2.5 font-display text-base font-bold text-ink shadow-hard-sm transition-colors hover:bg-telegram/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2 focus-visible:ring-offset-card"
                >
                  <Send size={17} strokeWidth={2.5} />
                  Open bot
                </a>
              ) : null}
            </div>
            {(config.follow?.channel || (config.follow?.links.length ?? 0) > 0) && (
              <div className="flex flex-wrap items-center gap-2 border-t-2 border-ink/10 px-4 py-3 sm:px-6">
                <span className="mr-1 font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Follow us</span>
                {[
                  ...(config.follow?.channel ? [{ label: `@${config.follow.channel}`, url: `https://t.me/${config.follow.channel}` }] : []),
                  ...(config.follow?.links ?? []),
                ].map((link) => (
                  <a
                    key={link.url}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-full border-2 border-ink bg-white px-3 py-1 text-sm font-semibold transition-colors hover:bg-droid-wash focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            )}
          </section>
        )}

        <section id="builder" className="grid scroll-mt-6 gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
          <div className="min-w-0">
            <BuilderForm
              cfg={cfg}
              errors={errors}
              update={update}
              site={site}
              onFetchDetails={() => fetchDetails(cfg.url)}
              presets={presets}
              presetsLoading={presetsLoading}
              presetsError={presetsError}
              onPreset={applyPreset}
              onSuggestPackage={() => {
                const suggestion = suggestPackage(cfg.url);
                if (!suggestion) {
                  setErrors((e) => ({ ...e, packageName: 'Enter a valid website URL first' }));
                  return;
                }
                touched.current.packageName = false;
                setCfg((c) => ({ ...c, packageName: suggestion }));
                setErrors((e) => ({ ...e, packageName: undefined }));
              }}
              icon={icon}
              iconPreview={iconPreview}
              iconBg={iconBg}
              iconScale={iconScale}
              onIconBg={(v) => {
                touched.current.iconBg = true;
                setIconBg(v);
              }}
              onIconScale={setIconScale}
              onIconFile={onIconFile}
              onIconLetter={() => {
                setIcon({ kind: 'letter' });
                setIconScale(0.62);
                if (!HEX_RE.test(iconBg) || iconBg === '#FFFFFF') setIconBg(HEX_RE.test(cfg.themeColor) ? cfg.themeColor : DEFAULT_ICON_BG);
                setErrors((e) => ({ ...e, icon: undefined }));
              }}
            />
          </div>

          <aside aria-label="Preview and build" className="flex min-w-0 flex-col gap-6">
            <PhonePreview
              name={cfg.name}
              url={cfg.url}
              themeColor={HEX_RE.test(cfg.themeColor) ? cfg.themeColor : '#22C36F'}
              backgroundColor={HEX_RE.test(cfg.backgroundColor) ? cfg.backgroundColor : '#FFFFFF'}
              iconUrl={iconPreview}
              fullscreen={cfg.fullscreen}
              splash={cfg.splash}
              navBar={cfg.navBar}
              telegram={Boolean(normalizeTelegram(cfg.telegram))}
            />
            <div
              ref={panelRef}
              className="scroll-mt-4 lg:sticky lg:top-6 lg:-mb-2 lg:-mr-2 lg:max-h-[calc(100vh-3rem)] lg:overflow-y-auto lg:pb-2 lg:pr-2"
            >
              <BuildPanel state={buildState} disabledReason={disabledReason} botUsername={botName} onBuild={build} onReset={resetBuilder} />
            </div>
          </aside>
        </section>

        <section id="builds" className="scroll-mt-6 pt-14 sm:pt-20">
          <p className="font-mono text-xs font-bold uppercase tracking-widest text-droid-deep">Workspace</p>
          <h2 className="mt-2 font-display text-3xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl">Shipped from this browser</h2>
          <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px] lg:items-start">
            <div className="min-w-0">
              <BuildHistory
                botUsername={botName}
                builds={builds}
                loading={buildsLoading}
                error={buildsError}
                onRetry={() => {
                  setBuildsLoading(true);
                  fetchBuilds();
                }}
                onRebuild={rebuild}
                onDelete={deleteBuild}
              />
            </div>
            <SigningCard signing={signing} loading={buildsLoading} onRestore={restoreKey} />
          </div>
          {config?.apiKeys !== false && (
            <div className="mt-6">
              <ApiKeysCard key={workspaceRev} />
            </div>
          )}
        </section>

        <Guide />
      </main>

      <footer className="border-t-2 border-ink">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-6 font-mono text-[12px] text-ink-soft sm:px-6">
          <p>{brand} · WebView shell, minSdk 24 · targetSdk 34</p>
          <p>Android is a trademark of Google LLC.</p>
        </div>
      </footer>
    </div>
  );
}
