import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

const root = createRoot(document.getElementById('root')!)

// A Google sign-in window that could not hand its result back directly lands
// here. It only has to store the session and close itself, so skip the app.
if (new URLSearchParams(window.location.hash.slice(1)).has('google_auth_popup')) {
  root.render(<p className="p-10 text-center font-mono text-sm text-ink-soft">Signing you in… this window closes by itself.</p>)
  import('./lib/googleAuth.ts').then((m) => m.handleGoogleRedirect(true))
} else {
  root.render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}
