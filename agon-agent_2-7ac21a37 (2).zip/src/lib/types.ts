export type Orientation = 'auto' | 'portrait' | 'landscape';
export type ExternalLinks = 'inapp' | 'browser';

export interface BuildOptions {
  fullscreen: boolean;
  keepScreenOn: boolean;
  zoom: boolean;
  splash: boolean;
  confirmExit: boolean;
  desktopMode: boolean;
  externalLinks: ExternalLinks;
  camera: boolean;
  microphone: boolean;
  location: boolean;
  navBar: boolean;
  blockScreenshots: boolean;
  telegram: string;
  customCss: string;
}

export interface BuilderConfig extends BuildOptions {
  url: string;
  name: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  themeColor: string;
  backgroundColor: string;
  orientation: Orientation;
}

export interface Build {
  id: number;
  app_name: string;
  package_name: string;
  url: string;
  version_name: string;
  version_code: number;
  theme_color: string;
  background_color: string;
  orientation: Orientation;
  options: Partial<BuildOptions> | null;
  apk_url: string;
  icon_url: string;
  file_name: string;
  apk_size: number;
  sha256: string;
  cert_sha256: string;
  created_at: string;
  /** Start parameter that makes the Telegram bot send this APK as a file. */
  share_code?: string;
}

export interface LogLine {
  t: number;
  message: string;
}

export interface ApiKey {
  id: number;
  name: string;
  key_prefix: string;
  created_at: string;
  last_used_at: string | null;
}

export interface Signing {
  fingerprint: string;
  created_at: string;
}

export interface Preset {
  id: number;
  name: string;
  url: string;
  package_name: string;
  theme_color: string;
  background_color: string;
  tagline: string;
  needs_location: boolean;
  sort_order: number;
}

export interface SiteInfo {
  url: string;
  reachable: boolean;
  status: number;
  name: string;
  title: string;
  description: string;
  themeColor: string | null;
  backgroundColor: string | null;
  orientation: Orientation | null;
  hasManifest: boolean;
  icon: string | null;
  iconSource: 'manifest' | 'apple-touch-icon' | 'favicon' | null;
}

export type IconSource =
  | { kind: 'letter' }
  | { kind: 'image'; src: string; origin: 'upload' | 'site' }
  | { kind: 'kept'; buildId: number; previewUrl: string };

export interface RenderedIcons {
  legacy: string;
  foreground: string;
  background: string;
  preview: string;
}

export type FieldErrors = Partial<Record<keyof BuilderConfig | 'icon', string>>;

export type BuildState =
  | { status: 'idle' }
  | { status: 'building'; packageName: string }
  | { status: 'done'; build: Build; log: LogLine[] }
  | { status: 'error'; error: string };

export interface SiteConfig {
  site: { name: string; tagline: string; logoUrl: string };
  bot: { username: string; name: string } | null;
  webBuilder: boolean;
  apiKeys: boolean;
  trialHours: number;
  follow?: { channel: string; links: FollowLink[] };
}

export interface FollowLink {
  label: string;
  url: string;
}

export interface AdminSettings {
  site: { name: string; tagline: string; logoUrl: string };
  access: {
    trialHours: number;
    botAccess: 'open' | 'approved';
    webBuilder: boolean;
    apiKeys: boolean;
    contact: string;
    welcome: string;
  };
  privacy: { storeProfiles: boolean; retentionDays: number; idleMinutes: number };
  follow: { channel: string; required: boolean; links: FollowLink[] };
}

export interface AdminBot {
  id: number;
  username: string;
  name: string;
  hint: string;
  webhookUrl: string;
  connectedAt: string;
}

export interface BotTest {
  ok: boolean;
  error?: string;
  username?: string;
  matches?: boolean;
  pending?: number;
  lastError?: string | null;
  lastErrorAt?: string | null;
}

export interface AdminUser {
  id: number;
  username: string | null;
  first_name: string | null;
  status: string;
  approved: boolean;
  unlimited: boolean;
  trial_started_at: string;
  access_until: string | null;
  builds_count: number;
  created_at: string;
  last_seen_at: string;
  plan: { ok: boolean; kind: 'trial' | 'paid' | 'unlimited' | null; reason: 'blocked' | 'pending' | 'expired' | null; until: string | null };
}

export interface AdminBuild extends Build {
  source: 'bot' | 'web';
  owner_label: string;
}

export interface AuditEntry {
  id: number;
  actor: string;
  action: string;
  detail: string;
  created_at: string;
}

export interface AdminData {
  me: { email: string; role: string; via: 'google' | 'password'; last_login_at: string | null };
  settings: AdminSettings;
  bot: AdminBot | null;
  stats: { users: number; trials: number; access: number; expired: number; builds: number };
  users: AdminUser[];
  builds: AdminBuild[];
  audit: AuditEntry[];
  /** Filled for super admins only. */
  admins: AdminAccount[];
}

export interface AdminAccount {
  id: number;
  email: string;
  role: 'super_admin' | 'admin';
  method: 'google' | 'password';
  last_login_at: string | null;
  created_at: string;
  you: boolean;
}

export type AdminTab = 'overview' | 'bot' | 'branding' | 'access' | 'follow' | 'admins' | 'users' | 'builds' | 'security' | 'activity';

export interface SectionProps {
  data: AdminData;
  /** Runs an admin action, then reloads the panel data. */
  act: <T = { ok: true }>(action: string, payload?: object) => Promise<T>;
  toast: (message: string) => void;
  go: (tab: AdminTab) => void;
}
