import supabase from './supabase';

const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

function buildGoogleUrl(appName: string): string | null {
  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
  const redirectUri = import.meta.env.VITE_GOOGLE_AUTH_PROXY;
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
  if (!clientId || !redirectUri) return null;
  const state = btoa(JSON.stringify({ origin: window.location.origin, appName, supabaseUrl, supabaseAnonKey }));
  return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=openid%20email%20profile&prompt=select_account&state=${encodeURIComponent(state)}`;
}

/**
 * Opens Google's account chooser in a popup. On success the session is stored,
 * which the app picks up through its auth listener.
 */
export function signInWithGoogle(appName: string, onError: (message: string) => void): 'opened' | 'blocked' | 'unavailable' {
  const url = buildGoogleUrl(appName);
  if (!url) return 'unavailable';

  // Always window.open(), never a full-page redirect: the page may be running inside a preview frame.
  const popup = window.open(url, 'google-auth', isMobile() ? '' : 'width=500,height=600');
  if (!popup) return 'blocked';

  // Only trust messages from that popup; never poll popup.closed (it reads true
  // as soon as the popup reaches Google, long before sign-in finishes).
  const handler = async (event: MessageEvent) => {
    if (event.source !== popup) return;
    if (event.data?.type === 'google-auth-denied') {
      window.removeEventListener('message', handler);
      onError('Google sign-in was cancelled.');
      return;
    }
    if (event.data?.type !== 'google-auth-success') return;
    window.removeEventListener('message', handler);
    const { access_token, refresh_token } = event.data;
    const { error } = await supabase.auth.setSession({ access_token, refresh_token });
    if (error) onError(`Google sign-in could not be completed: ${error.message}`);
  };
  window.addEventListener('message', handler);
  return 'opened';
}

/**
 * Redirect fallback: when the popup cannot message the tab that opened it, it is
 * sent to this site with the session in the URL fragment (…&google_auth_popup=1).
 * Creating the Supabase client stores that session, which signs in every open tab
 * of this site; all that is left is to close the popup.
 */
export async function handleGoogleRedirect(known = false): Promise<void> {
  if (!known && !new URLSearchParams(window.location.hash.slice(1)).has('google_auth_popup')) return;
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session) {
    console.error('[google-auth] redirect sign-in failed:', error?.message);
    return;
  }
  window.close();
}
