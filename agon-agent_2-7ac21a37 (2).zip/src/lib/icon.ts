import type { RenderedIcons } from './types';
import { readableOn } from './util';

const LEGACY = 192; // mipmap-xxxhdpi launcher icon (48dp)
const ADAPTIVE = 432; // adaptive layer (108dp)
const VIEWPORT = 288; // visible part of an adaptive icon (72dp)

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('That image could not be decoded'));
    img.src = src;
  });
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('That file could not be read'));
    reader.readAsDataURL(file);
  });
}

function canvas(size: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const el = document.createElement('canvas');
  el.width = size;
  el.height = size;
  const ctx = el.getContext('2d');
  if (!ctx) throw new Error('Canvas is not available in this browser');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  return [el, ctx];
}

const toHex = (n: number) => Math.round(n).toString(16).padStart(2, '0');

/** Detects icons that already fill their square (opaque corners) and their edge colour. */
export function analyzeImage(img: HTMLImageElement): { fullBleed: boolean; color: string | null } {
  try {
    const [el, ctx] = canvas(48);
    ctx.drawImage(img, 0, 0, 48, 48);
    const { data } = ctx.getImageData(0, 0, el.width, el.height);
    const points = [
      [1, 1], [46, 1], [1, 46], [46, 46], [24, 1], [24, 46], [1, 24], [46, 24],
    ];
    let r = 0;
    let g = 0;
    let b = 0;
    for (const [x, y] of points) {
      const o = (y * 48 + x) * 4;
      if (data[o + 3] < 245) return { fullBleed: false, color: null };
      r += data[o];
      g += data[o + 1];
      b += data[o + 2];
    }
    const n = points.length;
    return { fullBleed: true, color: `#${toHex(r / n)}${toHex(g / n)}${toHex(b / n)}`.toUpperCase() };
  } catch {
    return { fullBleed: false, color: null };
  }
}

interface RenderOptions {
  image: HTMLImageElement | null;
  letter: string;
  bg: string;
  /** 0.4 – 1: how much of the visible tile the artwork covers. */
  scale: number;
}

function drawArtwork(ctx: CanvasRenderingContext2D, center: number, box: number, opts: RenderOptions) {
  if (opts.image) {
    const iw = opts.image.naturalWidth || 512;
    const ih = opts.image.naturalHeight || 512;
    const ratio = Math.min(box / iw, box / ih);
    const w = iw * ratio;
    const h = ih * ratio;
    ctx.drawImage(opts.image, center - w / 2, center - h / 2, w, h);
    return;
  }
  ctx.fillStyle = readableOn(opts.bg);
  ctx.font = `800 ${Math.round(box * 0.86)}px "Bricolage Grotesque", "Arial Black", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  const metrics = ctx.measureText(opts.letter);
  const ascent = metrics.actualBoundingBoxAscent || box * 0.6;
  const descent = metrics.actualBoundingBoxDescent || 0;
  ctx.fillText(opts.letter, center, center + (ascent - descent) / 2);
}

function roundedRect(ctx: CanvasRenderingContext2D, size: number, radius: number) {
  ctx.beginPath();
  ctx.moveTo(radius, 0);
  ctx.arcTo(size, 0, size, size, radius);
  ctx.arcTo(size, size, 0, size, radius);
  ctx.arcTo(0, size, 0, 0, radius);
  ctx.arcTo(0, 0, size, 0, radius);
  ctx.closePath();
}

const base64 = (el: HTMLCanvasElement) => el.toDataURL('image/png').split(',')[1];

/** Produces the three PNG layers the APK needs plus a square preview. */
export async function renderIcons(opts: RenderOptions): Promise<RenderedIcons> {
  if (!opts.image && document.fonts?.load) {
    await document.fonts.load('800 64px "Bricolage Grotesque"').catch(() => undefined);
  }
  // Letter icons look right a little smaller than image artwork.
  const scale = opts.image ? opts.scale : opts.scale * 0.72;

  const [legacyEl, legacy] = canvas(LEGACY);
  roundedRect(legacy, LEGACY, LEGACY * 0.22);
  legacy.clip();
  legacy.fillStyle = opts.bg;
  legacy.fillRect(0, 0, LEGACY, LEGACY);
  drawArtwork(legacy, LEGACY / 2, LEGACY * scale, opts);

  const [fgEl, fg] = canvas(ADAPTIVE);
  drawArtwork(fg, ADAPTIVE / 2, VIEWPORT * scale, opts);

  const [bgEl, bg] = canvas(ADAPTIVE);
  bg.fillStyle = opts.bg;
  bg.fillRect(0, 0, ADAPTIVE, ADAPTIVE);

  const [previewEl, preview] = canvas(VIEWPORT);
  preview.fillStyle = opts.bg;
  preview.fillRect(0, 0, VIEWPORT, VIEWPORT);
  drawArtwork(preview, VIEWPORT / 2, VIEWPORT * scale, opts);

  return {
    legacy: base64(legacyEl),
    foreground: base64(fgEl),
    background: base64(bgEl),
    preview: previewEl.toDataURL('image/png'),
  };
}
