import type { ApiKey, Build, LogLine, Preset, Signing, SiteConfig, SiteInfo } from './types';

const STORAGE_KEY = 'web2apk.workspace';
let memoryKey: string | null = null;

function randomKey(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function isValidWorkspaceKey(key: string): boolean {
  return /^[a-f0-9]{64}$/.test(key);
}

/** The workspace key identifies this browser's builds and seeds its APK signing key. */
export function getWorkspaceKey(): string {
  if (memoryKey) return memoryKey;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored && isValidWorkspaceKey(stored)) {
      memoryKey = stored;
      return stored;
    }
  } catch {
    // Storage can be unavailable (private mode / sandboxed frames).
  }
  const fresh = randomKey();
  setWorkspaceKey(fresh);
  return fresh;
}

export function setWorkspaceKey(key: string): void {
  memoryKey = key;
  try {
    window.localStorage.setItem(STORAGE_KEY, key);
  } catch {
    // Fall back to the in-memory copy for this session.
  }
}

export class ApiError extends Error {
  field?: string;
  status: number;
  constructor(message: string, status: number, field?: string) {
    super(message);
    this.status = status;
    this.field = field;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        'X-Workspace-Key': getWorkspaceKey(),
        ...(init.headers || {}),
      },
    });
  } catch {
    throw new ApiError('Network error — check your connection and try again', 0);
  }
  const text = await res.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      throw new ApiError(`The server returned an unexpected response (${res.status})`, res.status);
    }
  }
  if (!res.ok) {
    const body = (data || {}) as { error?: string; field?: string };
    throw new ApiError(body.error || `Request failed (${res.status})`, res.status, body.field);
  }
  return data as T;
}

export interface BuildsResponse {
  builds: Build[];
  total: number;
  signing: Signing | null;
}

export const api = {
  config: () => request<SiteConfig>('/api/config'),
  presets: () => request<Preset[]>('/api/presets'),
  builds: () => request<BuildsResponse>('/api/builds'),
  createBuild: (body: unknown) =>
    request<{ build: Build; log: LogLine[] }>('/api/builds', { method: 'POST', body: JSON.stringify(body) }),
  deleteBuild: (id: number) =>
    request<{ ok: true }>('/api/builds', { method: 'DELETE', body: JSON.stringify({ id }) }),
  keys: () => request<ApiKey[]>('/api/keys'),
  createKey: (name: string) =>
    request<{ key: ApiKey; token: string }>('/api/keys', { method: 'POST', body: JSON.stringify({ name }) }),
  deleteKey: (id: number) => request<{ ok: true }>('/api/keys', { method: 'DELETE', body: JSON.stringify({ id }) }),
  siteInfo: (url: string) => request<SiteInfo>(`/api/site-info?url=${encodeURIComponent(url)}`),
};
