import supabase from './supabase';
import { ApiError } from './api';
import type { AdminData } from './types';

async function call<T>(init: RequestInit): Promise<T> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new ApiError('Sign in to continue', 401);
  let res: Response;
  try {
    res = await fetch('/api/admin', {
      ...init,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    });
  } catch {
    throw new ApiError('Network error — check your connection and try again', 0);
  }
  const text = await res.text();
  let body: unknown = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    throw new ApiError(`The server returned an unexpected response (${res.status})`, res.status);
  }
  if (!res.ok) {
    const b = (body || {}) as { error?: string; field?: string };
    throw new ApiError(b.error || `Request failed (${res.status})`, res.status, b.field);
  }
  return body as T;
}

export const adminGet = () => call<AdminData>({ method: 'GET' });

export const adminPost = <T = { ok: true }>(action: string, payload: object = {}) =>
  call<T>({ method: 'POST', body: JSON.stringify({ action, ...payload }) });
