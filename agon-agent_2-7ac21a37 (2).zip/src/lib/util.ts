export const PACKAGE_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
export const HEX_RE = /^#[0-9a-fA-F]{6}$/;
export const VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,23}$/;

export function normalizeUrl(input: string): string | null {
  let value = input.trim();
  if (!value) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) value = 'https://' + value;
  try {
    const url = new URL(value);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
    if (!url.hostname.includes('.') && url.hostname !== 'localhost') return null;
    return url.toString();
  } catch {
    return null;
  }
}

/** com.example.shop.webapp from https://shop.example.com — the suffix avoids clashing with official apps. */
export function suggestPackage(url: string): string {
  const normalized = normalizeUrl(url);
  if (!normalized) return '';
  const host = new URL(normalized).hostname.replace(/^www\./, '');
  const parts = host
    .split('.')
    .filter(Boolean)
    .reverse()
    .map((segment) => {
      let s = segment.toLowerCase().replace(/[^a-z0-9_]/g, '_');
      if (!/^[a-z]/.test(s)) s = 'x' + s;
      return s;
    });
  if (parts.length < 2) parts.unshift('app');
  return [...parts, 'webapp'].join('.').slice(0, 100);
}

export function hostOf(url: string): string {
  const normalized = normalizeUrl(url);
  if (!normalized) return '';
  return new URL(normalized).hostname;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

export function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '';
  const seconds = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (seconds < 45) return 'just now';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days} d ago`;
  return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export function firstLetter(name: string): string {
  const match = name.trim().match(/[\p{L}\p{N}]/u);
  return match ? match[0].toUpperCase() : 'A';
}

export function luminance(hex: string): number {
  if (!HEX_RE.test(hex)) return 1;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
}

export function readableOn(hex: string): string {
  return luminance(hex) > 0.6 ? '#17160F' : '#FFFFFF';
}

export function fingerprint(hex: string, groups = 8): string {
  const pairs = hex.toUpperCase().match(/.{2}/g) || [];
  return pairs.slice(0, groups).join(':') + (pairs.length > groups ? ':…' : '');
}

/** '' for empty, the bare username / +invite code when valid, null when it isn't a Telegram handle. */
export function normalizeTelegram(input: string): string | null {
  let s = input.trim();
  if (!s) return '';
  s = s
    .replace(/^(https?:\/\/)?(www\.)?(t|telegram)\.me\//i, '')
    .replace(/^joinchat\//i, '+')
    .replace(/^@/, '')
    .replace(/[/?#].*$/, '');
  return /^\+[A-Za-z0-9_-]{8,64}$/.test(s) || /^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(s) ? s : null;
}

/** Opens Telegram's own share sheet with the APK download link — no bot or token involved. */
export function telegramShareUrl(build: { apk_url: string; app_name: string; version_name: string }): string {
  const text = `${build.app_name} v${build.version_name} — Android app (APK)`;
  return `https://t.me/share/url?url=${encodeURIComponent(build.apk_url)}&text=${encodeURIComponent(text)}`;
}

/** With a connected bot, the link opens the bot, which sends the APK as an installable file. */
export function telegramLink(build: { apk_url: string; app_name: string; version_name: string; share_code?: string }, bot?: string | null): string {
  return bot && build.share_code ? `https://t.me/${bot}?start=${build.share_code}` : telegramShareUrl(build);
}

export function trialLabel(hours: number): string {
  if (hours % 24 === 0) return `${hours / 24}-day`;
  return `${hours}-hour`;
}

export function dateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
