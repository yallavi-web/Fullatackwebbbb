import { useState } from 'react';
import { Download, KeyRound, LogOut, Search, Trash2, UserCog } from 'lucide-react';
import supabase from '../lib/supabase';
import type { AdminUser, SectionProps } from '../lib/types';
import { dateTime, formatBytes, timeAgo } from '../lib/util';
import { Field, Spinner, Toggle, inputClass } from '../components/ui';
import { Badge, ErrorNote, Panel, btn, useAction } from './kit';

function PlanBadge({ user }: { user: AdminUser }) {
  const p = user.plan;
  if (p.reason === 'blocked') return <Badge tone="bad">Blocked</Badge>;
  if (p.reason === 'pending') return <Badge tone="warn">Awaiting approval</Badge>;
  if (p.reason === 'expired') return <Badge tone="warn">Trial ended</Badge>;
  if (p.kind === 'unlimited') return <Badge tone="good">Unlimited</Badge>;
  if (p.kind === 'paid') return <Badge tone="good">Access until {dateTime(p.until)}</Badge>;
  return <Badge tone="plain">Trial until {dateTime(p.until)}</Badge>;
}

const nameOf = (u: AdminUser) => u.first_name || (u.username ? `@${u.username}` : 'Telegram user');

function UserRow({ user, act, toast, approval }: { user: AdminUser; approval: boolean } & Pick<SectionProps, 'act' | 'toast'>) {
  const [open, setOpen] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const a = useAction();
  const run = async (op: string, done: string, extra: object = {}) => {
    if (await a.run(op, () => act('user', { id: user.id, op, ...extra }))) toast(done);
  };
  const busy = a.busy !== null;

  return (
    <li className="px-4 py-3 sm:px-6">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-ink bg-droid-wash font-display text-lg font-bold">
          {nameOf(user).replace('@', '').charAt(0).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1 basis-40">
          <p className="truncate text-[15px] font-semibold leading-tight">
            {nameOf(user)} {user.first_name && user.username && <span className="font-normal text-ink-soft">@{user.username}</span>}
          </p>
          <p className="truncate font-mono text-[12px] text-ink-soft">
            ID {user.id} · {user.builds_count} build{user.builds_count === 1 ? '' : 's'} · seen {timeAgo(user.last_seen_at)}
          </p>
        </div>
        <PlanBadge user={user} />
        <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} className={`${btn.plain} px-2.5`}>
          <UserCog size={15} />
          Manage
        </button>
      </div>

      {open && (
        <div className="mt-3 space-y-3 rounded-md border-2 border-ink/20 bg-white p-3">
          <div className="flex flex-wrap gap-2">
            {[1, 7, 30].map((days) => (
              <button key={days} type="button" disabled={busy} onClick={() => run('grant', `Added ${days} day${days === 1 ? '' : 's'}`, { days })} className={btn.primary}>
                + {days} day{days === 1 ? '' : 's'}
              </button>
            ))}
            <button type="button" disabled={busy || user.unlimited} onClick={() => run('unlimited', 'Unlimited access granted')} className={btn.plain}>
              Unlimited
            </button>
            <button type="button" disabled={busy} onClick={() => run('resetTrial', 'Trial restarted')} className={btn.plain}>
              Restart trial
            </button>
            <button type="button" disabled={busy} onClick={() => run('revoke', 'Access ended')} className={btn.danger}>
              End access
            </button>
          </div>
          <div className="flex flex-wrap gap-2 border-t-2 border-ink/10 pt-3">
            {approval && !user.approved && (
              <button type="button" disabled={busy} onClick={() => run('approve', 'User approved')} className={btn.primary}>
                Approve
              </button>
            )}
            {user.status === 'blocked' ? (
              <button type="button" disabled={busy} onClick={() => run('unblock', 'User unblocked')} className={btn.plain}>
                Unblock
              </button>
            ) : (
              <button type="button" disabled={busy} onClick={() => run('block', 'User blocked')} className={btn.danger}>
                Block
              </button>
            )}
            {confirm ? (
              <>
                <button type="button" disabled={busy} onClick={() => run('delete', 'User data deleted')} className={`${btn.danger} bg-signal`}>
                  {a.busy === 'delete' ? <Spinner /> : <Trash2 size={15} />}
                  Delete user and their builds
                </button>
                <button type="button" onClick={() => setConfirm(false)} className={btn.plain}>
                  Keep
                </button>
              </>
            ) : (
              <button type="button" disabled={busy} onClick={() => setConfirm(true)} className={btn.danger}>
                <Trash2 size={15} />
                Delete data
              </button>
            )}
          </div>
          <p className="text-[13px] text-ink-soft">
            First seen {dateTime(user.created_at)}. The person is told in Telegram when you add time, approve them or restart their trial.
          </p>
          <ErrorNote>{a.error}</ErrorNote>
        </div>
      )}
    </li>
  );
}

export function UsersSection({ data, act, toast, go }: SectionProps) {
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase().replace(/^@/, '');
  const users = q ? data.users.filter((u) => `${u.id} ${u.username ?? ''} ${u.first_name ?? ''}`.toLowerCase().includes(q)) : data.users;

  return (
    <section className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-center gap-3 border-b-2 border-ink px-4 py-3 sm:px-6">
        <h2 className="font-display text-xl font-bold tracking-tight">Bot users</h2>
        <p className="text-sm text-ink-soft">{data.users.length} total</p>
        <label className="relative ml-auto block w-full sm:w-64">
          <span className="sr-only">Search users</span>
          <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-soft" />
          <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Name, @username or ID" className={`${inputClass} py-2 pl-9 text-sm`} />
        </label>
      </header>
      {data.users.length === 0 ? (
        <div className="space-y-3 px-4 py-10 text-center sm:px-6">
          <p className="font-display text-lg font-bold">No one has started the bot yet</p>
          <p className="mx-auto max-w-sm text-sm text-ink-soft">
            {data.bot ? `People appear here after they message @${data.bot.username}.` : 'Connect your Telegram bot first — people appear here after their first message.'}
          </p>
          {!data.bot && (
            <button type="button" onClick={() => go('bot')} className={btn.primary}>
              Connect the bot
            </button>
          )}
        </div>
      ) : users.length === 0 ? (
        <p className="px-4 py-8 text-center text-sm text-ink-soft sm:px-6">No user matches “{query}”.</p>
      ) : (
        <ul className="divide-y-2 divide-ink/10">
          {users.map((u) => (
            <UserRow key={u.id} user={u} act={act} toast={toast} approval={data.settings.access.botAccess === 'approved'} />
          ))}
        </ul>
      )}
    </section>
  );
}

export function BuildsSection({ data, act, toast }: SectionProps) {
  const [confirm, setConfirm] = useState<number | null>(null);
  const a = useAction();

  return (
    <section className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-baseline gap-x-3 border-b-2 border-ink px-4 py-3 sm:px-6">
        <h2 className="font-display text-xl font-bold tracking-tight">All builds</h2>
        <p className="text-sm text-ink-soft">
          {data.stats.builds} stored{data.stats.builds > data.builds.length ? ` · newest ${data.builds.length} shown` : ''}
        </p>
      </header>
      {a.error && (
        <div className="px-4 pt-4 sm:px-6">
          <ErrorNote>{a.error}</ErrorNote>
        </div>
      )}
      {data.builds.length === 0 ? (
        <p className="px-4 py-10 text-center text-sm text-ink-soft sm:px-6">No APKs are stored yet. Builds from the website, the API and the bot appear here.</p>
      ) : (
        <ul className="divide-y-2 divide-ink/10">
          {data.builds.map((b) => (
            <li key={b.id} className="flex flex-wrap items-center gap-x-3 gap-y-2 px-4 py-3 sm:px-6">
              <img src={b.icon_url} alt="" loading="lazy" className="h-11 w-11 shrink-0 rounded-[12px] border border-ink/15 bg-paper-deep" />
              <div className="min-w-0 flex-1 basis-48">
                <p className="truncate text-[15px] font-semibold leading-tight">
                  {b.app_name} <span className="font-mono text-[12px] font-normal text-ink-soft">v{b.version_name}</span>
                </p>
                <p className="truncate font-mono text-[12px] text-ink-soft">{b.package_name}</p>
                <p className="truncate text-[13px] text-ink-soft">
                  {b.owner_label} · {formatBytes(b.apk_size)} · {timeAgo(b.created_at)}
                </p>
              </div>
              <Badge tone={b.source === 'bot' ? 'good' : 'plain'}>{b.source === 'bot' ? 'Bot' : 'Web'}</Badge>
              {confirm === b.id ? (
                <>
                  <button
                    type="button"
                    disabled={a.busy !== null}
                    onClick={async () => {
                      if (await a.run('delete', () => act('deleteBuild', { id: b.id }))) {
                        setConfirm(null);
                        toast('Build deleted');
                      }
                    }}
                    className={`${btn.danger} bg-signal`}
                  >
                    {a.busy ? <Spinner /> : <Trash2 size={15} />}
                    Delete
                  </button>
                  <button type="button" onClick={() => setConfirm(null)} className={btn.plain}>
                    Keep
                  </button>
                </>
              ) : (
                <>
                  <a href={b.apk_url} download={b.file_name} aria-label={`Download ${b.app_name}`} className={`${btn.plain} px-2.5`}>
                    <Download size={15} />
                  </a>
                  <button type="button" onClick={() => setConfirm(b.id)} aria-label={`Delete ${b.app_name}`} className={`${btn.danger} px-2.5`}>
                    <Trash2 size={15} />
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export function SecuritySection({ data, act, toast }: SectionProps) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [again, setAgain] = useState('');
  const [privacy, setPrivacy] = useState(data.settings.privacy);
  const [idle, setIdle] = useState(String(data.settings.privacy.idleMinutes));
  const [keep, setKeep] = useState(String(data.settings.privacy.retentionDays));
  const pw = useAction();
  const pr = useAction();

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (next.length < 10) return pw.setError('Use at least 10 characters for the new password.');
    if (next !== again) return pw.setError('The two new passwords don’t match.');
    if (next === current) return pw.setError('Choose a password different from the current one.');
    const ok = await pw.run('password', async () => {
      const check = await supabase.auth.signInWithPassword({ email: data.me.email, password: current });
      if (check.error) throw new Error('The current password is not correct.');
      const change = await supabase.auth.updateUser({ password: next });
      if (change.error) throw new Error(change.error.message);
      await act('passwordChanged');
    });
    if (ok) {
      setCurrent('');
      setNext('');
      setAgain('');
      toast('Password changed');
    }
    return undefined;
  };

  const savePrivacy = async (e: React.FormEvent) => {
    e.preventDefault();
    const idleMinutes = Number(idle);
    const retentionDays = Number(keep);
    if (idle.trim() === '' || !Number.isInteger(idleMinutes) || idleMinutes < 5 || idleMinutes > 240) return pr.setError('Auto-lock must be between 5 and 240 minutes.');
    if (keep.trim() === '' || !Number.isInteger(retentionDays) || retentionDays < 0 || retentionDays > 365) return pr.setError('Retention must be between 0 and 365 days.');
    if (await pr.run('privacy', () => act('savePrivacy', { privacy: { ...privacy, idleMinutes, retentionDays } }))) toast('Saved');
    return undefined;
  };

  return (
    <>
      {data.me.via === 'google' ? (
        <Panel title="Sign-in" icon={<KeyRound size={18} />} hint={`Signed in as ${data.me.email}`}>
          <p className="text-[15px] leading-relaxed text-ink-soft">
            You sign in with Google, so there is no password to manage here. Keep that Google account safe — turn on 2-Step Verification in your
            Google Account settings.
          </p>
          <button type="button" onClick={() => supabase.auth.signOut({ scope: 'global' })} className={btn.danger}>
            <LogOut size={15} />
            Sign out on all devices
          </button>
        </Panel>
      ) : (
        <Panel title="Password" icon={<KeyRound size={18} />} hint={`Signed in as ${data.me.email}`}>
          <form onSubmit={changePassword} noValidate className="space-y-4">
            <Field id="pw-current" label="Current password">
              <input id="pw-current" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} className={inputClass} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field id="pw-new" label="New password" hint="At least 10 characters.">
                <input id="pw-new" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} className={inputClass} />
              </Field>
              <Field id="pw-again" label="Repeat new password">
                <input id="pw-again" type="password" autoComplete="new-password" value={again} onChange={(e) => setAgain(e.target.value)} className={inputClass} />
              </Field>
            </div>
            <ErrorNote>{pw.error}</ErrorNote>
            <div className="flex flex-wrap gap-2">
              <button type="submit" disabled={pw.busy !== null || !current || !next} className={btn.primary}>
                {pw.busy && <Spinner />}
                Change password
              </button>
              <button
                type="button"
                onClick={() => supabase.auth.signOut({ scope: 'global' })}
                className={btn.danger}
              >
                <LogOut size={15} />
                Sign out on all devices
              </button>
            </div>
          </form>
        </Panel>
      )}

      <Panel title="Security & privacy settings">
        <form onSubmit={savePrivacy} noValidate className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="idle" label="Auto-lock (minutes)" hint="The admin panel signs out after this long without activity.">
              <input id="idle" type="number" inputMode="numeric" min={5} max={240} value={idle} onChange={(e) => setIdle(e.target.value)} className={`${inputClass} font-mono`} />
            </Field>
            <Field id="keep" label="Delete builds after (days)" hint="Stored APKs older than this are removed. 0 keeps them until deleted by hand.">
              <input id="keep" type="number" inputMode="numeric" min={0} max={365} value={keep} onChange={(e) => setKeep(e.target.value)} className={`${inputClass} font-mono`} />
            </Field>
          </div>
          <Toggle
            checked={privacy.storeProfiles}
            onChange={(v) => setPrivacy((p) => ({ ...p, storeProfiles: v }))}
            label="Store Telegram names and usernames"
            description="When off, only the numeric Telegram ID is kept, and names already stored are erased on save."
          />
          <ErrorNote>{pr.error}</ErrorNote>
          <button type="submit" disabled={pr.busy !== null} className={btn.primary}>
            {pr.busy && <Spinner />}
            Save settings
          </button>
        </form>
        <ul className="space-y-1.5 border-t-2 border-ink/10 pt-4 text-[13px] leading-snug text-ink-soft">
          <li>The bot token is stored encrypted and never leaves the server.</li>
          <li>Telegram’s calls to the bot are only accepted with the secret registered for this site.</li>
          <li>Every admin request is checked against your signed-in session, and each change is written to the Activity log.</li>
          <li>“Delete data” on a user removes their record, their builds and their signing certificate.</li>
        </ul>
      </Panel>
    </>
  );
}

export function ActivitySection({ data }: SectionProps) {
  return (
    <section className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-baseline gap-x-3 border-b-2 border-ink px-4 py-3 sm:px-6">
        <h2 className="font-display text-xl font-bold tracking-tight">Activity</h2>
        <p className="text-sm text-ink-soft">Last {data.audit.length} admin actions</p>
      </header>
      {data.audit.length === 0 ? (
        <p className="px-4 py-10 text-center text-sm text-ink-soft sm:px-6">Nothing has been recorded yet.</p>
      ) : (
        <ul className="divide-y divide-ink/10">
          {data.audit.map((entry) => (
            <li key={entry.id} className="flex flex-wrap items-baseline gap-x-3 gap-y-0.5 px-4 py-2.5 sm:px-6">
              <span className="w-40 shrink-0 font-mono text-[12px] text-ink-soft">{dateTime(entry.created_at)}</span>
              <span className="text-[15px] font-semibold">{entry.action}</span>
              {entry.detail && <span className="min-w-0 break-words text-sm text-ink-soft">{entry.detail}</span>}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
