// Entry for the admin panel. It is built as its own page at /fhl/admin, so the
// public site's code contains no link or reference to it.
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '../index.css'
import AdminApp from './AdminApp.tsx'
import { handleGoogleRedirect } from '../lib/googleAuth.ts'

handleGoogleRedirect()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AdminApp />
  </StrictMode>,
)
