import { useState } from 'react';
import { Check, Copy, KeyRound, Trash2, UserCog, UserPlus } from 'lucide-react';
import type { AdminAccount, SectionProps } from '../lib/types';
import { dateTime, timeAgo } from '../lib/util';
import { Field, Segmented, Spinner, inputClass } from '../components/ui';
import { Badge, ErrorNote, Panel, btn, useAction } from './kit';

type Role = AdminAccount['role'];
type Method = AdminAccount['method'];
interface Secret {
  email: string;
  password: string;
  fresh: boolean;
}

const EMAIL = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;
const MAX_ADMINS = 10;
const roleName = (role: Role) => (role === 'super_admin' ? 'Super admin' : 'Admin');

function SecretBox({ secret, onDone }: { secret: Secret; onDone: () => void }) {
  const [copied, setCopied] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const address = `${window.location.origin}/fhl/admin/`;
  return (
    <div role="status" className="reveal space-y-2 rounded-md border-2 border-ink bg-droid-wash p-3">
      <p className="text-sm font-semibold">
        {secret.fresh ? `Account created for ${secret.email}.` : `New password set for ${secret.email}.`} Copy the temporary password now — it
        won’t be shown again.
      </p>
      <div className="flex items-start gap-2">
        <code className="min-w-0 flex-1 break-all rounded border border-ink/25 bg-white px-2 py-1.5 font-mono text-[13px]">{secret.password}</code>
        <button
          type="button"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(secret.password);
              setCopied(true);
              setBlocked(false);
              window.setTimeout(() => setCopied(false), 1800);
            } catch {
              setBlocked(true);
            }
          }}
          className={`${btn.plain} shrink-0 px-2.5`}
        >
          {copied ? <Check size={15} /> : <Copy size={15} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      {blocked && <p className="text-sm font-medium text-signal-deep">Your browser blocked clipboard access. Select the password and copy it by hand.</p>}
      <p className="text-[13px] leading-snug text-ink-soft">
        Send it to them privately, together with the sign-in address <span className="break-all font-mono text-ink">{address}</span>. They should
        change the password under Security & privacy after their first sign-in.
      </p>
      <button type="button" onClick={onDone} className={btn.plain}>
        Done
      </button>
    </div>
  );
}

function AdminRow({ account, act, toast, onSecret }: { account: AdminAccount; onSecret: (s: Secret) => void } & Pick<SectionProps, 'act' | 'toast'>) {
  const [confirm, setConfirm] = useState(false);
  const a = useAction();
  const busy = a.busy !== null;
  const other: Role = account.role === 'super_admin' ? 'admin' : 'super_admin';

  return (
    <li className="py-3">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 border-ink bg-droid-wash font-display text-lg font-bold">
          {account.email.charAt(0).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1 basis-48">
          <p className="break-all text-[15px] font-semibold leading-tight">{account.email}</p>
          <p className="font-mono text-[12px] text-ink-soft">
            {account.method === 'google' ? 'Google' : 'Password'} sign-in · {account.last_login_at ? `last sign-in ${timeAgo(account.last_login_at)}` : 'has not signed in yet'} · added{' '}
            {dateTime(account.created_at)}
          </p>
        </div>
        <Badge tone={account.role === 'super_admin' ? 'good' : 'plain'}>{roleName(account.role)}</Badge>
        {account.you && <Badge tone="warn">You</Badge>}
      </div>

      {!account.you && (
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={async () => {
              if (await a.run('role', () => act('setAdminRole', { id: account.id, role: other }))) toast(`${account.email} is now ${roleName(other).toLowerCase()}`);
            }}
            className={btn.plain}
          >
            {a.busy === 'role' ? <Spinner /> : <UserCog size={15} />}
            Make {roleName(other).toLowerCase()}
          </button>
          {account.method === 'password' && (
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                a.run('reset', async () => {
                  const result = await act<{ email: string; password: string }>('resetAdminPassword', { id: account.id });
                  onSecret({ email: result.email, password: result.password, fresh: false });
                })
              }
              className={btn.plain}
            >
              {a.busy === 'reset' ? <Spinner /> : <KeyRound size={15} />}
              Reset password
            </button>
          )}
          {confirm ? (
            <>
              <button
                type="button"
                disabled={busy}
                onClick={async () => {
                  if (await a.run('remove', () => act('removeAdmin', { id: account.id }))) toast('Admin removed');
                  else setConfirm(false);
                }}
                className={`${btn.danger} bg-signal`}
              >
                {a.busy === 'remove' ? <Spinner /> : <Trash2 size={15} />}
                Yes, remove access
              </button>
              <button type="button" disabled={busy} onClick={() => setConfirm(false)} className={btn.plain}>
                Keep
              </button>
            </>
          ) : (
            <button type="button" disabled={busy} onClick={() => setConfirm(true)} className={btn.danger}>
              <Trash2 size={15} />
              Remove
            </button>
          )}
        </div>
      )}
      {a.error && (
        <div className="mt-2">
          <ErrorNote>{a.error}</ErrorNote>
        </div>
      )}
    </li>
  );
}

export function AdminsSection({ data, act, toast }: SectionProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role>('admin');
  const [method, setMethod] = useState<Method>('google');
  const [emailError, setEmailError] = useState<string | null>(null);
  const [secret, setSecret] = useState<Secret | null>(null);
  const a = useAction();
  const full = data.admins.length >= MAX_ADMINS;

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const value = email.trim().toLowerCase();
    if (!EMAIL.test(value)) {
      setEmailError('Enter a valid e-mail address.');
      return;
    }
    a.setError(null);
    const ok = await a.run('add', async () => {
      const result = await act<{ email: string; password: string | null }>('addAdmin', { email: value, role, method });
      if (result.password) setSecret({ email: result.email, password: result.password, fresh: true });
      else toast(`${result.email} can now sign in with Google`);
    });
    if (ok) {
      setEmail('');
      setRole('admin');
    }
  };

  return (
    <>
      <Panel title="Admin accounts" icon={<UserCog size={18} />} hint={`${data.admins.length} of ${MAX_ADMINS}`}>
        {secret && <SecretBox secret={secret} onDone={() => setSecret(null)} />}
        <ul className="divide-y-2 divide-ink/10">
          {data.admins.map((account) => (
            <AdminRow key={account.id} account={account} act={act} toast={toast} onSecret={setSecret} />
          ))}
        </ul>
        <ul className="space-y-1.5 border-t-2 border-ink/10 pt-4 text-[13px] leading-snug text-ink-soft">
          <li>
            <span className="font-semibold text-ink">Super admin:</span> everything, including adding or removing admins and connecting the bot.
          </li>
          <li>
            <span className="font-semibold text-ink">Admin:</span> users, builds, branding, access, follow and privacy settings — but not admin
            accounts or the bot token.
          </li>
          <li>
            <span className="font-semibold text-ink">Google sign-in:</span> only the Gmail addresses listed here get in, and only through Google’s own
            sign-in — a password for the same address is not accepted.
          </li>
          <li>Removing an admin ends their access immediately. You can’t remove or demote yourself, so one super admin always remains.</li>
        </ul>
      </Panel>

      <Panel title="Add an admin" icon={<UserPlus size={18} />} hint="By Gmail address, or with a password">
        <form onSubmit={add} noValidate className="space-y-5">
          <Field id="new-admin-email" label={method === 'google' ? 'Gmail address' : 'E-mail'} error={emailError ?? undefined}>
            <input
              id="new-admin-email"
              type="email"
              autoComplete="off"
              spellCheck={false}
              autoCapitalize="none"
              maxLength={120}
              placeholder={method === 'google' ? 'name@gmail.com' : 'name@example.com'}
              value={email}
              aria-invalid={Boolean(emailError)}
              aria-describedby={emailError ? 'new-admin-email-error' : undefined}
              onChange={(e) => {
                setEmail(e.target.value);
                setEmailError(null);
                a.setError(null);
              }}
              className={inputClass}
            />
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Segmented<Method>
              label="Signs in with"
              value={method}
              onChange={setMethod}
              options={[
                { value: 'google', label: 'Google' },
                { value: 'password', label: 'Password' },
              ]}
            />
            <Segmented<Role>
              label="Role"
              value={role}
              onChange={setRole}
              options={[
                { value: 'admin', label: 'Admin' },
                { value: 'super_admin', label: 'Super admin' },
              ]}
            />
          </div>
          <ErrorNote>{a.error}</ErrorNote>
          <button type="submit" disabled={a.busy !== null || full} className={btn.primary}>
            {a.busy ? <Spinner /> : <UserPlus size={16} />}
            {a.busy ? 'Creating…' : 'Add admin'}
          </button>
          <p className="text-[13px] leading-snug text-ink-soft">
            {full
              ? `You have reached ${MAX_ADMINS} admin accounts. Remove one to add another.`
              : method === 'google'
                ? 'They open the admin address and choose “Continue with Google” with exactly this account. No password is created and no e-mail is sent.'
                : 'A temporary password is generated and shown once, for you to pass on. No e-mail is sent.'}
          </p>
        </form>
      </Panel>
    </>
  );
}
