import { useState, type ReactNode } from 'react';

const base =
  'inline-flex items-center justify-center gap-1.5 rounded-md border-2 border-ink px-3 py-2 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep focus-visible:ring-offset-2 focus-visible:ring-offset-card disabled:cursor-not-allowed disabled:opacity-50';

export const btn = {
  plain: `${base} bg-white hover:bg-droid-wash`,
  primary: `${base} bg-droid hover:bg-droid/80`,
  dark: `${base} bg-ink text-paper hover:bg-droid-deep`,
  danger: `${base} bg-white hover:bg-signal-wash`,
  telegram: `${base} bg-telegram hover:bg-telegram/80`,
};

export function Panel({ title, hint, icon, children }: { title: string; hint?: string; icon?: ReactNode; children: ReactNode }) {
  return (
    <section className="rounded-xl border-2 border-ink bg-card shadow-hard">
      <header className="flex flex-wrap items-center gap-x-3 gap-y-1 border-b-2 border-ink px-4 py-3 sm:px-6">
        {icon}
        <h2 className="font-display text-xl font-bold tracking-tight">{title}</h2>
        {hint && <p className="w-full text-sm text-ink-soft sm:ml-auto sm:w-auto">{hint}</p>}
      </header>
      <div className="space-y-5 px-4 py-5 sm:px-6">{children}</div>
    </section>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <p role="alert" className="rounded-md border-2 border-signal bg-signal-wash px-3 py-2 text-sm font-medium">
      {children}
    </p>
  );
}

export function Badge({ tone, children }: { tone: 'good' | 'warn' | 'bad' | 'plain'; children: ReactNode }) {
  const tones = {
    good: 'border-droid-deep/50 bg-droid-wash text-droid-deep',
    warn: 'border-ink/30 bg-paper-deep text-ink',
    bad: 'border-signal bg-signal-wash text-signal-deep',
    plain: 'border-ink/30 bg-white text-ink-soft',
  };
  return (
    <span className={`inline-block whitespace-nowrap rounded border px-1.5 py-0.5 font-mono text-[11px] font-bold ${tones[tone]}`}>
      {children}
    </span>
  );
}

/** Tracks which action is running and the last error, for one section. */
export function useAction() {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const run = async (id: string, fn: () => Promise<unknown>): Promise<boolean> => {
    setBusy(id);
    setError(null);
    try {
      await fn();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
      return false;
    } finally {
      setBusy(null);
    }
  };
  return { busy, error, run, setError };
}

export const label = 'mb-1.5 block font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft';
