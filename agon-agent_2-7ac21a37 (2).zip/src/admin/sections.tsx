import { useRef, useState } from 'react';
import { Bot, CheckCircle2, Circle, ExternalLink, Eye, EyeOff, ImageUp, PlugZap, RefreshCw, Stethoscope, Trash2, Unplug } from 'lucide-react';
import type { BotTest, SectionProps } from '../lib/types';
import { dateTime, trialLabel } from '../lib/util';
import { Field, Segmented, Spinner, Toggle, inputClass } from '../components/ui';
import { ErrorNote, Panel, btn, useAction } from './kit';

export function Overview({ data, go }: SectionProps) {
  const s = data.stats;
  const tiles: [string, number][] = [
    ['Bot users', s.users],
    ['On free trial', s.trials],
    ['With access', s.access],
    ['Trial ended', s.expired],
    ['Stored builds', s.builds],
  ];
  const branded = data.settings.site.name !== 'Web2APK' || Boolean(data.settings.site.logoUrl);
  const steps = [
    {
      done: Boolean(data.bot),
      title: 'Connect your Telegram bot',
      body: data.bot ? `@${data.bot.username} is connected and answering.` : 'Paste the token from @BotFather to switch the bot on.',
      tab: 'bot' as const,
    },
    {
      done: branded,
      title: 'Set your name and logo',
      body: branded ? `The site and bot use “${data.settings.site.name}”.` : 'Give the site and the bot your own name and logo.',
      tab: 'branding' as const,
    },
    {
      done: Boolean(data.settings.access.contact),
      title: 'Add a contact for expired trials',
      body: data.settings.access.contact
        ? `People are sent to @${data.settings.access.contact} when their trial ends.`
        : 'Tell people who to message when their free trial ends.',
      tab: 'access' as const,
    },
  ];

  return (
    <>
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        {tiles.map(([name, value]) => (
          <li key={name} className="rounded-xl border-2 border-ink bg-card px-4 py-3 shadow-hard-sm">
            <p className="font-display text-3xl font-extrabold leading-none">{value.toLocaleString('en-US')}</p>
            <p className="mt-1.5 font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">{name}</p>
          </li>
        ))}
      </ul>

      <Panel title="Setup" hint={`${steps.filter((x) => x.done).length} of ${steps.length} done`}>
        <ol className="space-y-3">
          {steps.map((step) => (
            <li key={step.title} className="flex flex-wrap items-center gap-3 rounded-md border-2 border-ink/20 bg-white px-3 py-3">
              {step.done ? <CheckCircle2 size={22} className="shrink-0 text-droid-deep" /> : <Circle size={22} className="shrink-0 text-ink-faint" />}
              <div className="min-w-0 flex-1 basis-48">
                <p className="font-semibold leading-tight">{step.title}</p>
                <p className="mt-0.5 text-sm text-ink-soft">{step.body}</p>
              </div>
              <button type="button" onClick={() => go(step.tab)} className={step.done ? btn.plain : btn.primary}>
                {step.done ? 'Change' : 'Set up'}
              </button>
            </li>
          ))}
        </ol>
      </Panel>

      <Panel title="How access works right now">
        <ul className="space-y-2 text-[15px] leading-relaxed text-ink-soft">
          <li>
            <span className="font-semibold text-ink">Free trial:</span>{' '}
            {data.settings.access.trialHours > 0
              ? `every new bot user gets a ${trialLabel(data.settings.access.trialHours)} free trial from their first message.`
              : 'switched off — new bot users need access from you before they can build.'}
          </li>
          <li>
            <span className="font-semibold text-ink">Bot:</span>{' '}
            {data.settings.access.botAccess === 'approved' ? 'new users wait for your approval.' : 'open to anyone who starts it.'}
          </li>
          <li>
            <span className="font-semibold text-ink">Follow:</span>{' '}
            {data.settings.follow.required
              ? `people must join @${data.settings.follow.channel} before they can build in the bot.`
              : 'no channel has to be joined before building.'}
          </li>
          <li>
            <span className="font-semibold text-ink">Website builder:</span> {data.settings.access.webBuilder ? 'open to visitors.' : 'switched off.'}{' '}
            <span className="font-semibold text-ink">API keys:</span> {data.settings.access.apiKeys ? 'allowed.' : 'switched off.'}
          </li>
        </ul>
        <button type="button" onClick={() => go('access')} className={btn.plain}>
          Change access settings
        </button>
      </Panel>
    </>
  );
}

export function BotSection({ data, act, toast }: SectionProps) {
  const [token, setToken] = useState('');
  const [show, setShow] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [test, setTest] = useState<BotTest | null>(null);
  const a = useAction();
  const bot = data.bot;

  const connect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) {
      a.setError('Paste the bot token from @BotFather first.');
      return;
    }
    if (await a.run('connect', () => act('connectBot', { token: token.trim() }))) {
      setToken('');
      setTest(null);
      toast('Bot connected');
    }
  };

  if (!bot) {
    return (
      <Panel title="Connect a Telegram bot" icon={<Bot size={18} />}>
        <ol className="space-y-2 text-[15px] leading-relaxed text-ink-soft">
          <li>
            <span className="font-semibold text-ink">1.</span> In Telegram, open{' '}
            <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer" className="font-semibold text-ink underline underline-offset-4">
              @BotFather
            </a>{' '}
            and send <code className="font-mono text-ink">/newbot</code>. Choose a name and a username.
          </li>
          <li>
            <span className="font-semibold text-ink">2.</span> BotFather replies with a token that looks like{' '}
            <code className="font-mono text-ink">123456789:AAE…</code>
          </li>
          <li>
            <span className="font-semibold text-ink">3.</span> Paste it below. The bot starts answering straight away.
          </li>
        </ol>
        <form onSubmit={connect} noValidate className="space-y-3">
          <Field id="bot-token" label="Bot token">
            <div className="flex gap-2">
              <input
                id="bot-token"
                type={show ? 'text' : 'password'}
                autoComplete="off"
                spellCheck={false}
                placeholder="123456789:AAE…"
                value={token}
                aria-invalid={Boolean(a.error)}
                onChange={(e) => {
                  setToken(e.target.value);
                  a.setError(null);
                }}
                className={`${inputClass} font-mono`}
              />
              <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? 'Hide token' : 'Show token'} className={`${btn.plain} shrink-0 px-2.5`}>
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </Field>
          <ErrorNote>{a.error}</ErrorNote>
          <button type="submit" disabled={a.busy !== null} className={btn.primary}>
            {a.busy ? <Spinner /> : <PlugZap size={16} />}
            {a.busy ? 'Connecting…' : 'Connect bot'}
          </button>
        </form>
        <p className="text-[13px] leading-snug text-ink-soft">
          The token is stored encrypted on the server and is never shown again or sent back to a browser.
        </p>
      </Panel>
    );
  }

  return (
    <Panel title="Telegram bot" icon={<Bot size={18} />} hint="Connected">
      <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
        {[
          ['Bot', `${bot.name} · @${bot.username}`],
          ['Token', bot.hint],
          ['Connected', dateTime(bot.connectedAt)],
          ['Webhook', bot.webhookUrl],
        ].map(([k, v]) => (
          <div key={k} className="min-w-0">
            <dt className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">{k}</dt>
            <dd className="mt-0.5 break-all text-[15px]">{v}</dd>
          </div>
        ))}
      </dl>

      <div className="flex flex-wrap gap-2">
        <a href={`https://t.me/${bot.username}`} target="_blank" rel="noopener noreferrer" className={btn.telegram}>
          <ExternalLink size={15} />
          Open bot
        </a>
        <button
          type="button"
          disabled={a.busy !== null}
          onClick={() => a.run('test', async () => setTest((await act<{ test: BotTest }>('testBot')).test))}
          className={btn.plain}
        >
          {a.busy === 'test' ? <Spinner /> : <Stethoscope size={15} />}
          Test connection
        </button>
        <button
          type="button"
          disabled={a.busy !== null}
          onClick={async () => {
            if (await a.run('repair', () => act('repairBot'))) {
              setTest(null);
              toast('Webhook registered again');
            }
          }}
          className={btn.plain}
        >
          {a.busy === 'repair' ? <Spinner /> : <RefreshCw size={15} />}
          Re-register webhook
        </button>
        {confirm ? (
          <>
            <button
              type="button"
              disabled={a.busy !== null}
              onClick={async () => {
                if (await a.run('disconnect', () => act('disconnectBot'))) {
                  setConfirm(false);
                  toast('Bot disconnected');
                }
              }}
              className={`${btn.danger} bg-signal`}
            >
              {a.busy === 'disconnect' ? <Spinner /> : <Unplug size={15} />}
              Yes, disconnect
            </button>
            <button type="button" onClick={() => setConfirm(false)} className={btn.plain}>
              Keep connected
            </button>
          </>
        ) : (
          <button type="button" onClick={() => setConfirm(true)} className={btn.danger}>
            <Unplug size={15} />
            Disconnect
          </button>
        )}
      </div>
      <ErrorNote>{a.error}</ErrorNote>

      {test && (
        <div role="status" className={`rounded-md border-2 px-3 py-2.5 text-sm ${test.ok ? 'border-droid-deep/40 bg-droid-wash' : 'border-signal bg-signal-wash'}`}>
          {test.error ? (
            <p className="font-semibold">{test.error}</p>
          ) : (
            <>
              <p className="font-semibold">{test.ok ? `@${test.username} is connected and Telegram is delivering messages here.` : 'Telegram answered, but something needs attention.'}</p>
              <ul className="mt-1 space-y-0.5 text-ink-soft">
                {!test.matches && <li>The webhook points somewhere else. Use “Re-register webhook”.</li>}
                {test.lastError && (
                  <li>
                    Last delivery error ({dateTime(test.lastErrorAt ?? null)}): {test.lastError}
                  </li>
                )}
                <li>Messages waiting: {test.pending}</li>
              </ul>
            </>
          )}
        </div>
      )}
    </Panel>
  );
}

export function BrandingSection({ data, act, toast }: SectionProps) {
  const [name, setName] = useState(data.settings.site.name);
  const [tagline, setTagline] = useState(data.settings.site.tagline);
  const fileRef = useRef<HTMLInputElement>(null);
  const a = useAction();
  const logo = data.settings.site.logoUrl;

  const upload = (file: File) => {
    if (file.size > 512 * 1024) {
      a.setError('Keep the logo under 512 KB.');
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => a.setError('That file could not be read.');
    reader.onload = async () => {
      const fileBase64 = String(reader.result).split(',')[1] ?? '';
      if (await a.run('logo', () => act('uploadLogo', { fileBase64 }))) toast('Logo updated');
    };
    reader.readAsDataURL(file);
  };

  return (
    <Panel title="Name & logo" hint="Shown on the site, the browser tab and in the bot">
      <form
        noValidate
        className="space-y-5"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!name.trim()) {
            a.setError('Give the site a name.');
            return;
          }
          if (await a.run('save', () => act('saveSite', { site: { name, tagline } }))) toast('Saved');
        }}
      >
        <Field id="site-name" label="Site name" hint="Up to 30 characters.">
          <input id="site-name" type="text" maxLength={30} value={name} onChange={(e) => setName(e.target.value)} className={inputClass} />
        </Field>
        <Field id="site-tagline" label="Tagline" hint="Optional. Replaces the paragraph under the headline on the home page.">
          <textarea id="site-tagline" rows={3} maxLength={220} value={tagline} onChange={(e) => setTagline(e.target.value)} className={`${inputClass} resize-y`} />
        </Field>
        <button type="submit" disabled={a.busy !== null} className={btn.primary}>
          {a.busy === 'save' && <Spinner />}
          Save name
        </button>
      </form>

      <div className="flex flex-wrap items-center gap-4 border-t-2 border-ink/10 pt-5">
        <span className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border-2 border-ink bg-paper-deep">
          {logo ? <img src={logo} alt="Current logo" className="h-full w-full object-cover" /> : <span className="px-2 text-center text-[11px] text-ink-soft">No logo</span>}
        </span>
        <div className="min-w-0 flex-1 basis-48 space-y-2">
          <p className="font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">Logo</p>
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="sr-only"
              tabIndex={-1}
              aria-hidden
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) upload(file);
                e.target.value = '';
              }}
            />
            <button type="button" disabled={a.busy !== null} onClick={() => fileRef.current?.click()} className={btn.plain}>
              {a.busy === 'logo' ? <Spinner /> : <ImageUp size={15} />}
              {logo ? 'Replace logo' : 'Upload logo'}
            </button>
            {logo && (
              <button
                type="button"
                disabled={a.busy !== null}
                onClick={async () => {
                  if (await a.run('remove', () => act('removeLogo'))) toast('Logo removed');
                }}
                className={btn.danger}
              >
                <Trash2 size={15} />
                Remove
              </button>
            )}
          </div>
          <p className="text-[13px] text-ink-soft">Square PNG, JPG or WebP, up to 512 KB.</p>
        </div>
      </div>
      <ErrorNote>{a.error}</ErrorNote>
    </Panel>
  );
}

export function AccessSection({ data, act, toast }: SectionProps) {
  const [form, setForm] = useState(data.settings.access);
  const [hours, setHours] = useState(String(data.settings.access.trialHours));
  const a = useAction();
  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));

  return (
    <Panel title="Access & trial" hint="Who can build, and for how long">
      <form
        noValidate
        className="space-y-5"
        onSubmit={async (e) => {
          e.preventDefault();
          const trialHours = Number(hours);
          if (hours.trim() === '' || !Number.isInteger(trialHours) || trialHours < 0 || trialHours > 720) {
            a.setError('Trial length must be a whole number of hours from 0 to 720.');
            return;
          }
          if (await a.run('save', () => act('saveAccess', { access: { ...form, trialHours } }))) toast('Saved');
        }}
      >
        <div className="grid gap-5 sm:grid-cols-2">
          <Field id="trial-hours" label="Free trial (hours)" hint="24 = one day. Starts with a person’s first message to the bot. 0 switches the trial off.">
            <input id="trial-hours" type="number" inputMode="numeric" min={0} max={720} value={hours} onChange={(e) => setHours(e.target.value)} className={`${inputClass} font-mono`} />
          </Field>
          <Segmented
            label="Who can use the bot"
            value={form.botAccess}
            onChange={(v) => set({ botAccess: v })}
            options={[
              { value: 'open', label: 'Anyone' },
              { value: 'approved', label: 'Approved only' },
            ]}
          />
        </div>
        <div className="grid gap-2.5 sm:grid-cols-2">
          <Toggle checked={form.webBuilder} onChange={(v) => set({ webBuilder: v })} label="Website builder" description="Let visitors build APKs on the website" />
          <Toggle checked={form.apiKeys} onChange={(v) => set({ apiKeys: v })} label="API keys" description="Let visitors create keys and build over the API" />
        </div>
        <Field id="contact" label="Contact for access" hint="Telegram username shown to people whose trial has ended.">
          <input id="contact" type="text" spellCheck={false} autoCapitalize="none" maxLength={40} placeholder="@yourname" value={form.contact} onChange={(e) => set({ contact: e.target.value })} className={`${inputClass} font-mono`} />
        </Field>
        <Field id="welcome" label="Welcome message" hint="Optional extra line in the bot’s greeting.">
          <textarea id="welcome" rows={3} maxLength={300} value={form.welcome} onChange={(e) => set({ welcome: e.target.value })} className={`${inputClass} resize-y`} />
        </Field>
        <ErrorNote>{a.error}</ErrorNote>
        <button type="submit" disabled={a.busy !== null} className={btn.primary}>
          {a.busy && <Spinner />}
          Save access settings
        </button>
      </form>
    </Panel>
  );
}
