import { useCallback, useEffect, useRef, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { Activity, ArrowLeft, Bot, Eye, EyeOff, LayoutDashboard, Lock, LogOut, Megaphone, Package, Palette, ShieldCheck, Timer, UserCog, Users } from 'lucide-react';
import supabase from '../lib/supabase';
import { adminGet, adminPost } from '../lib/adminApi';
import { signInWithGoogle } from '../lib/googleAuth';
import { ApiError } from '../lib/api';
import type { AdminData, AdminTab } from '../lib/types';
import { Spinner, inputClass } from '../components/ui';
import { ErrorNote, btn, label } from './kit';
import { AccessSection, BotSection, BrandingSection, Overview } from './sections';
import { ActivitySection, BuildsSection, SecuritySection, UsersSection } from './sections2';
import { FollowSection } from './follow';
import { AdminsSection } from './admins';

const TABS: { id: AdminTab; label: string; icon: typeof Bot }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'bot', label: 'Telegram bot', icon: Bot },
  { id: 'branding', label: 'Name & logo', icon: Palette },
  { id: 'access', label: 'Access & trial', icon: Timer },
  { id: 'follow', label: 'Follow & social', icon: Megaphone },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'builds', label: 'Builds', icon: Package },
  { id: 'admins', label: 'Admin accounts', icon: UserCog },
  { id: 'security', label: 'Security & privacy', icon: ShieldCheck },
  { id: 'activity', label: 'Activity', icon: Activity },
];

function GoogleMark() {
  return (
    <svg viewBox="0 0 18 18" width="18" height="18" aria-hidden>
      <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" />
      <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z" />
      <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" />
      <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" />
    </svg>
  );
}

function Login({ notice }: { notice: string | null }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [waiting, setWaiting] = useState(false);

  const google = () => {
    setError(null);
    const started = signInWithGoogle('Web2APK admin', (message) => {
      setWaiting(false);
      setError(message);
    });
    if (started === 'blocked') setError('Your browser blocked the Google window. Allow pop-ups for this page and try again.');
    else if (started === 'unavailable') setError('Google sign-in is not available here. Use your e-mail and password.');
    else setWaiting(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setError('Enter your admin e-mail and password.');
      return;
    }
    setBusy(true);
    setError(null);
    const { error: failed } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (failed) {
      setBusy(false);
      setError(/invalid login/i.test(failed.message) ? 'Wrong e-mail or password.' : failed.message);
      return;
    }
    setBusy(false);
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-10">
      <div className="rounded-xl border-2 border-ink bg-card shadow-hard">
        <header className="flex items-center gap-3 border-b-2 border-ink px-5 py-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg border-2 border-ink bg-droid shadow-hard-sm">
            <Lock size={18} strokeWidth={2.5} />
          </span>
          <div>
            <h1 className="font-display text-2xl font-extrabold leading-none tracking-tight">Admin sign in</h1>
            <p className="mt-1 text-sm text-ink-soft">Authorised accounts only</p>
          </div>
        </header>
        <form onSubmit={submit} noValidate className="space-y-4 px-5 py-5">
          {notice && (
            <p role="status" className="rounded-md border-2 border-ink/20 bg-white px-3 py-2 text-sm">
              {notice}
            </p>
          )}
          <button type="button" onClick={google} className={`${btn.plain} w-full py-3 text-base`}>
            <GoogleMark />
            Continue with Google
          </button>
          {waiting && (
            <p role="status" className="text-center text-sm text-ink-soft">
              Choose your account in the Google window. This page continues by itself.
            </p>
          )}
          <p className="flex items-center gap-3 font-mono text-[11px] font-bold uppercase tracking-widest text-ink-soft">
            <span className="h-0.5 flex-1 bg-ink/15" aria-hidden />
            or use a password
            <span className="h-0.5 flex-1 bg-ink/15" aria-hidden />
          </p>
          <div>
            <label htmlFor="admin-email" className={label}>
              E-mail
            </label>
            <input id="admin-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
          </div>
          <div>
            <label htmlFor="admin-password" className={label}>
              Password
            </label>
            <div className="flex gap-2">
              <input
                id="admin-password"
                type={show ? 'text' : 'password'}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={inputClass}
              />
              <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? 'Hide password' : 'Show password'} className={`${btn.plain} shrink-0 px-2.5`}>
                {show ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>
          <ErrorNote>{error}</ErrorNote>
          <button type="submit" disabled={busy} className={`${btn.dark} w-full py-3 text-base`}>
            {busy ? <Spinner /> : <Lock size={16} />}
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
      <a href="/" className="mt-5 inline-flex items-center gap-1.5 self-center text-sm font-semibold text-ink-soft underline decoration-ink/30 underline-offset-4 hover:text-ink">
        <ArrowLeft size={14} />
        Back to the site
      </a>
    </main>
  );
}

export default function AdminApp() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [data, setData] = useState<AdminData | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tab, setTab] = useState<AdminTab>('overview');
  const [toast, setToast] = useState<string | null>(null);
  const lastActive = useRef(Date.now());
  const userId = session?.user.id ?? null;
  const wasSignedOut = useRef(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: s }) => {
      setSession(s.session);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = useCallback(async (message: string | null) => {
    setNotice(message);
    setData(null);
    await supabase.auth.signOut({ scope: 'local' });
  }, []);

  const refresh = useCallback(async () => {
    try {
      setData(await adminGet());
      setLoadError(null);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
        const who = (await supabase.auth.getSession()).data.session?.user.email;
        await signOut(
          err.status === 403
            ? `${who ?? 'That account'} is not an admin account. Ask a super admin to add it under Admin accounts.`
            : 'Your session ended. Sign in again.',
        );
      } else {
        setLoadError(err instanceof Error ? err.message : 'The admin panel could not be loaded');
      }
    }
  }, [signOut]);

  useEffect(() => {
    if (!ready) return;
    if (!userId) {
      wasSignedOut.current = true;
      return;
    }
    if (wasSignedOut.current) {
      // A fresh sign-in (Google or password): record it in the activity log, then load the panel.
      wasSignedOut.current = false;
      adminPost('login')
        .catch(() => undefined)
        .finally(refresh);
    } else {
      refresh();
    }
  }, [ready, userId, refresh]);

  useEffect(() => {
    document.title = `Admin · ${data?.settings.site.name ?? 'Web2APK'}`;
  }, [data]);

  // Auto-lock: sign out after the configured minutes without any input.
  const idleMinutes = data?.settings.privacy.idleMinutes ?? 30;
  useEffect(() => {
    if (!userId) return;
    lastActive.current = Date.now();
    const touch = () => {
      lastActive.current = Date.now();
    };
    const events = ['pointerdown', 'keydown', 'scroll'] as const;
    events.forEach((name) => window.addEventListener(name, touch, { passive: true }));
    const timer = window.setInterval(() => {
      if (Date.now() - lastActive.current > idleMinutes * 60000) {
        signOut(`Signed out after ${idleMinutes} minutes without activity.`);
      }
    }, 15000);
    return () => {
      events.forEach((name) => window.removeEventListener(name, touch));
      window.clearInterval(timer);
    };
  }, [userId, idleMinutes, signOut]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const act = useCallback(
    async <T,>(action: string, payload?: object): Promise<T> => {
      const result = await adminPost<T>(action, payload);
      await refresh();
      return result;
    },
    [refresh],
  );

  if (!ready) return <p className="p-10 text-center font-mono text-sm text-ink-soft">Loading admin…</p>;
  if (!session) return <Login notice={notice} />;

  const props = data ? { data, act, toast: setToast, go: setTab } : null;

  return (
    <div className="min-h-screen">
      <header className="border-b-2 border-ink bg-paper/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-2 px-4 py-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="truncate font-display text-xl font-extrabold tracking-tight">{data?.settings.site.name ?? 'Web2APK'}</span>
            <span className="shrink-0 rounded border-2 border-ink bg-ink px-1.5 py-0.5 font-mono text-[11px] font-bold uppercase tracking-widest text-paper">Admin</span>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" aria-label="View site" className={`${btn.plain} px-2.5`}>
              <ArrowLeft size={15} />
              <span className="hidden sm:inline">View site</span>
            </a>
            <button type="button" onClick={() => signOut(null)} className={btn.dark}>
              <LogOut size={15} />
              Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <nav aria-label="Admin sections" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 lg:mx-0 lg:flex-col lg:overflow-visible lg:px-0">
          {TABS.filter((t) => t.id !== 'admins' || data?.me.role === 'super_admin').map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              aria-current={tab === t.id ? 'page' : undefined}
              className={`flex shrink-0 items-center gap-2 whitespace-nowrap rounded-md border-2 px-3 py-2 text-left text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-droid-deep ${
                tab === t.id ? 'border-ink bg-ink text-paper' : 'border-ink/20 bg-card hover:border-ink'
              }`}
            >
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
          <p className="hidden break-all pt-3 font-mono text-[11px] text-ink-soft lg:block">Signed in as {session.user.email}
            {data && ` · ${data.me.role === 'super_admin' ? 'super admin' : 'admin'}`}
          </p>
        </nav>

        <main className="min-w-0 space-y-6">
          {loadError && (
            <div role="alert" className="flex flex-wrap items-center gap-3 rounded-xl border-2 border-signal bg-signal-wash px-4 py-3">
              <p className="min-w-0 flex-1 text-sm">
                <span className="font-semibold">The admin panel could not be loaded.</span> {loadError}
              </p>
              <button type="button" onClick={refresh} className={btn.plain}>
                Try again
              </button>
            </div>
          )}
          {!props && !loadError && (
            <div aria-busy="true" className="space-y-4">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-28 animate-pulse rounded-xl bg-ink/10" />
              ))}
            </div>
          )}
          {props && tab === 'overview' && <Overview {...props} />}
          {props && tab === 'bot' && <BotSection {...props} />}
          {props && tab === 'branding' && <BrandingSection {...props} />}
          {props && tab === 'access' && <AccessSection {...props} />}
          {props && tab === 'follow' && <FollowSection {...props} />}
          {props && tab === 'bot' && props.data.me.role !== 'super_admin' && (
            <p role="note" className="rounded-xl border-2 border-ink/20 bg-card px-4 py-3 text-sm text-ink-soft">
              Only a super admin can connect, re-register or disconnect the bot.
            </p>
          )}
          {props && tab === 'admins' && <AdminsSection {...props} />}
          {props && tab === 'users' && <UsersSection {...props} />}
          {props && tab === 'builds' && <BuildsSection {...props} />}
          {props && tab === 'security' && <SecuritySection {...props} />}
          {props && tab === 'activity' && <ActivitySection {...props} />}
        </main>
      </div>

      {toast && (
        <p role="status" className="reveal fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-lg border-2 border-ink bg-ink px-4 py-2.5 text-sm font-semibold text-paper shadow-hard-sm">
          {toast}
        </p>
      )}
    </div>
  );
}
