import { useState } from 'react';
import { Megaphone, Plus, Trash2 } from 'lucide-react';
import type { SectionProps } from '../lib/types';
import { Field, Spinner, Toggle, inputClass } from '../components/ui';
import { ErrorNote, Panel, btn, label, useAction } from './kit';

const MAX_LINKS = 5;

export function FollowSection({ data, act, toast, go }: SectionProps) {
  const saved = data.settings.follow;
  const [channel, setChannel] = useState(saved.channel ? `@${saved.channel}` : '');
  const [required, setRequired] = useState(saved.required);
  const [links, setLinks] = useState(saved.links);
  const a = useAction();
  const bot = data.bot;

  const setLink = (i: number, patch: Partial<{ label: string; url: string }>) =>
    setLinks((list) => list.map((l, n) => (n === i ? { ...l, ...patch } : l)));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (required && !channel.trim()) return a.setError('Add your Telegram channel before making it required.');
    const filled = links.filter((l) => l.label.trim() || l.url.trim());
    const broken = filled.find((l) => !l.label.trim() || !/^https:\/\/\S+\.\S+/.test(l.url.trim()));
    if (broken) return a.setError(`“${broken.label.trim() || broken.url.trim()}” needs both a name and a link starting with https://`);
    if (await a.run('save', () => act('saveFollow', { follow: { channel, required, links: filled } }))) {
      setLinks(filled);
      toast('Saved');
    }
    return undefined;
  };

  return (
    <Panel title="Follow & social" icon={<Megaphone size={18} />} hint="Ask people to follow you before they build">
      <form onSubmit={save} noValidate className="space-y-5">
        <Field id="follow-channel" label="Telegram channel or group" hint="Public username. Shown as a Join button in the bot and on the site.">
          <input
            id="follow-channel"
            type="text"
            spellCheck={false}
            autoCapitalize="none"
            autoComplete="off"
            maxLength={60}
            placeholder="@yourchannel"
            value={channel}
            onChange={(e) => {
              setChannel(e.target.value);
              a.setError(null);
            }}
            className={`${inputClass} font-mono`}
          />
        </Field>

        <Toggle
          checked={required}
          onChange={setRequired}
          label="Require joining before building"
          description={
            bot
              ? `The bot checks this before every build. @${bot.username} must be an administrator of the channel to see who has joined.`
              : 'The bot checks this before every build. Connect the bot first.'
          }
        />
        {!bot && (
          <button type="button" onClick={() => go('bot')} className={btn.plain}>
            Connect the bot
          </button>
        )}

        <div>
          <p className={label}>
            Other links · {links.length} of {MAX_LINKS}
          </p>
          {links.length === 0 ? (
            <p className="rounded-md border-2 border-dashed border-ink/30 px-3 py-3 text-sm text-ink-soft">
              No links yet. Add YouTube, Instagram, a website or anything else you want people to follow.
            </p>
          ) : (
            <ul className="space-y-2">
              {links.map((link, i) => (
                <li key={i} className="flex flex-col gap-2 sm:flex-row">
                  <input
                    type="text"
                    maxLength={24}
                    placeholder="Name, e.g. YouTube"
                    aria-label={`Link ${i + 1} name`}
                    value={link.label}
                    onChange={(e) => setLink(i, { label: e.target.value })}
                    className={`${inputClass} sm:w-44 sm:shrink-0`}
                  />
                  <div className="flex min-w-0 flex-1 gap-2">
                    <input
                      type="url"
                      inputMode="url"
                      spellCheck={false}
                      placeholder="https://…"
                      aria-label={`Link ${i + 1} address`}
                      value={link.url}
                      onChange={(e) => setLink(i, { url: e.target.value })}
                      className={`${inputClass} font-mono text-[13px]`}
                    />
                    <button type="button" onClick={() => setLinks((list) => list.filter((_, n) => n !== i))} aria-label={`Remove link ${i + 1}`} className={`${btn.danger} shrink-0 px-2.5`}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <button
            type="button"
            disabled={links.length >= MAX_LINKS}
            onClick={() => setLinks((list) => [...list, { label: '', url: '' }])}
            className={`${btn.plain} mt-2`}
          >
            <Plus size={15} strokeWidth={2.5} />
            Add link
          </button>
          <p className="mt-2 text-[13px] leading-snug text-ink-soft">
            Links appear as buttons in the bot’s welcome message and on the home page. Only the Telegram channel can be checked — follows on other
            platforms can’t be verified, so they are never required.
          </p>
        </div>

        <ErrorNote>{a.error}</ErrorNote>
        <button type="submit" disabled={a.busy !== null} className={btn.primary}>
          {a.busy && <Spinner />}
          Save follow settings
        </button>
      </form>
    </Panel>
  );
}
